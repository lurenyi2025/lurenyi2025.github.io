const fs = require('fs-extra');
const path = require('path');
const http = require('http');
const { spawn } = require('child_process');
const cheerio = require('cheerio');

const CHROME_CANDIDATES = [
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/Applications/Chromium.app/Contents/MacOS/Chromium'
];
const DEFAULT_WAIT_MS = 2500;
const MIN_CANVAS_CROP_SIZE = 8;

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function findChromeExecutable() {
  return CHROME_CANDIDATES.find((candidate) => fs.existsSync(candidate)) || '';
}

function httpGetJson(url) {
  return new Promise((resolve, reject) => {
    http.get(url, (res) => {
      let data = '';
      res.on('data', (chunk) => {
        data += String(chunk);
      });
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (error) {
          reject(error);
        }
      });
    }).on('error', reject);
  });
}

function normalizeRestoreNodeId(value) {
  return String(value || '')
    .trim()
    .replace(/[^a-z0-9_-]+/gi, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 96);
}

function dedupeRestoreNodeId(candidate, usedIds) {
  let nextId = normalizeRestoreNodeId(candidate) || 'restore-node-canvas';
  if (!usedIds.has(nextId)) {
    usedIds.add(nextId);
    return nextId;
  }

  let suffix = 2;
  while (usedIds.has(`${nextId}-${suffix}`)) {
    suffix += 1;
  }
  nextId = `${nextId}-${suffix}`;
  usedIds.add(nextId);
  return nextId;
}

function buildCanvasRestoreNodeId($element, index, usedIds) {
  const existingId = String($element.attr('data-restore-node-id') || '').trim();
  if (existingId) {
    usedIds.add(existingId);
    return existingId;
  }

  const domId = normalizeRestoreNodeId($element.attr('id'));
  if (domId) {
    return dedupeRestoreNodeId(`restore-node-canvas-${domId}`, usedIds);
  }

  return dedupeRestoreNodeId(`restore-node-canvas-${index}`, usedIds);
}

function serializeHtmlWithDoctype(sourceHtml, $) {
  const doctypeMatch = String(sourceHtml || '').match(/^\s*<!doctype[^>]*>/i);
  const serialized = $.html().replace(/^\s*<!doctype[^>]*>\s*/i, '');
  return doctypeMatch ? `${doctypeMatch[0]}\n${serialized}` : serialized;
}

function collectCanvasTargets(localizedHtml) {
  const sourceHtml = String(localizedHtml || '');
  const $ = cheerio.load(sourceHtml, { decodeEntities: false });
  const usedIds = new Set();
  $('[data-restore-node-id]').each((_, element) => {
    const restoreNodeId = String($(element).attr('data-restore-node-id') || '').trim();
    if (restoreNodeId) {
      usedIds.add(restoreNodeId);
    }
  });

  const targets = [];
  let changed = false;
  $('canvas').each((index, element) => {
    const $element = $(element);
    const restoreNodeId = buildCanvasRestoreNodeId($element, index, usedIds);
    if (String($element.attr('data-restore-node-id') || '').trim() !== restoreNodeId) {
      $element.attr('data-restore-node-id', restoreNodeId);
      changed = true;
    }

    targets.push({
      restoreNodeId,
      domId: String($element.attr('id') || '').trim(),
      width: Number.parseFloat(String($element.attr('width') || '0')) || 0,
      height: Number.parseFloat(String($element.attr('height') || '0')) || 0
    });
  });

  return {
    localizedHtml: serializeHtmlWithDoctype(sourceHtml, $),
    targets,
    changed
  };
}

function pushCanvasBackgroundSnapshots(collection, restoreNodeId, dataUrl) {
  if (!restoreNodeId || !dataUrl) {
    return;
  }

  const safeDataUrl = String(dataUrl).replace(/'/g, '%27');
  collection.push({
    id: restoreNodeId,
    attr: 'style.backgroundImage',
    dataUrl: `url('${safeDataUrl}')`
  });
  collection.push({
    id: restoreNodeId,
    attr: 'style.backgroundRepeat',
    dataUrl: 'no-repeat'
  });
  collection.push({
    id: restoreNodeId,
    attr: 'style.backgroundPosition',
    dataUrl: 'center center'
  });
  collection.push({
    id: restoreNodeId,
    attr: 'style.backgroundSize',
    dataUrl: '100% 100%'
  });
}

function mergeBrowserAssetSnapshots(existingSnapshots, nextSnapshots) {
  const merged = new Map();
  const push = (snapshot) => {
    if (!snapshot?.id || !snapshot?.attr || !snapshot?.dataUrl) {
      return;
    }
    merged.set(`${snapshot.id}::${snapshot.attr}`, snapshot);
  };

  (Array.isArray(existingSnapshots) ? existingSnapshots : []).forEach(push);
  (Array.isArray(nextSnapshots) ? nextSnapshots : []).forEach(push);
  return Array.from(merged.values());
}

async function openChrome(url, options = {}) {
  const chromeExecutable = findChromeExecutable();
  if (!chromeExecutable) {
    throw new Error('No Chrome executable found.');
  }

  const remoteDebuggingPort = Number(options.remoteDebuggingPort) || 39281;
  const viewportWidth = Math.max(320, Number(options.viewportWidth) || 1440);
  const viewportHeight = Math.max(320, Number(options.viewportHeight) || 960);
  const userDataDir = path.join('/tmp', `protorec-canvas-fallback-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`);

  const child = spawn(chromeExecutable, [
    '--headless=new',
    '--disable-gpu',
    `--window-size=${viewportWidth},${viewportHeight}`,
    `--remote-debugging-port=${remoteDebuggingPort}`,
    `--user-data-dir=${userDataDir}`,
    url
  ], {
    stdio: ['ignore', 'pipe', 'pipe']
  });

  let stderr = '';
  child.stderr.on('data', (chunk) => {
    stderr += String(chunk);
  });

  for (let attempt = 0; attempt < 40; attempt += 1) {
    await sleep(250);
    if (child.exitCode !== null) {
      await fs.remove(userDataDir).catch(() => {});
      throw new Error(`chrome exited early (${child.exitCode})\n${stderr}`);
    }

    try {
      const targets = await httpGetJson(`http://127.0.0.1:${remoteDebuggingPort}/json/list`);
      const pageTarget = Array.isArray(targets)
        ? targets.find((item) => item && item.type === 'page')
        : null;
      if (pageTarget?.webSocketDebuggerUrl) {
        return {
          child,
          userDataDir,
          webSocketDebuggerUrl: pageTarget.webSocketDebuggerUrl
        };
      }
    } catch (_error) {
      // Wait for the next attempt.
    }
  }

  child.kill('SIGTERM');
  await fs.remove(userDataDir).catch(() => {});
  throw new Error(`chrome debugger target not ready\n${stderr}`);
}

async function evaluatePage(webSocketDebuggerUrl, expression, waitMs = DEFAULT_WAIT_MS) {
  const socket = new WebSocket(webSocketDebuggerUrl);
  let messageId = 0;
  const pending = new Map();

  socket.onmessage = (event) => {
    const message = JSON.parse(event.data);
    if (!message.id || !pending.has(message.id)) {
      return;
    }

    const { resolve, reject } = pending.get(message.id);
    pending.delete(message.id);
    if (message.error) {
      reject(new Error(message.error.message || 'CDP request failed.'));
      return;
    }
    resolve(message.result);
  };

  const send = (method, params = {}) => new Promise((resolve, reject) => {
    const id = ++messageId;
    pending.set(id, { resolve, reject });
    socket.send(JSON.stringify({ id, method, params }));
  });

  await new Promise((resolve, reject) => {
    socket.onopen = resolve;
    socket.onerror = reject;
  });

  await send('Page.enable');
  await send('Runtime.enable');
  await sleep(waitMs);

  const result = await send('Runtime.evaluate', {
    expression,
    returnByValue: true,
    awaitPromise: true
  });

  socket.close();
  return result?.result?.value;
}

async function stopChrome(chrome) {
  if (!chrome?.child) {
    return;
  }

  if (chrome.child.exitCode === null) {
    chrome.child.kill('SIGTERM');
    await sleep(500);
    if (chrome.child.exitCode === null) {
      chrome.child.kill('SIGKILL');
    }
  }

  if (chrome.userDataDir) {
    await fs.remove(chrome.userDataDir).catch(() => {});
  }
}

function buildCanvasSnapshotExpression(options = {}) {
  const payload = JSON.stringify({
    referenceImageUrl: String(options.referenceImageUrl || ''),
    viewportWidth: Number(options.viewportWidth) || 0,
    viewportHeight: Number(options.viewportHeight) || 0,
    targetIds: Array.isArray(options.targetIds) ? options.targetIds : []
  });

  return `(() => {
    const options = ${payload};
    const loadImage = (src) => new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error('reference-image-load-failed'));
      image.src = src;
    });
    const isFullyVisible = (rect, viewportWidth, viewportHeight) => (
      rect.width >= ${MIN_CANVAS_CROP_SIZE}
      && rect.height >= ${MIN_CANVAS_CROP_SIZE}
      && rect.top >= -1
      && rect.left >= -1
      && rect.right <= viewportWidth + 1
      && rect.bottom <= viewportHeight + 1
    );
    return Promise.resolve()
      .then(() => document.fonts && document.fonts.ready ? document.fonts.ready.catch(() => undefined) : undefined)
      .then(() => new Promise((resolve) => setTimeout(resolve, 250)))
      .then(() => loadImage(options.referenceImageUrl))
      .then((referenceImage) => {
        const viewportWidth = Number(options.viewportWidth) || window.innerWidth || document.documentElement.clientWidth || 0;
        const viewportHeight = Number(options.viewportHeight) || window.innerHeight || document.documentElement.clientHeight || 0;
        const scaleX = viewportWidth > 0 ? referenceImage.naturalWidth / viewportWidth : 1;
        const scaleY = viewportHeight > 0 ? referenceImage.naturalHeight / viewportHeight : 1;
        const snapshots = [];

        for (const targetId of Array.isArray(options.targetIds) ? options.targetIds : []) {
          const selector = '[data-restore-node-id="' + String(targetId).replace(/"/g, '\\"') + '"]';
          const element = document.querySelector(selector);
          if (!(element instanceof HTMLCanvasElement)) {
            continue;
          }

          const style = window.getComputedStyle(element);
          if (style.display === 'none' || style.visibility === 'hidden' || Number.parseFloat(style.opacity || '1') <= 0) {
            continue;
          }

          const rect = element.getBoundingClientRect();
          if (!isFullyVisible(rect, viewportWidth, viewportHeight)) {
            continue;
          }

          const cropWidth = Math.max(1, Math.round(rect.width * scaleX));
          const cropHeight = Math.max(1, Math.round(rect.height * scaleY));
          const cropX = Math.max(0, Math.min(referenceImage.naturalWidth - cropWidth, Math.round(rect.left * scaleX)));
          const cropY = Math.max(0, Math.min(referenceImage.naturalHeight - cropHeight, Math.round(rect.top * scaleY)));
          if (cropWidth < ${MIN_CANVAS_CROP_SIZE} || cropHeight < ${MIN_CANVAS_CROP_SIZE}) {
            continue;
          }

          const scratch = document.createElement('canvas');
          scratch.width = cropWidth;
          scratch.height = cropHeight;
          const context = scratch.getContext('2d');
          if (!context) {
            continue;
          }

          context.drawImage(
            referenceImage,
            cropX,
            cropY,
            cropWidth,
            cropHeight,
            0,
            0,
            cropWidth,
            cropHeight
          );

          const dataUrl = scratch.toDataURL('image/png');
          if (!dataUrl || dataUrl === 'data:,') {
            continue;
          }

          snapshots.push({
            id: targetId,
            dataUrl,
            rect: {
              left: Number(rect.left.toFixed(2)),
              top: Number(rect.top.toFixed(2)),
              width: Number(rect.width.toFixed(2)),
              height: Number(rect.height.toFixed(2))
            }
          });
        }

        return {
          viewportWidth,
          viewportHeight,
          naturalWidth: referenceImage.naturalWidth,
          naturalHeight: referenceImage.naturalHeight,
          snapshots
        };
      })
      .catch((error) => ({
        error: error && error.message ? error.message : String(error || 'canvas-fallback-failed')
      }));
  })()`;
}

async function ensureCanvasSnapshotFallback(options = {}) {
  const captureDir = path.resolve(String(options.captureDir || '.'));
  const indexHtmlPath = path.join(captureDir, 'index.html');
  const referenceImagePath = path.join(captureDir, 'reference_full.png');
  const previewBaseUrl = String(options.previewBaseUrl || '').replace(/\/+$/g, '');
  const captureRelativePath = String(options.captureRelativePath || '').replace(/^\/+|\/+$/g, '');
  const metadata = options.metadata && typeof options.metadata === 'object'
    ? { ...options.metadata }
    : {};

  if (!previewBaseUrl || !captureRelativePath) {
    return { applied: false, reason: 'missing-preview-context', metadata, localizedHtml: String(options.localizedHtml || '') };
  }

  if (!await fs.pathExists(indexHtmlPath)) {
    return { applied: false, reason: 'missing-localized-html', metadata, localizedHtml: String(options.localizedHtml || '') };
  }

  if (!await fs.pathExists(referenceImagePath)) {
    return { applied: false, reason: 'missing-reference-image', metadata, localizedHtml: String(options.localizedHtml || '') };
  }

  const sourceHtml = String(options.localizedHtml || await fs.readFile(indexHtmlPath, 'utf8'));
  const canvasCollection = collectCanvasTargets(sourceHtml);
  if (!canvasCollection.targets.length) {
    return { applied: false, reason: 'no-canvas', metadata, localizedHtml: canvasCollection.localizedHtml };
  }

  const existingSnapshots = Array.isArray(metadata.browserAssetSnapshots) ? metadata.browserAssetSnapshots : [];
  const existingBackgroundImageIds = new Set(
    existingSnapshots
      .filter((snapshot) => snapshot?.attr === 'style.backgroundImage')
      .map((snapshot) => String(snapshot.id || '').trim())
      .filter(Boolean)
  );

  const missingSnapshotTargets = canvasCollection.targets.filter(
    (target) => !existingBackgroundImageIds.has(target.restoreNodeId)
  );

  if (!missingSnapshotTargets.length) {
    if (canvasCollection.changed) {
      await fs.writeFile(indexHtmlPath, canvasCollection.localizedHtml);
    }
    return {
      applied: false,
      reason: 'canvas-snapshots-already-present',
      metadata,
      localizedHtml: canvasCollection.localizedHtml,
      canvasCount: canvasCollection.targets.length
    };
  }

  if (canvasCollection.changed) {
    await fs.writeFile(indexHtmlPath, canvasCollection.localizedHtml);
  }

  const viewportWidth = Number(metadata?.viewport?.width) || 1440;
  const viewportHeight = Number(metadata?.viewport?.height) || 960;
  const previewUrl = `${previewBaseUrl}/temp_proto/${captureRelativePath}/index.html`;
  const referenceImageUrl = `${previewBaseUrl}/temp_proto/${captureRelativePath}/reference_full.png`;
  const remoteDebuggingPort = 39000 + Math.floor(Math.random() * 1000);

  let chrome = null;
  try {
    chrome = await openChrome(previewUrl, {
      remoteDebuggingPort,
      viewportWidth,
      viewportHeight
    });
    const evaluationResult = await evaluatePage(
      chrome.webSocketDebuggerUrl,
      buildCanvasSnapshotExpression({
        referenceImageUrl,
        viewportWidth,
        viewportHeight,
        targetIds: missingSnapshotTargets.map((target) => target.restoreNodeId)
      }),
      Number(options.waitMs) || DEFAULT_WAIT_MS
    );

    if (evaluationResult?.error) {
      return {
        applied: false,
        reason: `snapshot-eval-failed:${evaluationResult.error}`,
        metadata,
        localizedHtml: canvasCollection.localizedHtml,
        canvasCount: canvasCollection.targets.length
      };
    }

    const synthesizedSnapshots = [];
    (Array.isArray(evaluationResult?.snapshots) ? evaluationResult.snapshots : []).forEach((snapshot) => {
      pushCanvasBackgroundSnapshots(synthesizedSnapshots, snapshot.id, snapshot.dataUrl);
    });

    if (!synthesizedSnapshots.length) {
      return {
        applied: false,
        reason: 'no-visible-canvas-snapshots',
        metadata,
        localizedHtml: canvasCollection.localizedHtml,
        canvasCount: canvasCollection.targets.length
      };
    }

    return {
      applied: true,
      reason: 'canvas-snapshots-synthesized',
      metadata: {
        ...metadata,
        browserAssetSnapshots: mergeBrowserAssetSnapshots(existingSnapshots, synthesizedSnapshots)
      },
      localizedHtml: canvasCollection.localizedHtml,
      canvasCount: canvasCollection.targets.length,
      synthesizedCanvasCount: synthesizedSnapshots.length / 4,
      synthesizedSnapshotCount: synthesizedSnapshots.length
    };
  } finally {
    await stopChrome(chrome);
  }
}

module.exports = {
  ensureCanvasSnapshotFallback
};
