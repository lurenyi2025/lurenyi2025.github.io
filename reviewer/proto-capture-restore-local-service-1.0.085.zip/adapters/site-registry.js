const SITE_ADAPTERS = {
  vmallProductDetail: {
    id: 'vmall-product-detail',
    hostPatterns: ['vmall.com', 'www.vmall.com'],
    actionAnchorIds: ['serviceComponent', 'prd-botnav-leftbtn', 'prd-botnav-rightbtn'],
    purchasePairIds: ['prd-botnav-leftbtn', 'prd-botnav-rightbtn'],
    purchaseActionLabels: ['加入购物车', '立即购买'],
    comboPriceTexts: ['组合价', '组合价:'],
    selectionPrefixes: ['已选'],
    detailAnchorLabels: ['详情', '图文详情', '商品详情', '参数', '规格参数', '评价'],
    recommendationHeadings: ['搭配推荐', '相关好物', '看了又看', '为您推荐'],
    relatedGoodsViewMoreTexts: ['查看更多'],
    stableIdentityHints: [
      'navigationlayout',
      'product[_-]content[_-]box',
      'product[_-]gallery[_-]box',
      'prd-gallery',
      'prd-detail',
      'servicecomponent',
      'service-prd-list',
      'rndiyweb',
      'proddetail',
      'prd-reviews(?:-tl)?',
      'vbiz-footer',
      'product-installment-menu'
    ],
    textHints: {
      serviceStrip: ['服务与权益', '品质保证', '免运费', '官方售后', '全国联保'],
      specList: ['主要参数', '规格参数', '操作系统', '屏幕尺寸', '电池容量', '机身内存', 'cpu型号', '上市时间', '传播名', '特色功能'],
      legalNotice: ['特别提醒', '仅作示意', '请以实物为准', '理论值', '实际使用', '实时调整和修订'],
      reviewFeed: ['只看当前商品评价', '最热门', '评价('],
      productGrid: ['新品', '热销', '推荐', '商品'],
      featuredShelf: ['甄选', '推荐', '精选', '新品', '热销']
    }
  },
  hammerWorkbench: {
    id: 'hammer-workbench',
    hostPatterns: ['yzw.cn', 'xy.yzw.cn', 'fw-op.yzw.cn'],
    tableBadgeSurfaceSelectors: [
      '.hammer-table-body .hammer-jc-sesame-rolling-tag-item',
      '.hammer-table-body .hammer-tag.hammer-tag-processing',
      '.hammer-table-body .hammer-tag.hammer-tag-orange',
      '.ant-table-body .hammer-jc-sesame-rolling-tag-item',
      '.ant-table-body .hammer-tag.hammer-tag-processing',
      '.ant-table-body .hammer-tag.hammer-tag-orange'
    ],
    tableBadgeGroupSelectors: [
      '.hammer-table-body .hammer-jc-sesame-rolling-tag',
      '.ant-table-body .hammer-jc-sesame-rolling-tag',
      'td .hammer-jc-sesame-rolling-tag',
      'th .hammer-jc-sesame-rolling-tag'
    ],
    badgeDensitySelectors: [
      '.hammer-jc-sesame-rolling-tag',
      '.hammer-tag',
      '.hammer-jc-supplier-tag-button'
    ],
    multilineTextSelectors: [
      '[data-restore-layout-multiline="true"]',
      '.hammer-typography-ellipsis-multiple-line'
    ],
    compactIconHoverTargetSelectors: [
      'button',
      'a',
      '[role="button"]',
      '.hammer-btn',
      '[class*="supplier-tag-button"]',
      '[class*="icon-button"]'
    ],
    compactIconClassNamePattern: '(hammer-btn|supplier-tag-button|icon)',
    compactIconButtonVariants: {
      primarySolid: ['hammer-btn-primary', 'hammer-btn-variant-solid'],
      defaultOutlined: ['hammer-btn-default', 'hammer-btn-variant-outlined'],
      link: ['hammer-btn-link', 'hammer-btn-variant-link']
    },
    compactIconHoverStyles: {
      default: {
        borderRadius: '8px',
        background: 'rgb(242, 245, 248)',
        backgroundImage: 'none',
        backgroundColor: 'rgb(242, 245, 248)',
        borderColor: 'transparent',
        borderStyle: 'solid',
        borderWidth: '1px',
        boxShadow: 'rgb(242, 245, 248) 0 0 0 999px inset'
      },
      primarySolid: {
        borderRadius: '8px',
        background: 'linear-gradient(153.02deg, #4291ff, #15d1d0)',
        backgroundImage: 'linear-gradient(153.02deg, #4291ff, #15d1d0)',
        backgroundColor: 'rgba(0, 0, 0, 0)',
        borderColor: 'transparent',
        borderStyle: 'none',
        borderWidth: '0',
        boxShadow: 'none'
      },
      defaultOutlined: {
        borderRadius: '8px',
        background: 'rgb(236, 240, 244)',
        backgroundImage: 'none',
        backgroundColor: 'rgb(236, 240, 244)',
        borderColor: 'rgb(205, 210, 216)',
        borderStyle: 'solid',
        borderWidth: '1px',
        boxShadow: 'rgb(236, 240, 244) 0 0 0 999px inset'
      },
      link: {
        borderRadius: '8px',
        background: 'rgba(26, 114, 255, 0.12)',
        backgroundImage: 'none',
        backgroundColor: 'rgba(26, 114, 255, 0.12)',
        borderColor: 'transparent',
        borderStyle: 'solid',
        borderWidth: '1px',
        boxShadow: 'rgba(26, 114, 255, 0.12) 0 0 0 999px inset'
      }
    },
    tableBadgeVariants: {
      rollingOutline: {
        backgroundColor: 'rgb(255, 255, 255)'
      },
      processing: {
        backgroundColor: 'rgb(230, 244, 255)',
        borderColor: 'rgb(148, 200, 255)',
        textColor: 'rgb(26, 114, 255)'
      },
      orange: {
        backgroundColor: 'rgb(255, 247, 230)',
        borderColor: 'rgb(255, 213, 145)',
        textColor: 'rgb(212, 107, 8)'
      }
    },
    pageThemeTokens: {
      background: ['--yzw-color-bg-normal', '--proxima-background-color'],
      surface: ['--yzw-color-bg-pure']
    }
  }
};

function getSiteAdapter(adapterId) {
  return SITE_ADAPTERS[adapterId] || null;
}

function matchesHostPattern(hostname, pattern) {
  const normalizedHostname = String(hostname || '').toLowerCase();
  const normalizedPattern = String(pattern || '').toLowerCase();

  return !!normalizedHostname
    && !!normalizedPattern
    && (
      normalizedHostname === normalizedPattern
      || normalizedHostname.endsWith(`.${normalizedPattern}`)
    );
}

function resolveSiteAdapterByUrl(pageUrl) {
  if (!pageUrl) {
    return null;
  }

  try {
    const hostname = new URL(pageUrl).hostname;

    return Object.values(SITE_ADAPTERS).find((adapter) => {
      const hostPatterns = Array.isArray(adapter?.hostPatterns) ? adapter.hostPatterns : [];
      return hostPatterns.some((pattern) => matchesHostPattern(hostname, pattern));
    }) || null;
  } catch (_error) {
    return null;
  }
}

module.exports = {
  SITE_ADAPTERS,
  getSiteAdapter,
  resolveSiteAdapterByUrl
};
