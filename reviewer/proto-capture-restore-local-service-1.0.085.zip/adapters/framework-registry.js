function uniqueStrings(values = []) {
  return Array.from(new Set(
    values
      .map((value) => String(value || '').trim())
      .filter(Boolean)
  ));
}

function joinSelectors(values = []) {
  return uniqueStrings(values).join(', ');
}

const FRAMEWORK_SELECTORS = {
  tabs: {
    scopeRoots: ['.ant-tabs', '.el-tabs', '.hammer-tabs', '[data-tab-container]'],
    containers: ['.ant-tabs', '.el-tabs', '.hammer-tabs', '[role="tablist"]', '[data-tab-container]'],
    tabs: ['[role="tab"]', '.ant-tabs-tab', '.el-tabs__item', '.hammer-tabs-tab', '[data-tab]'],
    panels: ['[role="tabpanel"]', '.ant-tabs-tabpane', '.el-tab-pane', '.tab-pane', '.hammer-tabs-tabpane', '[data-tab-panel]'],
    wrappers: ['.ant-tabs-tab', '.el-tabs__item', '.hammer-tabs-tab', '[data-tab]'],
    activeTabClasses: ['ant-tabs-tab-active', 'hammer-tabs-tab-active', 'is-active', 'active', 'selected', 'current'],
    activePanelClasses: ['ant-tabs-tabpane-active', 'hammer-tabs-tabpane-active', 'is-active', 'active', 'show', 'selected', 'current'],
    hiddenPanelClasses: ['ant-tabs-tabpane-hidden', 'hammer-tabs-tabpane-hidden', 'hidden']
  },
  selects: {
    scopeRoots: ['.ant-select', '.el-select', '.hammer-select', '[data-select-root]'],
    roots: ['.ant-select', '.el-select', '.hammer-select', '[data-select-root]'],
    triggers: ['.ant-select-selector', '.el-select__wrapper', '.hammer-select-selector', '[data-select-trigger]'],
    values: ['.ant-select-selection-item', '.el-select__selected-item', '.hammer-select-selection-item', '[data-select-value]'],
    menus: ['.ant-select-dropdown', '.el-select-dropdown', '.hammer-select-dropdown', '[role="listbox"]', '[data-select-menu]'],
    options: ['.ant-select-item-option', '.el-select-dropdown__item', '.hammer-select-item', '[role="option"]', '[data-select-option]'],
    openClasses: ['ant-select-open', 'is-focus', 'is-open', 'is-active', 'hammer-select-open'],
    clearTriggers: ['.ant-select-clear', '.hammer-select-clear', '[data-select-clear]'],
    likeTriggers: ['.ant-select-selector', '.el-select__wrapper', '.hammer-select-selector', '[data-select-trigger]', '[role="combobox"]', 'input[aria-haspopup="listbox"]', 'input[aria-controls]']
  },
  collapse: {
    scopeRoots: ['.ant-collapse-item', '.el-collapse-item', '.hammer-collapse-item', '[data-collapse-item]'],
    headers: ['.ant-collapse-header', '.el-collapse-item__header', '.hammer-collapse-header', '[data-collapse-trigger]'],
    items: ['.ant-collapse-item', '.el-collapse-item', '.hammer-collapse-item', '[data-collapse-item]'],
    contents: ['.ant-collapse-content', '.el-collapse-item__wrap', '.hammer-collapse-content', '[data-collapse-content]'],
    activeClasses: ['ant-collapse-item-active', 'is-active', 'active', 'open']
  },
  dropdowns: {
    scopeRoots: [
      '.ant-dropdown',
      '.el-dropdown',
      '.hammer-dropdown',
      '.dropdown',
      '[data-dropdown-root]',
      '[data-dropdown]',
      '.hammer-basic-download-center',
      '[aria-haspopup="true"]'
    ],
    triggers: ['.ant-dropdown-trigger', '.el-dropdown-link', '.hammer-dropdown-trigger', '[data-dropdown-trigger]'],
    menus: ['.ant-dropdown', '.el-dropdown-menu', '.hammer-dropdown', '.dropdown-menu', '[data-dropdown-menu]'],
    hiddenClasses: ['ant-dropdown-hidden', 'hammer-dropdown-hidden', 'hidden']
  },
  modals: {
    scopeRoots: ['.ant-modal-root', '.ant-drawer', '.el-dialog__wrapper', '.hammer-modal', '[role="dialog"]', '.modal', '[data-modal-root]'],
    roots: ['.ant-modal-root', '.ant-drawer', '.el-dialog__wrapper', '.hammer-modal', '[role="dialog"]', '.modal', '[data-modal-root]'],
    triggers: ['[data-modal-trigger]', '[data-target]', '[data-modal-target]', '[aria-controls]', '[aria-haspopup="dialog"]', 'a[href^="#"]', '.ant-btn', '.el-button', 'button', '[role="button"]'],
    closes: ['.ant-modal-close', '.ant-drawer-close', '.el-dialog__headerbtn', '.modal-close', '[data-modal-close]'],
    openClasses: ['ant-modal-open', 'ant-drawer-open', 'is-open', 'open', 'active'],
    hiddenClasses: ['hidden', 'hide', 'is-hidden', 'hidden-modal', 'modal-hidden', 'drawer-hidden', 'popup-hidden', 'ant-modal-hidden', 'ant-drawer-hidden']
  },
  inputs: {
    scopeRoots: ['.ant-input-affix-wrapper', '.ant-input-group-wrapper', '.hammer-input-affix-wrapper', '.hammer-input-wrapper', '[data-input-wrapper]'],
    wrappers: ['.ant-input-affix-wrapper', '.ant-input-group-wrapper', '.hammer-input-affix-wrapper', '.hammer-input-wrapper', '[data-input-wrapper]'],
    clearTriggers: ['.ant-input-clear-icon', '.hammer-input-clear-icon', '.anticon-close-circle', '[data-clear-trigger]'],
    focusedClasses: ['ant-input-affix-wrapper-focused', 'hammer-input-affix-wrapper-focused', 'is-focus', 'focused'],
    filledClasses: ['has-value', 'is-filled']
  },
  tables: {
    containers: ['.hammer-table-container', '.ant-table-container', '[data-table-container]'],
    headers: ['.hammer-table-header', '.ant-table-header', '[data-table-header]'],
    bodies: ['.hammer-table-body', '.ant-table-body', '.ant-table-content', '[data-table-body]'],
    stickyScrolls: ['.hammer-table-sticky-scroll', '.ant-table-sticky-scroll', '[data-table-sticky-scroll]'],
    pingLeftClasses: ['hammer-table-ping-left', 'ant-table-ping-left'],
    pingRightClasses: ['hammer-table-ping-right', 'ant-table-ping-right']
  },
  carousel: {
    scopeRoots: ['[data-carousel-root]', '.swiper', '.swiper-container', '.slick-slider', '.ant-carousel', '[class*="carousel"]', '[data-carousel]', '[data-swiper]'],
    roots: ['[data-carousel-root]'],
    slides: ['[data-carousel-slide]'],
    controls: ['[data-carousel-control]'],
    activeClasses: ['active', 'is-active', 'current', 'selected', 'swiper-slide-active', 'slick-active'],
    verticalRoots: ['.hammer-carousel-vertical', '.slick-slider.slick-vertical', '.slick-vertical']
  },
  placeholders: {
    inputs: ['.hammer-input', '.ant-input']
  }
};

module.exports = {
  FRAMEWORK_SELECTORS,
  joinSelectors,
  uniqueStrings
};
