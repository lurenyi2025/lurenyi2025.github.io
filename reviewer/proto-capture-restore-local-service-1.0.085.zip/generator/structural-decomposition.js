const cheerio = require('cheerio');

const MARKER_PREFIX = '__PROTOREC_FRAGMENT:';
const MARKER_SUFFIX = '__';

const FRAGMENT_RULES = [
  {
    id: 'header',
    name: 'HeaderFragment',
    kind: 'header',
    sectionKind: 'top-bar',
    title: 'Header Fragment',
    selectors: [
      'header.ant-layout-header',
      '.ant-pro-layout-header',
      '.ant-pro-global-header',
      'header',
      '[role="banner"]',
      '[class*="header"]'
    ],
    confidence: 0.82,
    minHtmlLength: 300,
    risk: 'medium'
  },
  {
    id: 'sider-nav',
    name: 'SiderNavFragment',
    kind: 'sider-nav',
    sectionKind: 'sidebar',
    title: 'Sider Navigation Fragment',
    selectors: [
      'aside.ant-layout-sider',
      '.ant-pro-sider',
      'aside',
      '[role="navigation"]',
      'nav',
      '[class*="sider"]',
      '[class*="sidebar"]'
    ],
    confidence: 0.8,
    minHtmlLength: 600,
    risk: 'medium'
  },
  {
    id: 'breadcrumb',
    name: 'BreadcrumbFragment',
    kind: 'breadcrumb',
    sectionKind: 'breadcrumb',
    title: 'Breadcrumb Fragment',
    selectors: [
      'nav.ant-breadcrumb',
      '.ant-breadcrumb',
      '[aria-label*="breadcrumb" i]',
      '[class*="breadcrumb"]'
    ],
    confidence: 0.78,
    minHtmlLength: 80,
    risk: 'low'
  },
  {
    id: 'page-header',
    name: 'PageHeaderFragment',
    kind: 'page-header',
    sectionKind: 'page-header',
    title: 'Page Header Fragment',
    selectors: [
      '.ant-page-header',
      '.ant-pro-page-container-warp',
      '[class*="page-header"]',
      '[class*="pageHeader"]'
    ],
    confidence: 0.76,
    minHtmlLength: 180,
    risk: 'low'
  },
  {
    id: 'filter-form',
    name: 'FilterFormFragment',
    kind: 'filter-form',
    sectionKind: 'form',
    title: 'Filter Form Fragment',
    selectors: [
      'form.ant-pro-query-filter',
      '.ant-pro-query-filter',
      'form',
      '[role="form"]'
    ],
    confidence: 0.82,
    minHtmlLength: 500,
    risk: 'medium'
  },
  {
    id: 'table-toolbar',
    name: 'TableToolbarFragment',
    kind: 'table-toolbar',
    sectionKind: 'table-toolbar',
    title: 'Table Toolbar Fragment',
    selectors: [
      '.ant-pro-table-list-toolbar',
      '.ant-table-title',
      '[class*="table"][class*="toolbar"]',
      '[class*="toolbar"]'
    ],
    confidence: 0.76,
    minHtmlLength: 180,
    risk: 'low'
  },
  {
    id: 'data-table',
    name: 'DataTableFragment',
    kind: 'data-table',
    sectionKind: 'table',
    title: 'Data Table Fragment',
    selectors: [
      '.ant-table-wrapper',
      '.ant-table',
      '[role="table"]',
      'table',
      '.el-table'
    ],
    confidence: 0.84,
    minHtmlLength: 800,
    risk: 'medium'
  },
  {
    id: 'pagination',
    name: 'PaginationFragment',
    kind: 'pagination',
    sectionKind: 'pagination',
    title: 'Pagination Fragment',
    selectors: [
      '.ant-pagination',
      '.el-pagination',
      '[class*="pagination"]',
      '[aria-label*="pagination" i]'
    ],
    confidence: 0.78,
    minHtmlLength: 120,
    risk: 'low'
  },
  {
    id: 'footer',
    name: 'FooterFragment',
    kind: 'footer',
    sectionKind: 'footer',
    title: 'Footer Fragment',
    selectors: [
      'footer.ant-layout-footer',
      '.ant-layout-footer',
      'footer',
      '[role="contentinfo"]',
      '[class*="footer"]'
    ],
    confidence: 0.78,
    minHtmlLength: 160,
    risk: 'medium'
  }
];

function normalizeText(value = '', maxLength = 240) {
  return String(value || '').replace(/\s+/g, ' ').trim().slice(0, maxLength);
}

function toNumber(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function getOuterHtml($, element) {
  return String($.html(element) || '').trim();
}

function getStats($, $element) {
  const html = getOuterHtml($, $element.get(0));
  const text = normalizeText($element.text() || '', 240);
  return {
    htmlLength: html.length,
    textLength: text.length,
    textSnippet: text,
    childCount: $element.children().length,
    inputCount: $element.find('input, select, textarea, [role="textbox"], [contenteditable="true"]').length,
    buttonCount: $element.find('button, [role="button"], a').length,
    tableCount: $element.find('table, [role="table"], .ant-table, .el-table').length,
    menuCount: $element.find('.ant-menu, [role="menu"], nav, a').length
  };
}

function getDepth($element) {
  return $element.parents().length;
}

function getSelectorHint($element) {
  const element = $element.get(0);
  const tagName = String(element?.tagName || element?.name || 'div').toLowerCase();
  const id = String($element.attr('id') || '').trim();
  const className = String($element.attr('class') || '').trim();
  const role = String($element.attr('role') || '').trim();
  const idPart = id ? `#${id}` : '';
  const classPart = className
    ? `.${className.split(/\s+/).filter(Boolean).slice(0, 4).join('.')}`
    : '';
  const rolePart = role ? `[role="${role}"]` : '';
  return `${tagName}${idPart}${classPart}${rolePart}`;
}

function getBBox($element) {
  return {
    x: toNumber($element.attr('data-restore-layout-x') || $element.attr('data-restore-bbox-x')),
    y: toNumber($element.attr('data-restore-layout-y') || $element.attr('data-restore-bbox-y')),
    width: toNumber($element.attr('data-restore-layout-width') || $element.attr('data-restore-bbox-width')),
    height: toNumber($element.attr('data-restore-layout-height') || $element.attr('data-restore-bbox-height'))
  };
}

function getTextSignals(text) {
  const normalized = normalizeText(text, 260);
  if (!normalized) {
    return [];
  }

  const signals = [];
  normalized.split(/[\s/|,，。:：;；]+/).forEach((part) => {
    const value = part.trim();
    if (value && value.length <= 24 && !signals.includes(value)) {
      signals.push(value);
    }
  });

  if (!signals.length && normalized) {
    signals.push(normalized.slice(0, 40));
  }

  return signals.slice(0, 8);
}

function scoreCandidate(rule, stats, selectorIndex, elementIndex) {
  let score = rule.confidence * 100;
  score -= selectorIndex * 4;
  score -= elementIndex;

  if (rule.kind === 'filter-form') {
    score += Math.min(18, stats.inputCount * 3);
    score += Math.min(8, stats.buttonCount);
  }
  if (rule.kind === 'data-table') {
    score += stats.tableCount > 0 ? 18 : 0;
  }
  if (rule.kind === 'sider-nav') {
    score += Math.min(14, stats.menuCount);
  }
  if (rule.kind === 'table-toolbar') {
    score += Math.min(12, stats.buttonCount * 2);
  }
  if (rule.kind === 'pagination') {
    score += /(^|\s)(\d+|prev|next|上一页|下一页)(\s|$)/i.test(stats.textSnippet) ? 8 : 0;
  }
  if (!stats.textLength && rule.kind !== 'data-table') {
    score -= 12;
  }
  if (stats.htmlLength > 0 && stats.htmlLength < rule.minHtmlLength) {
    score -= 30;
  }

  return score;
}

function collectRuleCandidates($, rule, claimedElements) {
  const candidates = [];

  rule.selectors.forEach((selector, selectorIndex) => {
    let elements = [];
    try {
      elements = $(selector).toArray();
    } catch (_error) {
      elements = [];
    }

    elements.forEach((element, elementIndex) => {
      if (!element || claimedElements.has(element)) {
        return;
      }

      const $element = $(element);
      const stats = getStats($, $element);
      if (stats.htmlLength < rule.minHtmlLength) {
        return;
      }
      if (!stats.textLength && !stats.tableCount && !stats.inputCount && rule.kind !== 'header') {
        return;
      }

      candidates.push({
        rule,
        element,
        selector,
        selectorIndex,
        elementIndex,
        stats,
        score: scoreCandidate(rule, stats, selectorIndex, elementIndex),
        depth: getDepth($element)
      });
    });
  });

  return candidates.sort((left, right) => (
    right.score - left.score
    || right.depth - left.depth
    || right.stats.htmlLength - left.stats.htmlLength
  ));
}

function selectFragmentCandidates($) {
  const claimedElements = new Set();
  const selected = [];

  FRAGMENT_RULES.forEach((rule) => {
    const candidates = collectRuleCandidates($, rule, claimedElements);
    const candidate = candidates[0] || null;
    if (!candidate) {
      return;
    }

    claimedElements.add(candidate.element);
    selected.push(candidate);
  });

  return selected;
}

function markerFor(name) {
  return `${MARKER_PREFIX}${name}${MARKER_SUFFIX}`;
}

function replaceFragmentMarkers(markup, fragmentByName, depth = 0) {
  if (depth > 20) {
    return markup;
  }

  return String(markup || '').replace(
    new RegExp(`<!--${MARKER_PREFIX}([A-Za-z0-9_]+)${MARKER_SUFFIX}-->`, 'g'),
    (_match, name) => replaceFragmentMarkers(fragmentByName.get(name) || '', fragmentByName, depth + 1)
  );
}

function buildSectionRecord(fragment) {
  return {
    id: fragment.id,
    title: fragment.title,
    kind: fragment.sectionKind,
    confidence: fragment.confidence,
    summary: `${fragment.name} (${fragment.kind})`,
    renderMode: 'fallback-fragment',
    shellTag: 'section',
    markup: fragment.html,
    previewMarkup: fragment.html,
    blocks: [],
    componentName: fragment.name,
    fileName: `${fragment.name}.tsx`,
    interactionIds: [],
    contextWrappers: [],
    diagnostics: {
      source: {
        tagName: fragment.tagName,
        selectorHint: fragment.selectorHint,
        textSnippet: fragment.textSignals.join(' ')
      },
      naming: {
        baseName: fragment.id,
        finalId: fragment.id,
        componentName: fragment.name,
        quality: 'maintainable'
      },
      classification: {
        kind: fragment.sectionKind,
        matchedRules: fragment.matchedRules
      },
      structure: {
        htmlLength: fragment.htmlLength,
        childCount: fragment.childCount,
        imageCount: fragment.imageCount,
        interactionCount: 0,
        blockCount: 0
      },
      context: {
        strategy: 'level-1.5-named-fallback-fragment',
        wrapperCount: 0,
        wrappers: []
      },
      extraction: {
        status: 'success',
        source: 'post-restore-structural-decomposition',
        originalRenderMode: fragment.originalRenderMode || 'oversized-single-fragment',
        selectorHint: fragment.selectorHint
      },
      renderDecision: {
        mode: 'fallback-fragment',
        reasons: ['超大 fallback body 已拆成命名 fallback fragment，保留原始 HTML 渲染']
      },
      confidenceDecision: {
        score: fragment.confidence,
        reasons: [`命中 ${fragment.kind} 通用结构信号`]
      },
      issues: fragment.risk === 'high' ? ['命名片段仍需谨慎编辑'] : [],
      vibecoding: {
        suitabilityScore: Math.round(fragment.confidence * 100),
        changeRisk: fragment.risk,
        reasons: ['已提供命名 fallback fragment，适合小步定位修改']
      }
    },
    stats: {
      htmlLength: fragment.htmlLength,
      childCount: fragment.childCount,
      imageCount: fragment.imageCount,
      blockCount: 0
    }
  };
}

function createFallbackSectionMap(reason, sections = []) {
  return {
    version: 1,
    strategy: 'post-restore-named-fragments',
    source: 'page-ir',
    fragments: [],
    unclassifiedHtmlLength: sections.reduce((sum, section) => sum + Number(section?.stats?.htmlLength || 0), 0),
    fallbackReason: reason
  };
}

function decomposeSection(section) {
  const sourceMarkup = String(section?.previewMarkup || section?.markup || '').trim();
  if (!sourceMarkup || sourceMarkup.length < 50000) {
    return null;
  }

  const $ = cheerio.load(`<div id="__protorec-decomposition-root">${sourceMarkup}</div>`, { decodeEntities: false });
  const $root = $('#__protorec-decomposition-root');
  const selected = selectFragmentCandidates($);

  if (selected.length < 3) {
    return null;
  }

  const fragmentRecords = [];
  const candidatesByDepth = selected.slice().sort((left, right) => right.depth - left.depth);

  candidatesByDepth.forEach((candidate, index) => {
    const $element = $(candidate.element);
    const html = getOuterHtml($, candidate.element);
    if (!html) {
      return;
    }

    const rule = candidate.rule;
    const tagName = String(candidate.element?.tagName || candidate.element?.name || 'div').toLowerCase();
    const imageCount = $element.find('img, picture, svg, canvas, video').length;
    const fragment = {
      id: rule.id,
      name: rule.name,
      kind: rule.kind,
      sectionKind: rule.sectionKind,
      title: rule.title,
      renderMode: 'fallback-fragment',
      confidence: Number(Math.min(0.94, Math.max(0.55, candidate.score / 100)).toFixed(2)),
      selectorHint: getSelectorHint($element),
      matchedRules: [`selector:${candidate.selector}`, `kind:${rule.kind}`],
      textSignals: getTextSignals(candidate.stats.textSnippet),
      bbox: getBBox($element),
      htmlLength: html.length,
      childCount: candidate.stats.childCount,
      imageCount,
      risk: rule.risk,
      originalRenderMode: section?.renderMode || 'oversized-single-fragment',
      order: index + 1,
      tagName,
      html
    };

    fragmentRecords.push(fragment);
    $element.replaceWith(`<!--${markerFor(rule.name)}-->`);
  });

  const appShellHtml = String($root.html() || '').trim();
  const fragmentByName = new Map(fragmentRecords.map((fragment) => [fragment.name, fragment.html]));
  const renderedHtml = replaceFragmentMarkers(appShellHtml, fragmentByName);

  if (!renderedHtml.trim()) {
    return null;
  }

  const appShellRecord = {
    id: 'app-shell',
    name: 'AppShellFragment',
    kind: 'app-shell',
    sectionKind: 'app-shell',
    title: 'App Shell Fragment',
    renderMode: 'fallback-fragment',
    confidence: 0.78,
    selectorHint: section?.diagnostics?.source?.selectorHint || section.id || 'body',
    matchedRules: [`source:${section?.renderMode || 'oversized-single-fragment'}`, 'strategy:marker-preserving-shell'],
    textSignals: [],
    bbox: { x: 0, y: 0, width: 0, height: 0 },
    htmlLength: appShellHtml.length,
    childCount: $root.children().length,
    imageCount: 0,
    risk: 'medium',
    order: 0,
    tagName: 'fragment',
    html: appShellHtml
  };

  const sectionMapFragments = [appShellRecord].concat(
    fragmentRecords
      .sort((left, right) => left.order - right.order)
      .map((fragment) => ({
        id: fragment.id,
        name: fragment.name,
        kind: fragment.kind,
        renderMode: fragment.renderMode,
        confidence: fragment.confidence,
        selectorHint: fragment.selectorHint,
        matchedRules: fragment.matchedRules,
        textSignals: fragment.textSignals,
        bbox: fragment.bbox,
        htmlLength: fragment.htmlLength,
        risk: fragment.risk
      }))
  );

  const unclassifiedHtmlLength = appShellHtml
    .replace(new RegExp(`<!--${MARKER_PREFIX}[A-Za-z0-9_]+${MARKER_SUFFIX}-->`, 'g'), '')
    .trim()
    .length;

  return {
    sections: fragmentRecords
      .sort((left, right) => left.order - right.order)
      .map(buildSectionRecord),
    sectionMap: {
      version: 1,
      strategy: 'post-restore-named-fragments',
      source: 'page-ir',
      rootSectionId: section.id,
      rootRenderMode: section.renderMode,
      fragments: sectionMapFragments,
      unclassifiedHtmlLength,
      fallbackReason: null,
      diagnostics: {
        selectedFragmentCount: fragmentRecords.length,
        originalHtmlLength: sourceMarkup.length,
        renderedHtmlLength: renderedHtml.length,
        shellHtmlLength: appShellHtml.length,
        markerPreserving: true
      }
    },
    structuralDecomposition: {
      enabled: true,
      strategy: 'post-restore-named-fragments',
      rootFragmentName: 'AppShellFragment',
      fragments: [appShellRecord].concat(fragmentRecords.sort((left, right) => left.order - right.order)),
      previewBodyMarkup: renderedHtml,
      diagnostics: {
        selectedFragmentCount: fragmentRecords.length,
        originalHtmlLength: sourceMarkup.length,
        renderedHtmlLength: renderedHtml.length,
        shellHtmlLength: appShellHtml.length,
        unclassifiedHtmlLength
      }
    }
  };
}

function applyStructuralDecomposition(sections = []) {
  if (sections.length !== 1) {
    return {
      sections,
      sectionMap: createFallbackSectionMap('not-a-single-fallback-section', sections),
      structuralDecomposition: null
    };
  }

  const [rootSection] = sections;
  const rootHtmlLength = Number(rootSection?.stats?.htmlLength || 0);
  const rootBlockCount = Array.isArray(rootSection?.blocks) ? rootSection.blocks.length : 0;
  if (rootHtmlLength < 50000 || rootBlockCount > 0) {
    return {
      sections,
      sectionMap: createFallbackSectionMap('single-section-not-oversized-or-already-blocked', sections),
      structuralDecomposition: null
    };
  }

  const decomposed = decomposeSection(rootSection);
  if (!decomposed) {
    return {
      sections,
      sectionMap: createFallbackSectionMap('no-reliable-named-fragments', sections),
      structuralDecomposition: null
    };
  }

  return decomposed;
}

module.exports = {
  applyStructuralDecomposition,
  replaceFragmentMarkers
};
