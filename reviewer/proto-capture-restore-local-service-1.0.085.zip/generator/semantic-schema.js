const cheerio = require('cheerio');
const { sanitizeSegment } = require('./naming');

function normalizeText(value, maxLength = 120) {
  return String(value || '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, maxLength);
}

function makeId(value, fallback) {
  const asciiCandidate = normalizeText(value, 64)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  const normalized = asciiCandidate || sanitizeSegment(asciiCandidate);
  return normalized || fallback;
}

function uniqueId(baseId, seenIds, fallback) {
  const base = makeId(baseId, fallback);
  let candidate = base;
  let suffix = 2;
  while (seenIds.has(candidate)) {
    candidate = `${base}-${suffix}`;
    suffix += 1;
  }
  seenIds.add(candidate);
  return candidate;
}

function selectorFor($element, fallback = '') {
  const id = String($element.attr('id') || '').trim();
  if (id) {
    return `#${id.replace(/"/g, '\\"')}`;
  }

  const restoreNodeId = String($element.attr('data-restore-node-id') || '').trim();
  if (restoreNodeId) {
    return `[data-restore-node-id="${restoreNodeId.replace(/"/g, '\\"')}"]`;
  }

  const className = String($element.attr('class') || '')
    .split(/\s+/)
    .map((item) => item.trim())
    .filter(Boolean)
    .slice(0, 3)
    .join('.');
  if (className) {
    return `${$element.get(0)?.tagName || $element.get(0)?.name || '*'} .${className}`.replace(' .', '.');
  }

  return fallback;
}

function classifyColumnKind(label, cells = []) {
  const joined = [label, ...cells].join(' ').toLowerCase();
  if (/(操作|action|actions|edit|delete|view|查看|编辑|删除)/i.test(joined)) return 'action';
  if (cells.length && cells.every((value) => /^[-+]?\d+(?:[.,]\d+)?%?$/.test(String(value).trim()))) return 'number';
  if (/(date|日期|时间)/i.test(label) || cells.some((value) => /\d{4}[-/]\d{1,2}[-/]\d{1,2}/.test(value))) return 'date';
  if (/(status|状态|完成|completion)/i.test(label)) return 'status';
  return 'text';
}

function looksLikeNonActionValue(label) {
  const normalized = normalizeText(label, 80);
  if (!normalized) {
    return true;
  }
  if (/^[-+]?\d+(?:[.,]\d+)?%?$/.test(normalized)) {
    return true;
  }
  if (/^\d{4}[-/]\d{1,2}[-/]\d{1,2}(?:\s+\d{1,2}:\d{2}(?::\d{2})?)?$/.test(normalized)) {
    return true;
  }
  if (/^\d{1,2}:\d{2}(?::\d{2})?$/.test(normalized)) {
    return true;
  }
  return false;
}

function looksLikeActionLabel(label) {
  const normalized = normalizeText(label, 40);
  if (!normalized || normalized.length > 24 || looksLikeNonActionValue(normalized)) {
    return false;
  }
  return /(操作|action|view|edit|delete|remove|detail|details|open|配置|订阅|警报|查看|编辑|删除|详情|打开|禁用|启用|启停|发布|下线|上线)/i.test(normalized)
    || /^[\u4e00-\u9fff]{1,6}$/.test(normalized);
}

function extractCellActionLabels($, $cell) {
  const labels = [];
  $cell.find('a, button, [role="button"], [role="menuitem"]').toArray().forEach((actionElement) => {
    const label = normalizeText($(actionElement).text() || $(actionElement).attr('aria-label') || $(actionElement).attr('title') || '', 40);
    if (looksLikeActionLabel(label)) {
      labels.push(label);
    }
  });
  return labels;
}

function extractTableSchema($) {
  const $table = $('table, [role="table"], .ant-table, .el-table, .datatable-table').filter((_, element) => {
    const text = normalizeText($(element).text(), 400);
    return text.length >= 20;
  }).first();
  if (!$table.length) {
    return null;
  }

  const $headerCells = $table.find('thead th, [role="columnheader"]');
  const headerLabels = $headerCells.toArray().map((element) => normalizeText($(element).text(), 80));
  const rows = [];
  $table.find('tbody tr, [role="row"]').toArray().forEach((rowElement, rowIndex) => {
    const $row = $(rowElement);
    const cellElements = $row.find('td, [role="cell"], [role="gridcell"]').toArray();
    const cells = cellElements.map((cellElement) => normalizeText($(cellElement).text(), 120));
    if (cells.length) {
      rows.push({
        id: `row-${rowIndex + 1}`,
        rawCells: cells,
        cellActions: cellElements.map((cellElement) => extractCellActionLabels($, $(cellElement)))
      });
    }
  });

  const maxCellCount = rows.reduce((max, row) => Math.max(max, row.rawCells.length), 0);
  const sourceColumnCount = Math.max(headerLabels.length, maxCellCount);
  if (sourceColumnCount < 2 || rows.length < 1) {
    return null;
  }

  const seenColumnIds = new Set();
  const columns = Array.from({ length: sourceColumnCount }).map((_, index) => {
    const sampleCells = rows.map((row) => row.rawCells[index] || '').filter(Boolean).slice(0, 8);
    if (!headerLabels[index] && !sampleCells.length) {
      return null;
    }
    const label = headerLabels[index] || `Column ${index + 1}`;
    const id = uniqueId(label, seenColumnIds, `column-${index + 1}`);
    return {
      id,
      label,
      sourceIndex: index,
      widthHint: '',
      sortable: Boolean($headerCells.eq(index).find('[aria-sort], .sort, .sortable').length || /sortable/.test(String($table.attr('class') || ''))),
      kind: classifyColumnKind(label, sampleCells)
    };
  }).filter(Boolean);

  if (columns.length < 2) {
    return null;
  }

  const normalizedRows = rows.slice(0, 40).map((row) => {
    const cells = {};
    columns.forEach((column) => {
      cells[column.id] = row.rawCells[column.sourceIndex] || '';
    });
    return { id: row.id, cells };
  });

  const actionColumn = columns.find((column) => column.kind === 'action');
  const seenActionIds = new Set();
  const actions = actionColumn
    ? Array.from(new Set(
      rows.flatMap((row) => {
        const elementActions = Array.isArray(row.cellActions?.[actionColumn.sourceIndex])
          ? row.cellActions[actionColumn.sourceIndex]
          : [];
        if (elementActions.length) {
          return elementActions;
        }
        return String(row.rawCells[actionColumn.sourceIndex] || '')
          .split(/\s+/)
          .map((value) => normalizeText(value, 40))
          .filter((value) => looksLikeActionLabel(value));
      })
    )).slice(0, 8).map((label) => ({
      id: uniqueId(label, seenActionIds, `action-${seenActionIds.size + 1}`),
      label,
      kind: 'link'
    }))
    : [];

  return {
    id: 'primary-table',
    selector: selectorFor($table, 'table'),
    confidence: 0.86,
    columns,
    rows: normalizedRows,
    actions,
    diagnostics: {
      source: 'dom-table',
      headerCount: headerLabels.length,
      rowCount: rows.length,
      modeledRowCount: normalizedRows.length
    }
  };
}

function inferControl($field) {
  const tagName = String($field.get(0)?.tagName || $field.get(0)?.name || '').toLowerCase();
  const type = String($field.attr('type') || '').toLowerCase();
  const role = String($field.attr('role') || '').toLowerCase();
  const className = String($field.attr('class') || '').toLowerCase();
  if (tagName === 'select' || role === 'combobox' || /select|picker/.test(className)) return 'select';
  if (/date|time/.test(type) || /date|time/.test(className)) return /range/.test(className) ? 'daterange' : 'date';
  if (type === 'checkbox') return 'checkbox';
  if (tagName === 'input' || tagName === 'textarea' || role === 'textbox') return 'input';
  return 'unknown';
}

function extractFilterSchema($) {
  const $form = $('form, .ant-pro-query-filter, .ant-form, .filter, .search').filter((_, element) => {
    const $element = $(element);
    return $element.find('input, select, textarea, [role="textbox"], [role="combobox"], button').length >= 2;
  }).first();
  if (!$form.length) {
    return null;
  }

  const fields = [];
  const seen = new Set();
  $form.find('input, select, textarea, [role="textbox"], [role="combobox"]').toArray().forEach((fieldElement, index) => {
    const $field = $(fieldElement);
    const placeholder = normalizeText($field.attr('placeholder') || '', 80);
    let label = normalizeText($field.closest('label, .ant-form-item, .form-group, .mb-3, .row, .col').find('label, .ant-form-item-label').first().text(), 80);
    if (!label) label = placeholder || normalizeText($field.attr('name') || $field.attr('aria-label') || '', 80);
    if (!label) label = `Filter ${index + 1}`;
    const id = uniqueId(label, seen, `filter-${index + 1}`);
    fields.push({
      id,
      label,
      control: inferControl($field),
      placeholder,
      options: $field.find('option').toArray().map((option) => normalizeText($(option).text(), 80)).filter(Boolean)
    });
  });

  if (!fields.length) {
    return null;
  }

  return {
    id: 'primary-filter',
    selector: selectorFor($form, 'form'),
    confidence: fields.length >= 2 ? 0.82 : 0.68,
    fields,
    collapsible: false,
    defaultCollapsed: false,
    diagnostics: {
      source: 'dom-form',
      fieldCount: fields.length
    }
  };
}

function extractMenuSchema($) {
  const menuCandidates = $('aside, nav, [role="navigation"], [role="menu"], .ant-menu, .drawer-menu, .sidenav-menu').filter((_, element) => {
    return $(element).find('a, [role="menuitem"], .nav-link, .ant-menu-item').length >= 2;
  }).toArray().map((element) => {
    const $element = $(element);
    const tagName = String(element?.tagName || element?.name || '').toLowerCase();
    const identity = [
      tagName,
      $element.attr('id'),
      $element.attr('class'),
      $element.attr('role'),
      $element.attr('aria-label')
    ].join(' ').toLowerCase();
    const items = $element.find('a, [role="menuitem"], .nav-link, .ant-menu-item').toArray();
    const activeCount = items.filter((item) => /(^|\s)(active|selected|ant-menu-item-selected)(\s|$)/i.test(String($(item).attr('class') || ''))).length;
    let score = items.length;
    if (tagName === 'aside') score += 34;
    if (/(^|\s|[-_])(aside|drawer|sider|sidebar|side-nav|sidenav|side-menu|ant-menu|drawer-menu)(\s|[-_]|$)/i.test(identity)) score += 28;
    if (/(^|\s|[-_])(menu|navigation|nav)(\s|[-_]|$)/i.test(identity)) score += 8;
    if (activeCount > 0) score += 10;
    if (/(^|\s|[-_])(top|topbar|top-app-bar|app-bar|navbar|toolbar|header)(\s|[-_]|$)/i.test(identity) && tagName !== 'aside') score -= 26;
    return { $element, score };
  }).sort((left, right) => right.score - left.score);

  const $menuRoot = menuCandidates[0]?.$element || $();
  if (!$menuRoot.length) {
    return null;
  }

  const items = [];
  const seen = new Set();
  $menuRoot.find('a, [role="menuitem"], .nav-link, .ant-menu-item').toArray().forEach((itemElement, index) => {
    const $item = $(itemElement);
    const className = String($item.attr('class') || '');
    if (/(^|\s)d-(?:none|sm-none|md-none|lg-none|xl-none|xxl-none)(\s|$)/.test(className)) return;
    const iconHint = normalizeText($item.find('i, svg, [role="img"], .material-icons, .material-symbols, .svg-inline--fa').first().attr('aria-label') || $item.find('i, .material-icons, .material-symbols').first().text(), 40);
    const $labelClone = $item.clone();
    $labelClone.find('i, svg, [role="img"], .material-icons, .material-symbols, .svg-inline--fa').remove();
    const label = normalizeText($labelClone.text() || $item.text(), 80);
    if (!label || label.length > 80) return;
    const id = uniqueId(label, seen, `menu-${index + 1}`);
    items.push({
      id,
      label,
      iconHint,
      href: String($item.attr('href') || '').trim(),
      active: /(^|\s)(active|selected|ant-menu-item-selected)(\s|$)/i.test(String($item.attr('class') || '')),
      children: []
    });
  });

  if (!items.length) {
    return null;
  }

  return {
    id: 'primary-menu',
    selector: selectorFor($menuRoot, 'nav'),
    confidence: items.length >= 3 ? 0.8 : 0.66,
    items: items.slice(0, 80),
    diagnostics: {
      source: 'dom-navigation',
      itemCount: items.length
    }
  };
}

function extractSemanticSchemas(pageIR = {}) {
  const html = (Array.isArray(pageIR.sections) ? pageIR.sections : [])
    .map((section) => String(section?.previewMarkup || section?.markup || '').trim())
    .filter(Boolean)
    .join('\n');
  if (!html.trim()) {
    return {
      version: 1,
      status: 'unavailable',
      tableSchema: null,
      filterSchema: null,
      menuSchema: null,
      diagnostics: ['no-preview-markup']
    };
  }

  const $ = cheerio.load(`<div id="__protorec-semantic-root">${html}</div>`, { decodeEntities: false });
  const tableSchema = extractTableSchema($);
  const filterSchema = extractFilterSchema($);
  const menuSchema = extractMenuSchema($);

  return {
    version: 1,
    status: tableSchema || filterSchema || menuSchema ? 'available' : 'low-confidence',
    tableSchema,
    filterSchema,
    menuSchema,
    diagnostics: [
      tableSchema ? 'table-schema-extracted' : 'table-schema-unavailable',
      filterSchema ? 'filter-schema-extracted' : 'filter-schema-unavailable',
      menuSchema ? 'menu-schema-extracted' : 'menu-schema-unavailable'
    ]
  };
}

module.exports = {
  extractSemanticSchemas
};
