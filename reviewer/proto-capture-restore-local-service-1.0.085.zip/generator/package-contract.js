const fs = require('fs-extra');
const path = require('path');

const { PAGES_ROOT, PROTOCOL_VERSION } = require('./config');
const { sanitizeSegment } = require('./naming');

function toPosixPath(filePath = '') {
  return String(filePath || '').split(path.sep).join('/');
}

function buildRootPageDir(pageIR) {
  return path.join(PAGES_ROOT, pageIR.baseRouteId || pageIR.routeId);
}

function buildRelativePath(rootDir, targetPath) {
  if (!rootDir || !targetPath) {
    return '';
  }

  return toPosixPath(path.relative(rootDir, targetPath));
}

function buildViewTitle(pageIR, view = {}) {
  if (String(view.id || '').trim() === String(pageIR?.view?.defaultViewId || '').trim()) {
    return String(pageIR.pageTitle || '').trim();
  }

  return String(view.label || view.title || pageIR.pageTitle || '').trim();
}

function buildPagesRegistry(pageIR, outputPaths = {}, existingRegistry = {}) {
  const rootPageDir = buildRootPageDir(pageIR);
  const currentEntryPath = buildRelativePath(rootPageDir, outputPaths.entryFilePath || path.join(outputPaths.pageDir, 'index.tsx'));
  const currentSpecPath = buildRelativePath(rootPageDir, outputPaths.specFilePath || path.join(outputPaths.pageDir, 'spec.md'));
  const existingViews = Array.isArray(existingRegistry?.views) ? existingRegistry.views : [];
  const expectedRegistryPageId = sanitizeSegment(String(pageIR.baseRouteId || pageIR.routeId).replace(/[\\/]+/g, '-'))
    || pageIR.pageSlug;
  const defaultViewTitle = existingViews.find((view) => view?.id === pageIR.view.defaultViewId)?.title;
  const registryPageId = existingRegistry?.pageId && !/-subviews-/.test(String(existingRegistry.pageId))
    ? existingRegistry.pageId
    : expectedRegistryPageId;
  const registryTitle = pageIR.view.viewId === pageIR.view.defaultViewId
    ? pageIR.pageTitle
    : (defaultViewTitle || existingRegistry?.title || pageIR.pageTitle);
  const nextView = {
    id: pageIR.view.viewId,
    label: pageIR.view.viewLabel,
    kind: pageIR.view.viewKind,
    order: pageIR.view.viewOrder,
    routeId: pageIR.routeId,
    entryPath: currentEntryPath,
    specPath: currentSpecPath,
    isDefault: pageIR.view.viewId === pageIR.view.defaultViewId,
    title: buildViewTitle(pageIR, pageIR.view)
  };
  const assets = Array.isArray(pageIR.assets) ? pageIR.assets : [];
  const imageCount = assets.filter((asset) => asset.category !== 'fonts').length;
  const fontCount = assets.filter((asset) => asset.category === 'fonts').length;

  const mergedViews = existingViews
    .filter((view) => view && view.id !== nextView.id)
    .concat(nextView)
    .sort((left, right) => {
      if ((left.order || 0) !== (right.order || 0)) {
        return (left.order || 0) - (right.order || 0);
      }

      return String(left.id || '').localeCompare(String(right.id || ''));
    });

  return {
    protocolVersion: PROTOCOL_VERSION,
    pageId: registryPageId,
    baseRouteId: pageIR.baseRouteId || pageIR.routeId,
    title: registryTitle,
    defaultViewId: pageIR.view.defaultViewId,
    sourceUrl: pageIR.sourceUrl || '',
    packageLevel: 1,
    resources: {
      imagesDir: buildRelativePath(rootPageDir, outputPaths.imagesDir || ''),
      fontsDir: buildRelativePath(rootPageDir, outputPaths.fontsDir || ''),
      imageCount,
      fontCount,
      failedAssetCount: Number(pageIR?.assetSummary?.failedAssetCount || 0)
    },
    views: mergedViews
  };
}

async function writePagesRegistry(pageIR, outputPaths = {}) {
  const rootPageDir = buildRootPageDir(pageIR);
  const registryPath = path.join(rootPageDir, 'pages.json');

  await fs.ensureDir(rootPageDir);

  let existingRegistry = {};
  if (await fs.pathExists(registryPath)) {
    try {
      existingRegistry = await fs.readJson(registryPath);
    } catch (_error) {
      existingRegistry = {};
    }
  }

  const nextRegistry = buildPagesRegistry(pageIR, outputPaths, existingRegistry);
  await fs.writeJson(registryPath, nextRegistry, { spaces: 2 });

  return {
    registryPath,
    registry: nextRegistry
  };
}

module.exports = {
  buildPagesRegistry,
  buildRelativePath,
  buildRootPageDir,
  toPosixPath,
  writePagesRegistry
};
