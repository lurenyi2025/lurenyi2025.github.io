const path = require('path');
const { PROTOCOL_VERSION } = require('./config');

function trimText(value = '', maxLength = 120) {
  const normalized = String(value || '').replace(/\s+/g, ' ').trim();
  if (!normalized) return '';
  return normalized.length <= maxLength ? normalized : `${normalized.slice(0, maxLength)}...`;
}

function toPosixPath(filePath = '') {
  return String(filePath || '').split(path.sep).join('/');
}

function relativeFrom(rootDir, targetPath) {
  if (!rootDir || !targetPath) return '';
  return toPosixPath(path.relative(rootDir, targetPath));
}

function lineOrUnknown(value, fallback = '暂未从抓取证据中稳定识别。') {
  const normalized = String(value || '').trim();
  return normalized || fallback;
}

function buildOverviewLines(pageIR) {
  const viewLabel = String(pageIR?.view?.viewLabel || '').trim();
  const sourceUrl = String(pageIR?.sourceUrl || '').trim();
  return [
    `- 页面名称：${lineOrUnknown(pageIR.pageTitle, pageIR.pageSlug)}`,
    `- 当前视图：${viewLabel && viewLabel !== pageIR.pageTitle ? viewLabel : '默认视图'}`,
    `- 页面类型：${lineOrUnknown(pageIR.archetype, 'generic')}`,
    `- 来源地址：${sourceUrl || '未记录'}`,
    `- 还原状态：${lineOrUnknown(pageIR.readyState, 'unknown')}`,
    `- 置信度：${Number(pageIR?.confidence?.page || 0).toFixed(2)}`
  ];
}

function buildStructureLines(pageIR) {
  const sections = Array.isArray(pageIR.sections) ? pageIR.sections : [];
  if (!sections.length) {
    return ['- 暂未识别出稳定页面区块。后续编辑前应先补充分区。'];
  }

  return sections.slice(0, 12).map((section, index) => {
    const summary = trimText(section.summary || section.title || '', 100);
    const blockCount = Array.isArray(section.blocks) ? section.blocks.length : 0;
    const blockText = blockCount ? `，包含 ${blockCount} 个可识别子块` : '';
    return `- ${index + 1}. ${section.title || section.id}（${section.kind || 'section'}）${blockText}${summary ? `：${summary}` : ''}`;
  });
}

function buildContentLines(pageIR) {
  const sections = Array.isArray(pageIR.sections) ? pageIR.sections : [];
  const contentLines = [];

  sections.slice(0, 8).forEach((section) => {
    const blocks = Array.isArray(section.blocks) ? section.blocks : [];
    if (!blocks.length) {
      contentLines.push(`- ${section.title || section.id}：${trimText(section.summary || '该区域以整体 HTML 片段还原，细节内容需结合预览确认。', 120)}`);
      return;
    }

    const blockNames = blocks.slice(0, 5)
      .map((block) => block.title || block.id)
      .filter(Boolean)
      .join('、');
    contentLines.push(`- ${section.title || section.id}：包含 ${blockNames || '若干内容块'}。`);
  });

  return contentLines.length ? contentLines : ['- 暂未提取到稳定内容摘要，请以预览和证据包为准。'];
}

function buildRouteLines(pageIR, registry = null, outputPaths = {}) {
  const pageDir = outputPaths.pageDir || '';
  const rootPageDir = outputPaths.rootPageDir || pageDir;
  const views = Array.isArray(registry?.views) && registry.views.length
    ? registry.views
    : [{
      id: pageIR?.view?.viewId || 'default',
      label: pageIR?.view?.viewLabel || pageIR.pageTitle || '默认视图',
      routeId: pageIR?.routeId || '',
      entryPath: 'index.tsx',
      specPath: 'spec.md',
      isDefault: true
    }];

  return views.map((view) => {
    const entryPath = relativeFrom(pageDir, path.join(rootPageDir, view.entryPath || 'index.tsx')) || String(view.entryPath || 'index.tsx');
    const specPath = view.specPath
      ? (relativeFrom(pageDir, path.join(rootPageDir, view.specPath)) || String(view.specPath))
      : '';
    const flags = [view.isDefault ? '默认' : '', view.id === pageIR?.view?.viewId ? '当前' : ''].filter(Boolean).join('，');
    return `- ${view.label || view.id}：route=\`${view.routeId || ''}\`，entry=\`${entryPath}\`${specPath ? `，spec=\`${specPath}\`` : ''}${flags ? `（${flags}）` : ''}`;
  });
}

function buildInteractionLines(pageIR) {
  const interactions = Array.isArray(pageIR.interactions) ? pageIR.interactions : [];
  if (!interactions.length) {
    return ['- 未识别到稳定交互协议；当前页面可先按静态还原预览验收。'];
  }

  return interactions.slice(0, 10).map((interaction) => {
    const label = interaction.label || interaction.kind || interaction.id;
    const itemCount = Number(interaction.itemCount || 0);
    const mode = interaction.interactionMode || interaction.protocolLevel || 'local';
    return `- ${label}：类型 ${interaction.kind || 'unknown'}，所属区域 ${interaction.sectionId || 'unknown'}，项目数 ${itemCount}，模式 ${mode}。`;
  });
}

function formatTarget(target = {}) {
  const name = target.targetType === 'block'
    ? `${target.sectionId || 'section'}.${target.targetId || 'block'}`
    : (target.targetId || target.sectionId || 'section');
  const reason = Array.isArray(target.reasons) && target.reasons.length
    ? `，原因：${target.reasons.slice(0, 2).join('；')}`
    : '';
  return `- ${name}：风险 ${target.changeRisk || 'unknown'}，适合度 ${target.suitabilityScore || 0}${reason}`;
}

function buildEditableLines(pageIR) {
  const editability = pageIR.editability || {};
  const recommended = Array.isArray(editability.recommendedFirstEdits) ? editability.recommendedFirstEdits : [];
  const lowRisk = Array.isArray(editability.lowRiskTargets) ? editability.lowRiskTargets : [];
  const targets = recommended.concat(lowRisk).slice(0, 8);

  if (!targets.length) {
    return [
      '- 可优先修改页面文案、图片引用、按钮文字和低风险内容块。',
      '- 暂未识别到特别稳定的结构级编辑入口，较大结构调整前应先对照预览。'
    ];
  }

  return targets.map(formatTarget);
}

function buildResourceLines(pageIR, outputPaths = {}) {
  const pageDir = outputPaths.pageDir || '';
  const imagesDir = relativeFrom(pageDir, outputPaths.imagesDir || '') || 'assets/images';
  const fontsDir = relativeFrom(pageDir, outputPaths.fontsDir || '') || 'assets/fonts';
  const assets = Array.isArray(pageIR.assets) ? pageIR.assets : [];
  const imageCount = assets.filter((asset) => asset.category !== 'fonts').length;
  const fontCount = assets.filter((asset) => asset.category === 'fonts').length;
  const failedAssetCount = Number(pageIR?.assetSummary?.failedAssetCount || 0);

  return [
    `- 图片目录：\`${imagesDir}\`，当前本地化 ${imageCount} 个。`,
    `- 字体目录：\`${fontsDir}\`，当前本地化 ${fontCount} 个。`,
    `- 资源失败：${failedAssetCount} 个；如视觉缺图或字体不一致，请先查看 \`.protorec/pages/<slug>/capture-quality.json\`。`,
    '- 远程依赖：生成器会尽量本地化资源；无法下载的资源会在质量报告中记录。'
  ];
}

function buildAvoidLines(pageIR) {
  const avoidForNow = Array.isArray(pageIR?.editability?.avoidForNow) ? pageIR.editability.avoidForNow : [];
  const lines = avoidForNow.slice(0, 6).map(formatTarget);
  if (lines.length) return lines;

  return [
    '- 暂不建议直接改写整页 HTML 或删除带有 `data-protorec-*` 的交互标记。',
    '- 暂不建议在不了解资源来源时替换字体、图标雪碧图和复杂 canvas 区域。'
  ];
}

function buildChecklistLines(pageIR) {
  const hasAssets = Array.isArray(pageIR.assets) && pageIR.assets.length > 0;
  const hasInteractions = Array.isArray(pageIR.interactions) && pageIR.interactions.length > 0;
  return [
    '- [ ] 页面能通过 `/preview?path=<route>` 打开。',
    '- [ ] 首屏布局、主要区块位置、字体大小和颜色与来源页面接近。',
    hasAssets ? '- [ ] 关键图片、图标和字体资源已正常显示。' : '- [ ] 当前无本地资源或资源较少，确认不是漏抓导致。',
    hasInteractions ? '- [ ] tabs、dropdown、carousel、dismiss 等基础交互可用或有明确降级说明。' : '- [ ] 当前无稳定交互协议，按静态页面验收。',
    '- [ ] 修改本文件中的文案或内容意图后，AI 能据此更新页面包且预览不破坏。'
  ];
}

function emitSpec(pageIR, { registry = null, outputPaths = {} } = {}) {
  return `---
protocolVersion: ${PROTOCOL_VERSION}
pageSlug: ${pageIR.pageSlug}
pageTitle: ${pageIR.pageTitle}
baseRouteId: ${pageIR.baseRouteId}
routeId: ${pageIR.routeId}
viewId: ${pageIR.view.viewId}
viewLabel: ${pageIR.view.viewLabel}
defaultViewId: ${pageIR.view.defaultViewId}
sourceUrl: ${pageIR.sourceUrl}
---

# ${pageIR.pageTitle}

## 1. 页面概览
${buildOverviewLines(pageIR).join('\n')}

## 2. 页面结构
${buildStructureLines(pageIR).join('\n')}

## 3. 页面内容
${buildContentLines(pageIR).join('\n')}

## 4. 视图与跳转
${buildRouteLines(pageIR, registry, outputPaths).join('\n')}

## 5. 交互说明
${buildInteractionLines(pageIR).join('\n')}

## 6. 可修改内容
${buildEditableLines(pageIR).join('\n')}

## 7. 资源说明
${buildResourceLines(pageIR, outputPaths).join('\n')}

## 8. 暂不建议修改的部分
${buildAvoidLines(pageIR).join('\n')}

## 9. 验收清单
${buildChecklistLines(pageIR).join('\n')}
`;
}

module.exports = {
  emitSpec
};
