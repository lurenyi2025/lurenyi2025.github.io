const cheerio = require('cheerio');

const { isEditMapPilotPage } = require('./emit-edit-map');

const BLOCK_DEFINITIONS = [
  {
    blockId: 'table',
    semanticKey: 'tableSchema',
    fileName: 'fragments/table.tsx',
    semanticPath: 'semantic/table.ts',
    structuralIds: ['data-table'],
    structuralKinds: ['data-table', 'table'],
    structuralNames: ['DataTableFragment'],
    fallbackSelectors: [
      '.ant-table-wrapper',
      '#datatablesSimple',
      'table',
      '[role="table"]',
      '.datatable-table'
    ]
  },
  {
    blockId: 'filter',
    semanticKey: 'filterSchema',
    fileName: 'fragments/filter.tsx',
    semanticPath: 'semantic/filter.ts',
    structuralIds: ['filter-form'],
    structuralKinds: ['filter-form', 'filter'],
    structuralNames: ['FilterFormFragment'],
    fallbackSelectors: [
      'form',
      '.ant-pro-query-filter',
      '.ant-form',
      '.filter',
      '.search'
    ]
  },
  {
    blockId: 'menu',
    semanticKey: 'menuSchema',
    fileName: 'fragments/menu.tsx',
    semanticPath: 'semantic/menu.ts',
    structuralIds: ['sider-nav', 'menu', 'drawer-menu'],
    structuralKinds: ['sider-nav', 'sidebar', 'menu', 'navigation'],
    structuralNames: ['SiderNavFragment', 'MenuFragment'],
    fallbackSelectors: [
      '#drawerAccordion',
      'aside',
      'nav',
      '[role="navigation"]',
      '[role="menu"]',
      '.ant-menu',
      '.drawer-menu',
      '.sidenav-menu'
    ]
  }
];

function escapeSourceJson(value) {
  return JSON.stringify(value)
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e')
    .replace(/\u2028/g, '\\u2028')
    .replace(/\u2029/g, '\\u2029');
}

function normalizeKey(value = '') {
  return String(value || '').trim().toLowerCase();
}

function compactArray(values = []) {
  return Array.from(new Set(
    values
      .map((value) => String(value || '').trim())
      .filter(Boolean)
  ));
}

function buildPreviewBodyMarkup(pageIR = {}) {
  if (pageIR?.structuralDecomposition?.previewBodyMarkup) {
    return String(pageIR.structuralDecomposition.previewBodyMarkup || '');
  }

  return (Array.isArray(pageIR.sections) ? pageIR.sections : [])
    .map((section) => String(section?.previewMarkup || section?.markup || '').trim())
    .filter(Boolean)
    .join('\n');
}

function matchesStructuralFragment(fragment = {}, definition = {}) {
  const id = normalizeKey(fragment.id);
  const kind = normalizeKey(fragment.kind || fragment.sectionKind);
  const name = String(fragment.name || '').trim();

  return definition.structuralIds.includes(id)
    || definition.structuralKinds.includes(kind)
    || definition.structuralNames.includes(name);
}

function findUniqueStructuralFragment(pageIR = {}, definition = {}) {
  const fragments = Array.isArray(pageIR?.structuralDecomposition?.fragments)
    ? pageIR.structuralDecomposition.fragments
    : [];
  const matches = fragments.filter((fragment) => (
    matchesStructuralFragment(fragment, definition)
    && String(fragment?.html || '').trim()
  ));

  if (matches.length !== 1) {
    return {
      status: 'skipped',
      reason: matches.length > 1 ? 'ambiguous-structural-fragment' : 'structural-fragment-unavailable',
      matchCount: matches.length
    };
  }

  return {
    status: 'available',
    source: 'structural-fragment',
    html: String(matches[0].html || ''),
    selectorHint: String(matches[0].selectorHint || ''),
    markerName: String(matches[0].name || ''),
    diagnostics: {
      fragmentName: String(matches[0].name || ''),
      fragmentKind: String(matches[0].kind || ''),
      confidence: Number(matches[0].confidence || 0)
    }
  };
}

function selectUniqueOuterHtml(markup = '', selectors = []) {
  const sourceMarkup = String(markup || '').trim();
  if (!sourceMarkup) {
    return {
      status: 'skipped',
      reason: 'preview-markup-unavailable'
    };
  }

  const $ = cheerio.load(`<div id="__protorec-fragment-root">${sourceMarkup}</div>`, {
    decodeEntities: false
  });

  for (const selector of compactArray(selectors)) {
    let matches = null;
    try {
      matches = $(`#__protorec-fragment-root`).find(selector);
    } catch (_error) {
      continue;
    }

    if (matches.length === 1) {
      return {
        status: 'available',
        source: 'selector',
        selector,
        markerName: '',
        html: $.html(matches.first())
      };
    }

    if (matches.length > 1) {
      return {
        status: 'skipped',
        reason: 'ambiguous-selector-match',
        selector,
        matchCount: matches.length
      };
    }
  }

  return {
    status: 'skipped',
    reason: 'selector-match-unavailable'
  };
}

function resolveFragmentHtml(pageIR = {}, definition = {}, schema = {}) {
  const structural = findUniqueStructuralFragment(pageIR, definition);
  if (structural.status === 'available') {
    return structural;
  }

  const selectors = [
    schema.selector,
    ...definition.fallbackSelectors
  ];
  const selected = selectUniqueOuterHtml(buildPreviewBodyMarkup(pageIR), selectors);
  if (selected.status === 'available') {
    return selected;
  }

  return {
    status: 'skipped',
    reason: selected.reason || structural.reason || 'fragment-source-unavailable',
    selector: selected.selector || '',
    matchCount: selected.matchCount || structural.matchCount || 0
  };
}

function selectorExistsInHtml(html = '', selector = '') {
  const normalizedSelector = String(selector || '').trim();
  if (!normalizedSelector) {
    return true;
  }

  const sourceHtml = String(html || '').trim();
  if (!sourceHtml) {
    return false;
  }

  try {
    const $ = cheerio.load(`<div id="__protorec-fragment-binding-root">${sourceHtml}</div>`, {
      decodeEntities: false
    });
    return $(`#__protorec-fragment-binding-root`).find(normalizedSelector).length > 0;
  } catch (_error) {
    return false;
  }
}

function createFragmentRecord(pageIR = {}, definition = {}, schema = {}) {
  const resolved = resolveFragmentHtml(pageIR, definition, schema);
  if (resolved.status !== 'available') {
    return null;
  }

  const schemaSelector = String(schema.selector || '').trim();
  if (schemaSelector && !selectorExistsInHtml(resolved.html, schemaSelector)) {
    return null;
  }

  return {
    blockId: definition.blockId,
    fileName: definition.fileName,
    semanticPath: definition.semanticPath,
    semanticType: definition.blockId,
    rootSelector: String(schema.selector || resolved.selector || resolved.selectorHint || '').trim(),
    source: resolved.source,
    selector: String(resolved.selector || ''),
    markerName: String(resolved.markerName || resolved.diagnostics?.fragmentName || ''),
    html: resolved.html,
    diagnostics: resolved.diagnostics || {
      selector: String(resolved.selector || ''),
      confidence: Number(schema.confidence || 0)
    }
  };
}

function collectPageFragments(pageIR = {}) {
  if (!isEditMapPilotPage(pageIR)) {
    return [];
  }

  const schemas = pageIR.semanticSchemas || {};
  return BLOCK_DEFINITIONS
    .map((definition) => {
      const schema = schemas[definition.semanticKey];
      if (!schema) {
        return null;
      }
      return createFragmentRecord(pageIR, definition, schema);
    })
    .filter(Boolean);
}

function emitFragmentSource(fragment = {}) {
  return `export const blockId = ${escapeSourceJson(fragment.blockId)};
export const semanticType = ${escapeSourceJson(fragment.semanticType)};
export const semanticPath = ${escapeSourceJson(fragment.semanticPath)};
export const rootSelector = ${escapeSourceJson(fragment.rootSelector)};
export const fragmentSource = ${escapeSourceJson(fragment.source)};
export const fragmentHtml = ${escapeSourceJson(fragment.html)};
export const diagnostics = ${escapeSourceJson(fragment.diagnostics || {})} as const;

export const editRouteLiteFragment = {
  blockId,
  semanticType,
  semanticPath,
  rootSelector,
  fragmentSource,
  fragmentHtml,
  diagnostics
} as const;

export default editRouteLiteFragment;
`;
}

function structuralFragmentByName(pageIR = {}) {
  const fragments = Array.isArray(pageIR?.structuralDecomposition?.fragments)
    ? pageIR.structuralDecomposition.fragments
    : [];

  return new Map(
    fragments
      .filter((fragment) => String(fragment?.name || '').trim())
      .map((fragment) => [String(fragment.name), fragment])
  );
}

function createStructuralPageShell(pageIR = {}, fragments = []) {
  const decomposition = pageIR?.structuralDecomposition || null;
  const rootFragmentName = String(decomposition?.rootFragmentName || '').trim();
  const byName = structuralFragmentByName(pageIR);
  const rootFragment = byName.get(rootFragmentName);
  if (!rootFragmentName || !rootFragment?.html) {
    return null;
  }

  const routeFragmentMarkers = {};
  fragments.forEach((fragment) => {
    if (!fragment.markerName) {
      return;
    }
    routeFragmentMarkers[fragment.blockId] = [fragment.markerName];
  });

  if (fragments.some((fragment) => fragment.source !== 'structural-fragment' || !fragment.markerName)) {
    return null;
  }

  const editableMarkerNames = new Set(
    Object.values(routeFragmentMarkers).flat()
  );
  const fallbackFragments = {};
  byName.forEach((fragment, name) => {
    if (name === rootFragmentName || editableMarkerNames.has(name)) {
      return;
    }
    if (String(fragment?.html || '').trim()) {
      fallbackFragments[name] = String(fragment.html || '');
    }
  });

  return {
    pageShellHtml: String(rootFragment.html || ''),
    routeFragmentMarkers,
    fallbackFragments,
    diagnostics: {
      source: 'structural-decomposition',
      rootFragmentName,
      routeFragmentCount: fragments.length,
      fallbackFragmentCount: Object.keys(fallbackFragments).length
    }
  };
}

function createSelectorPageShell(pageIR = {}, fragments = []) {
  const sourceMarkup = buildPreviewBodyMarkup(pageIR);
  if (!String(sourceMarkup || '').trim()) {
    return null;
  }

  if (fragments.some((fragment) => fragment.source !== 'selector' || !fragment.selector)) {
    return null;
  }

  const $ = cheerio.load(`<div id="__protorec-page-shell-root">${sourceMarkup}</div>`, {
    decodeEntities: false
  });

  for (const fragment of fragments) {
    let matches = null;
    try {
      matches = $('#__protorec-page-shell-root').find(fragment.selector);
    } catch (_error) {
      return null;
    }

    if (matches.length !== 1) {
      return null;
    }

    matches.first().replaceWith(`<!--__PROTOREC_ROUTE_FRAGMENT:${fragment.blockId}__-->`);
  }

  return {
    pageShellHtml: $('#__protorec-page-shell-root').html() || '',
    routeFragmentMarkers: {},
    fallbackFragments: {},
    diagnostics: {
      source: 'selector-replacement',
      routeFragmentCount: fragments.length,
      fallbackFragmentCount: 0
    }
  };
}

function buildPageShellRecord(pageIR = {}, fragments = collectPageFragments(pageIR)) {
  if (!isEditMapPilotPage(pageIR) || !fragments.length) {
    return null;
  }

  return createStructuralPageShell(pageIR, fragments)
    || createSelectorPageShell(pageIR, fragments);
}

function emitPageShellSource(shell = {}) {
  return `export const pageShellHtml = ${escapeSourceJson(shell.pageShellHtml || '')};
export const routeFragmentMarkers = ${escapeSourceJson(shell.routeFragmentMarkers || {})} as const;
export const fallbackFragments = ${escapeSourceJson(shell.fallbackFragments || {})} as const;
export const pageFragmentDiagnostics = ${escapeSourceJson(shell.diagnostics || {})} as const;
`;
}

function emitPageFragmentFiles(pageIR = {}, fragments = collectPageFragments(pageIR)) {
  const files = fragments.map((fragment) => [
    fragment.fileName,
    emitFragmentSource(fragment)
  ]);

  const shell = buildPageShellRecord(pageIR, fragments);
  if (shell) {
    files.unshift(['fragments/page.tsx', emitPageShellSource(shell)]);
  }

  return files;
}

function emitPageFragments(pageIR = {}) {
  return emitPageFragmentFiles(pageIR, collectPageFragments(pageIR));
}

module.exports = {
  buildPageShellRecord,
  collectPageFragments,
  emitPageFragmentFiles,
  emitPageFragments
};
