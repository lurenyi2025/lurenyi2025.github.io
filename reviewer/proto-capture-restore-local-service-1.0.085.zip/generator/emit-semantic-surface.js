function escapeSourceJson(value) {
  return JSON.stringify(value, null, 2)
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e')
    .replace(/\u2028/g, '\\u2028')
    .replace(/\u2029/g, '\\u2029');
}

function hasSemanticSurface(pageIR) {
  const schemas = pageIR?.semanticSchemas || {};
  return Boolean(schemas.tableSchema || schemas.filterSchema || schemas.menuSchema);
}

function emitTableSurface(tableSchema) {
  const columns = Array.isArray(tableSchema?.columns) ? tableSchema.columns : [];
  const rows = Array.isArray(tableSchema?.rows) ? tableSchema.rows : [];
  const actions = Array.isArray(tableSchema?.actions) ? tableSchema.actions : [];

  return `export type SemanticTableColumn = {
  id: string;
  label: string;
  kind: 'text' | 'number' | 'date' | 'status' | 'action' | 'unknown';
  sourceIndex: number;
  widthHint?: string;
  sortable?: boolean;
  defaultValue?: string;
};

export type SemanticTableRow = {
  id: string;
  cells: Record<string, string>;
};

export type SemanticTableAction = {
  id: string;
  label: string;
  kind?: string;
  href?: string;
};

export const tableColumns: SemanticTableColumn[] = ${escapeSourceJson(columns)} as SemanticTableColumn[];

export const tableRows: SemanticTableRow[] = ${escapeSourceJson(rows)} as SemanticTableRow[];

export const tableActions: SemanticTableAction[] = ${escapeSourceJson(actions)} as SemanticTableAction[];

export const tableSchema = {
  id: ${escapeSourceJson(tableSchema?.id || 'primary-table')},
  selector: ${escapeSourceJson(tableSchema?.selector || '')},
  confidence: ${Number(tableSchema?.confidence || 0)},
  columns: tableColumns,
  rows: tableRows,
  actions: tableActions,
  diagnostics: ${escapeSourceJson(tableSchema?.diagnostics || {})}
};
`;
}

function emitFilterSurface(filterSchema) {
  const fields = Array.isArray(filterSchema?.fields) ? filterSchema.fields : [];

  return `export type SemanticFilterField = {
  id: string;
  label: string;
  control: 'input' | 'select' | 'date' | 'daterange' | 'checkbox' | 'unknown';
  placeholder?: string;
  options?: string[];
};

export const filterFields: SemanticFilterField[] = ${escapeSourceJson(fields)} as SemanticFilterField[];

export const filterSchema = {
  id: ${escapeSourceJson(filterSchema?.id || 'primary-filter')},
  selector: ${escapeSourceJson(filterSchema?.selector || '')},
  confidence: ${Number(filterSchema?.confidence || 0)},
  fields: filterFields,
  collapsible: ${Boolean(filterSchema?.collapsible)},
  defaultCollapsed: ${Boolean(filterSchema?.defaultCollapsed)},
  diagnostics: ${escapeSourceJson(filterSchema?.diagnostics || {})}
};
`;
}

function emitMenuSurface(menuSchema) {
  const items = Array.isArray(menuSchema?.items) ? menuSchema.items : [];

  return `export type SemanticMenuItem = {
  id: string;
  label: string;
  iconHint?: string;
  href?: string;
  active?: boolean;
  children?: SemanticMenuItem[];
};

export const menuItems: SemanticMenuItem[] = ${escapeSourceJson(items)} as SemanticMenuItem[];

export const menuSchema = {
  id: ${escapeSourceJson(menuSchema?.id || 'primary-menu')},
  selector: ${escapeSourceJson(menuSchema?.selector || '')},
  confidence: ${Number(menuSchema?.confidence || 0)},
  items: menuItems,
  diagnostics: ${escapeSourceJson(menuSchema?.diagnostics || {})}
};
`;
}

function emitSemanticIndex(schema) {
  const imports = [];
  const schemaEntries = [];

  if (schema.tableSchema) {
    imports.push("import { tableSchema } from './table';");
    schemaEntries.push('  tableSchema,');
  } else {
    schemaEntries.push('  tableSchema: null,');
  }

  if (schema.filterSchema) {
    imports.push("import { filterSchema } from './filter';");
    schemaEntries.push('  filterSchema,');
  } else {
    schemaEntries.push('  filterSchema: null,');
  }

  if (schema.menuSchema) {
    imports.push("import { menuSchema } from './menu';");
    schemaEntries.push('  menuSchema,');
  } else {
    schemaEntries.push('  menuSchema: null,');
  }

  return `${imports.join('\n')}

export const semanticSchemas = {
  version: ${Number(schema.version || 1)},
  status: ${escapeSourceJson(schema.status || 'available')},
${schemaEntries.join('\n')}
  diagnostics: ${escapeSourceJson(schema.diagnostics || [])}
};
`;
}

function emitEditNotes(pageIR) {
  const slug = pageIR?.pageSlug || pageIR?.routeId || 'unknown';
  const schema = pageIR?.semanticSchemas || {};
  const files = [
    schema.tableSchema ? '- `table.ts`: table columns, row sample values, and actions.' : '',
    schema.filterSchema ? '- `filter.ts`: filter fields and filter collapsed defaults.' : '',
    schema.menuSchema ? '- `menu.ts`: navigation labels, links, active state, and hierarchy.' : ''
  ].filter(Boolean).join('\n');

  return `# Semantic Edit Surface: ${slug}

These files are generated from \`.protorec/pages/${slug}/semantic-schema.json\`.

For high-frequency list-page edits, IDE AI should start here before reading the large generated \`index.tsx\`.

${files || '- No schema-backed semantic files were emitted.'}

Editing these files can affect the preview because \`index.tsx\` imports \`semanticSchemas\` from \`./semantic\` when this surface exists.

Keep edits schema-shaped:

- Add table columns by editing \`tableColumns\` and row cell values in \`tableRows\`.
- Add filter fields by editing \`filterFields\`.
- Add menu entries by editing \`menuItems\`.
- Preserve \`id\` values when modifying existing fields so semantic validation can match the same structures.

Do not edit \`.protorec/\` evidence as source. It is validation evidence, not the page package.
`;
}

function emitSemanticSurface(pageIR) {
  if (!hasSemanticSurface(pageIR)) {
    return [];
  }

  const schema = pageIR.semanticSchemas || {};
  const files = [
    ['semantic/index.ts', emitSemanticIndex(schema)],
    ['semantic/edit-notes.md', emitEditNotes(pageIR)]
  ];

  if (schema.tableSchema) {
    files.push(['semantic/table.ts', emitTableSurface(schema.tableSchema)]);
  }

  if (schema.filterSchema) {
    files.push(['semantic/filter.ts', emitFilterSurface(schema.filterSchema)]);
  }

  if (schema.menuSchema) {
    files.push(['semantic/menu.ts', emitMenuSurface(schema.menuSchema)]);
  }

  return files;
}

module.exports = {
  emitSemanticSurface,
  hasSemanticSurface
};
