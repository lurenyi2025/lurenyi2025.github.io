const cheerio = require('cheerio');

const PILOT_ROUTE_IDS = new Set([
  'table-list',
  'plugins-data-tables-html'
]);

const PRESERVED_SCHEMA_KEYS = [
  'tableSchema',
  'filterSchema',
  'menuSchema'
];

function normalizeRouteId(value = '') {
  return String(value || '').trim();
}

function isEditRouteLitePilotSlug(value = '') {
  return PILOT_ROUTE_IDS.has(normalizeRouteId(value));
}

function collectPreservedRestoreNodeIds(semanticSchemas = {}) {
  const ids = new Set();

  PRESERVED_SCHEMA_KEYS.forEach((schemaKey) => {
    const selector = String(semanticSchemas?.[schemaKey]?.selector || '');
    selector.replace(/\[data-restore-node-id=(["']?)([^"'\]]+)\1\]/g, (_match, _quote, id) => {
      const normalizedId = String(id || '').trim();
      if (normalizedId) {
        ids.add(normalizedId);
      }
      return _match;
    });
  });

  return ids;
}

function shouldRemoveAttribute(name, value, preserveRestoreNodeIds) {
  const attributeName = String(name || '');
  if (/^data-protorec-/.test(attributeName)) {
    return true;
  }

  if (!/^data-restore-/.test(attributeName)) {
    return false;
  }

  return attributeName !== 'data-restore-node-id'
    || !preserveRestoreNodeIds.has(String(value || '').trim());
}

function compactEditRouteLiteHtml(html = '', options = {}) {
  const sourceHtml = String(html || '');
  if (!sourceHtml.trim()) {
    return sourceHtml;
  }

  const preserveRestoreNodeIds = options.preserveRestoreNodeIds instanceof Set
    ? options.preserveRestoreNodeIds
    : new Set();
  const $ = cheerio.load(`<div id="__protorec-edit-route-lite-compact-root">${sourceHtml}</div>`, {
    decodeEntities: false
  });
  const $root = $('#__protorec-edit-route-lite-compact-root');

  $root.find('*').each((_, element) => {
    const $element = $(element);
    Object.entries(element.attribs || {}).forEach(([name, value]) => {
      if (shouldRemoveAttribute(name, value, preserveRestoreNodeIds)) {
        $element.removeAttr(name);
      }
    });
  });

  return $root.html() || sourceHtml;
}

function updateHtmlLengthFields(target = {}, html) {
  const htmlLength = String(html || '').length;
  target.html = html;
  target.htmlLength = htmlLength;

  if (target.stats && typeof target.stats === 'object') {
    target.stats.htmlLength = htmlLength;
  }
  if (target.diagnostics?.structure && typeof target.diagnostics.structure === 'object') {
    target.diagnostics.structure.htmlLength = htmlLength;
  }
  target.diagnostics = {
    ...(target.diagnostics || {}),
    compaction: {
      ...(target.diagnostics?.compaction || {}),
      strategy: 'edit-route-lite-strip-restore-measurement-attrs',
      htmlLength
    }
  };

  return target;
}

function compactSection(section = {}, compactedByName) {
  const name = String(section?.componentName || '').trim();
  const compactedHtml = compactedByName.get(name);
  if (!compactedHtml) {
    return section;
  }

  const nextSection = {
    ...section,
    markup: compactedHtml,
    previewMarkup: compactedHtml,
    stats: {
      ...(section.stats || {}),
      htmlLength: compactedHtml.length
    },
    diagnostics: {
      ...(section.diagnostics || {}),
      structure: {
        ...(section.diagnostics?.structure || {}),
        htmlLength: compactedHtml.length
      },
      compaction: {
        strategy: 'edit-route-lite-strip-restore-measurement-attrs',
        htmlLength: compactedHtml.length
      }
    }
  };

  return nextSection;
}

function markerPattern() {
  return /<!--__PROTOREC_FRAGMENT:([A-Za-z0-9_]+)__-->/g;
}

function replaceFragmentMarkers(markup, fragmentByName, depth = 0) {
  if (depth > 20) {
    return String(markup || '');
  }

  return String(markup || '').replace(markerPattern(), (_match, name) => (
    replaceFragmentMarkers(fragmentByName.get(name) || '', fragmentByName, depth + 1)
  ));
}

function calculateUnclassifiedHtmlLength(appShellHtml = '') {
  return String(appShellHtml || '')
    .replace(markerPattern(), '')
    .trim()
    .length;
}

function compactEditRouteLiteStructuralResult(structuralResult = {}, options = {}) {
  const pageSlug = normalizeRouteId(options.pageSlug);
  if (!isEditRouteLitePilotSlug(pageSlug) || !structuralResult?.structuralDecomposition) {
    return structuralResult;
  }

  const preserveRestoreNodeIds = collectPreservedRestoreNodeIds(options.semanticSchemas || {});
  const sourceFragments = Array.isArray(structuralResult.structuralDecomposition.fragments)
    ? structuralResult.structuralDecomposition.fragments
    : [];
  const compactedByName = new Map();

  const compactedFragments = sourceFragments.map((fragment) => {
    const name = String(fragment?.name || '').trim();
    const sourceHtml = String(fragment?.html || '');
    const compactedHtml = compactEditRouteLiteHtml(sourceHtml, { preserveRestoreNodeIds });
    if (name && compactedHtml) {
      compactedByName.set(name, compactedHtml);
    }
    return updateHtmlLengthFields({ ...fragment }, compactedHtml);
  });

  const rootFragmentName = String(structuralResult.structuralDecomposition.rootFragmentName || '').trim();
  const rootHtml = compactedByName.get(rootFragmentName) || '';
  const renderedHtml = replaceFragmentMarkers(rootHtml, compactedByName);
  const unclassifiedHtmlLength = calculateUnclassifiedHtmlLength(rootHtml);

  const compactedSections = (Array.isArray(structuralResult.sections) ? structuralResult.sections : [])
    .map((section) => compactSection(section, compactedByName));

  const compactedSectionMapFragments = (Array.isArray(structuralResult.sectionMap?.fragments)
    ? structuralResult.sectionMap.fragments
    : []
  ).map((fragment) => {
    const name = String(fragment?.name || '').trim();
    const compactedHtml = compactedByName.get(name);
    if (!compactedHtml) {
      return fragment;
    }

    return {
      ...fragment,
      htmlLength: compactedHtml.length,
      compaction: {
        strategy: 'edit-route-lite-strip-restore-measurement-attrs',
        htmlLength: compactedHtml.length
      }
    };
  });

  return {
    ...structuralResult,
    sections: compactedSections,
    sectionMap: {
      ...(structuralResult.sectionMap || {}),
      fragments: compactedSectionMapFragments,
      unclassifiedHtmlLength,
      diagnostics: {
        ...(structuralResult.sectionMap?.diagnostics || {}),
        renderedHtmlLength: renderedHtml.length,
        shellHtmlLength: rootHtml.length,
        unclassifiedHtmlLength,
        compaction: {
          strategy: 'edit-route-lite-strip-restore-measurement-attrs',
          preserveRestoreNodeIdCount: preserveRestoreNodeIds.size
        }
      }
    },
    structuralDecomposition: {
      ...structuralResult.structuralDecomposition,
      fragments: compactedFragments,
      previewBodyMarkup: renderedHtml,
      diagnostics: {
        ...(structuralResult.structuralDecomposition.diagnostics || {}),
        renderedHtmlLength: renderedHtml.length,
        shellHtmlLength: rootHtml.length,
        unclassifiedHtmlLength,
        compaction: {
          strategy: 'edit-route-lite-strip-restore-measurement-attrs',
          preserveRestoreNodeIdCount: preserveRestoreNodeIds.size
        }
      }
    }
  };
}

module.exports = {
  collectPreservedRestoreNodeIds,
  compactEditRouteLiteHtml,
  compactEditRouteLiteStructuralResult,
  isEditRouteLitePilotSlug
};
