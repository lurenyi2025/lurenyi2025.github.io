const MIGRATION_ERROR_CODE = 'legacy_ai_rewrite_pack_retired';
const MIGRATION_ERROR_MESSAGE = [
  'BLOCKED: legacy ai-rewrite/rewrite-pack route is retired.',
  'Do not read or write src/pages/<slug>/ai-rewrite/* as a final prototype handoff.',
  'Final editable prototypes belong under src/prototypes/<slug>/ and process evidence stays under .protorec/pages/<slug>/.'
].join(' ');

function createMigrationError() {
  const error = new Error(MIGRATION_ERROR_MESSAGE);
  error.code = MIGRATION_ERROR_CODE;
  error.status = 'BLOCKED';
  return error;
}

function emitAiRewritePackFiles() {
  throw createMigrationError();
}

module.exports = {
  MIGRATION_ERROR_CODE,
  MIGRATION_ERROR_MESSAGE,
  createMigrationError,
  emitAiRewritePackFiles
};
