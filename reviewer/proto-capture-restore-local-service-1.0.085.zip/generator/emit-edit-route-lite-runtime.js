const { buildSemanticRuntimeSource } = require('./emit-page-entry');

function escapeJsonForSource(value) {
  return JSON.stringify(value)
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e')
    .replace(/\u2028/g, '\\u2028')
    .replace(/\u2029/g, '\\u2029');
}

function buildComposeEditRouteLiteMarkupSource() {
  return `
const ROUTE_MARKER_PATTERN = /<!--__PROTOREC_ROUTE_FRAGMENT:([A-Za-z0-9_-]+)__-->/g;
const NAMED_MARKER_PATTERN = /<!--__PROTOREC_FRAGMENT:([A-Za-z0-9_]+)__-->/g;

function buildMarkerIndex(routeFragmentMarkers: Record<string, string[]>) {
  const markerToBlockId = new Map<string, string>();
  Object.entries(routeFragmentMarkers || {}).forEach(([blockId, markerNames]) => {
    (Array.isArray(markerNames) ? markerNames : []).forEach((markerName) => {
      const normalizedName = String(markerName || '').trim();
      if (normalizedName && !markerToBlockId.has(normalizedName)) {
        markerToBlockId.set(normalizedName, String(blockId || '').trim());
      }
    });
  });
  return markerToBlockId;
}

function renderEditRouteLiteMarkup(
  markup: string,
  routeFragments: Record<string, string>,
  fallbackFragments: Record<string, string>,
  routeFragmentMarkers: Record<string, string[]>,
  depth = 0
): string {
  if (depth > 20) {
    return String(markup || '');
  }

  const markerToBlockId = buildMarkerIndex(routeFragmentMarkers);
  let renderedMarkup = String(markup || '');
  renderedMarkup = renderedMarkup.replace(ROUTE_MARKER_PATTERN, (_match, blockId) => {
    const nextMarkup = String(routeFragments?.[String(blockId || '').trim()] || '');
    return nextMarkup ? renderEditRouteLiteMarkup(nextMarkup, routeFragments, fallbackFragments, routeFragmentMarkers, depth + 1) : '';
  });
  renderedMarkup = renderedMarkup.replace(NAMED_MARKER_PATTERN, (_match, markerName) => {
    const normalizedName = String(markerName || '').trim();
    if (!normalizedName) {
      return '';
    }
    const routeBlockId = markerToBlockId.get(normalizedName);
    if (routeBlockId) {
      const routeMarkup = String(routeFragments?.[routeBlockId] || '');
      return routeMarkup ? renderEditRouteLiteMarkup(routeMarkup, routeFragments, fallbackFragments, routeFragmentMarkers, depth + 1) : '';
    }
    if (Object.prototype.hasOwnProperty.call(fallbackFragments || {}, normalizedName)) {
      const fallbackMarkup = String(fallbackFragments[normalizedName] || '');
      return fallbackMarkup ? renderEditRouteLiteMarkup(fallbackMarkup, routeFragments, fallbackFragments, routeFragmentMarkers, depth + 1) : '';
    }
    return '';
  });
  return renderedMarkup;
}

export function composeEditRouteLiteMarkup(
  pageShellHtml: string,
  routeFragments: Record<string, string>,
  fallbackFragments: Record<string, string>,
  routeFragmentMarkers: Record<string, string[]>
): string {
  return renderEditRouteLiteMarkup(pageShellHtml, routeFragments, fallbackFragments, routeFragmentMarkers);
}
`;
}

function buildBodyRuntimeSource() {
  return `
function escapePreviewBodyAttributeValue(value: string) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;');
}

export function sanitizePreviewBodyStyle(styleText: string) {
  return String(styleText || '')
    .split(';')
    .map((entry) => entry.trim())
    .filter(Boolean)
    .filter((declaration) => {
      const separatorIndex = declaration.indexOf(':');
      if (separatorIndex < 0) return false;
      const property = declaration.slice(0, separatorIndex).trim().toLowerCase();
      const value = declaration.slice(separatorIndex + 1).trim().toLowerCase();
      if (!property || !value) return false;
      return !(BODY_SCROLL_LOCK_PROPERTIES.has(property) && /^(hidden|clip)$/.test(value));
    })
    .join('; ');
}

export function sanitizePreviewBodyDataAttributes(dataAttributes: string) {
  if (!String(dataAttributes || '').trim() || typeof document === 'undefined') {
    return String(dataAttributes || '');
  }

  const parser = document.createElement('div');
  parser.innerHTML = '<body ' + dataAttributes + '></body>';
  const desiredBody = parser.firstElementChild;
  if (!desiredBody) return String(dataAttributes || '');

  Array.from(desiredBody.attributes).forEach((attribute) => {
    const name = String(attribute.name || '').toLowerCase();
    const value = String(attribute.value || '').trim().toLowerCase();
    if (BODY_SCROLL_LOCK_DATA_ATTRIBUTE_NAMES.has(name) && /^(hidden|clip)$/.test(value)) {
      desiredBody.removeAttribute(attribute.name);
    }
  });

  return Array.from(desiredBody.attributes)
    .map((attribute) => ' ' + attribute.name + '="' + escapePreviewBodyAttributeValue(attribute.value) + '"')
    .join('');
}

function usePreviewBodyEnvironment(className: string, styleText: string, dataAttributes: string) {
  React.useEffect(() => {
    if (typeof document === 'undefined' || !document.body) return undefined;

    const body = document.body;
    const previousClassName = body.getAttribute('class') || '';
    const previousStyle = body.getAttribute('style') || '';
    const previousDataAttributes = Array.from(body.attributes)
      .filter((attribute) => attribute.name.startsWith('data-'))
      .map((attribute) => [attribute.name, attribute.value] as const);

    Array.from(body.attributes)
      .filter((attribute) => attribute.name.startsWith('data-'))
      .forEach((attribute) => body.removeAttribute(attribute.name));

    const sanitizedDataAttributes = sanitizePreviewBodyDataAttributes(dataAttributes);
    if (sanitizedDataAttributes.trim()) {
      const parser = document.createElement('div');
      parser.innerHTML = '<body ' + sanitizedDataAttributes + '></body>';
      const desiredBody = parser.firstElementChild;
      if (desiredBody) {
        Array.from(desiredBody.attributes).forEach((attribute) => {
          body.setAttribute(attribute.name, attribute.value);
        });
      }
    }

    if (className.trim()) body.setAttribute('class', className);
    else body.removeAttribute('class');

    const sanitizedStyleText = sanitizePreviewBodyStyle(styleText);
    if (sanitizedStyleText.trim()) body.setAttribute('style', sanitizedStyleText);
    else body.removeAttribute('style');

    return () => {
      previousDataAttributes.forEach(([name, value]) => body.setAttribute(name, value));
      Array.from(body.attributes)
        .filter((attribute) => attribute.name.startsWith('data-') && !previousDataAttributes.find(([name]) => name === attribute.name))
        .forEach((attribute) => body.removeAttribute(attribute.name));

      if (previousClassName) body.setAttribute('class', previousClassName);
      else body.removeAttribute('class');
      if (previousStyle) body.setAttribute('style', previousStyle);
      else body.removeAttribute('style');
    };
  }, [className, styleText, dataAttributes]);
}

export { usePreviewBodyEnvironment };
`;
}

function emitEditRouteLiteRuntime(pageIR = {}) {
  if (!pageIR?.semanticSchemas) {
    return [];
  }

  const semanticRuntimeSource = String(buildSemanticRuntimeSource())
    .replace(/^function /gm, 'export function ');

  return [
    ['edit-route-lite-runtime.ts', `import React from 'react';

const BODY_SCROLL_LOCK_PROPERTIES = new Set([
  'overflow',
  'overflow-x',
  'overflow-y'
]);

const BODY_SCROLL_LOCK_DATA_ATTRIBUTE_NAMES = new Set([
  'data-restore-layout-overflow-x',
  'data-restore-layout-overflow-y',
  'data-restore-scroll-overflow-x',
  'data-restore-scroll-overflow-y'
]);

${buildComposeEditRouteLiteMarkupSource()}
${buildBodyRuntimeSource()}
${semanticRuntimeSource}
`]
  ];
}

module.exports = {
  emitEditRouteLiteRuntime
};
