const fs = require('fs');
const path = require('path');

const {
  emitEditMapObjectWithOptions,
  isEditMapPilotPage
} = require('./emit-edit-map');

const ROUTE_ORDER = ['table', 'filter', 'menu'];

function normalizeArray(value) {
  return Array.isArray(value) ? value : [];
}

function normalizePath(filePath = '') {
  return String(filePath || '').split(path.sep).join('/');
}

function normalizePathSet(values = []) {
  return new Set(
    normalizeArray(values)
      .map((value) => normalizePath(value).replace(/^\/+/, '').trim())
      .filter(Boolean)
  );
}

function pathExists(pageDir = '', relativePath = '') {
  if (!pageDir || !relativePath) {
    return false;
  }

  try {
    fs.accessSync(path.join(pageDir, relativePath));
    return true;
  } catch (_error) {
    return false;
  }
}

function availablePath(relativePath = '', emittedPaths = new Set(), pageDir = '') {
  const normalized = normalizePath(relativePath).replace(/^\/+/, '').trim();
  if (!normalized) {
    return '';
  }

  return emittedPaths.has(normalized) || pathExists(pageDir, normalized)
    ? normalized
    : '';
}

function listExistingFragments(pageDir = '') {
  const fragmentsDir = path.join(pageDir, 'fragments');
  try {
    return fs.readdirSync(fragmentsDir)
      .filter((name) => name.endsWith('.tsx'))
      .map((name) => `fragments/${name}`)
      .sort();
  } catch (_error) {
    return [];
  }
}

function readExistingEditMap(pageDir = '') {
  if (!pageDir) {
    return null;
  }

  try {
    return JSON.parse(fs.readFileSync(path.join(pageDir, 'edit-map.json'), 'utf8'));
  } catch (_error) {
    return null;
  }
}

function buildFragmentRecords({ pageDir = '', emittedFragmentPaths = [] } = {}) {
  const emitted = normalizePathSet(emittedFragmentPaths);
  const paths = emitted.size
    ? Array.from(emitted).sort()
    : listExistingFragments(pageDir);

  return paths.map((fragmentPath) => {
    const name = path.basename(fragmentPath, '.tsx');
    const role = name === 'page' ? 'page-shell' : 'edit-block';

    return {
      path: fragmentPath,
      name,
      role
    };
  });
}

function routeTitle(blockId = '') {
  if (blockId === 'table') return 'Table route';
  if (blockId === 'filter') return 'Filter route';
  if (blockId === 'menu') return 'Menu route';
  return `${blockId} route`;
}

function buildRoute(block = {}, options = {}) {
  const pageDir = options.pageDir || '';
  const emittedFragmentPaths = normalizePathSet(options.emittedFragmentPaths);
  const emittedSemanticPaths = normalizePathSet(options.emittedSemanticPaths);
  const blockId = String(block.blockId || block.semanticType || '').trim();
  const canonicalStatus = block.capability === 'available' ? 'available' : 'missing';
  const fragmentPath = canonicalStatus === 'available'
    ? availablePath(block.fragmentPath, emittedFragmentPaths, pageDir)
    : '';
  const semanticPath = canonicalStatus === 'available'
    ? availablePath(block.semanticPath, emittedSemanticPaths, pageDir)
    : '';
  const preferredTargets = [];

  if (semanticPath) {
    preferredTargets.push({
      kind: 'semantic',
      path: semanticPath,
      purpose: 'schema-backed values and edit model'
    });
  }

  if (fragmentPath) {
    preferredTargets.push({
      kind: 'fragment',
      path: fragmentPath,
      purpose: 'bounded markup for this edit route'
    });
  }

  const unsupportedPolicy = canonicalStatus === 'missing'
    ? [
      `Canonical status is missing for ${blockId}.`,
      `Do not fabricate fragments/${blockId}.tsx.`,
      `Do not create a fake ${blockId} semantic patch.`,
      `Do not add a fake ${blockId} through index.tsx to satisfy a bounded edit.`
    ].join(' ')
    : '';

  return {
    blockId,
    title: routeTitle(blockId),
    semanticType: String(block.semanticType || blockId),
    status: canonicalStatus,
    capability: canonicalStatus,
    editMapBlock: `edit-map.json#blocks[blockId=${blockId}]`,
    preferredTargets,
    supportedEdits: normalizeArray(block.supportedEdits),
    fallbackPolicy: canonicalStatus === 'available'
      ? 'Use preferredTargets first. Touch index.tsx or whole-page rewrite only after explaining why no bounded target can satisfy the requested change.'
      : 'No bounded target is available. Treat this route as unsupported unless the user explicitly requests new feature work; do not fabricate the missing structure.',
    unsupportedPolicy
  };
}

function buildEditRouteLiteGuidance(pageIR = {}, options = {}) {
  if (!isEditMapPilotPage(pageIR)) {
    return null;
  }

  const outputPaths = options.outputPaths || {};
  const pageDir = outputPaths.pageDir || options.pageDir || '';
  const emittedFragmentPaths = normalizeArray(options.emittedFragmentPaths);
  const emittedSemanticPaths = normalizeArray(options.emittedSemanticPaths);
  const emittedEditMapPaths = normalizePathSet(options.emittedEditMapPaths);
  const editMapExists = emittedEditMapPaths.has('edit-map.json') || pathExists(pageDir, 'edit-map.json');
  const editMap = options.editMapObject
    || readExistingEditMap(pageDir)
    || emitEditMapObjectWithOptions(pageIR, { emittedFragmentPaths });

  if (!editMap || (!editMapExists && !options.editMapObject)) {
    return null;
  }

  const fragments = buildFragmentRecords({ pageDir, emittedFragmentPaths });
  const semanticPaths = emittedSemanticPaths.length
    ? emittedSemanticPaths.map(normalizePath).sort()
    : ['semantic/table.ts', 'semantic/filter.ts', 'semantic/menu.ts']
      .filter((semanticPath) => pathExists(pageDir, semanticPath));
  const blocks = normalizeArray(editMap.blocks);
  const routes = ROUTE_ORDER
    .map((blockId) => blocks.find((block) => block.blockId === blockId || block.semanticType === blockId))
    .filter(Boolean)
    .map((block) => buildRoute(block, {
      pageDir,
      emittedFragmentPaths,
      emittedSemanticPaths
    }));

  return {
    mode: 'edit-route-lite',
    editMapPath: 'edit-map.json',
    fragmentsDir: 'fragments/',
    runtimePath: availablePath('edit-route-lite-runtime.ts', normalizePathSet(options.emittedRuntimePaths), pageDir),
    fragments,
    semanticPaths,
    routes,
    targetPrecedence: [
      'README.md',
      'spec.md',
      'edit-map.json',
      'semantic/*.ts',
      'fragments/*.tsx',
      'style.css',
      'index.tsx'
    ],
    fallbackPolicy: 'index.tsx and whole-page rewrite are non-preferred fallbacks. Use them only after explaining why edit-map, semantic files, and fragments cannot satisfy the requested change.',
    editMap
  };
}

module.exports = {
  buildEditRouteLiteGuidance
};
