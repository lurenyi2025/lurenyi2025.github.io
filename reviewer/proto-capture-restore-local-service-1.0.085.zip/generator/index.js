const fs = require('fs-extra');
const path = require('path');

const {
  META_ROOT,
  PAGES_ROOT
} = require('./config');
const { buildPageIR } = require('./build-page-ir');
const { emitSpec } = require('./emit-spec');
const { emitHandoff } = require('./emit-handoff');
const { emitPageReadme } = require('./emit-page-readme');
const { emitPageAssets } = require('./emit-page-assets');
const { emitPageEntry } = require('./emit-page-entry');
const { emitPageInteractions } = require('./emit-page-interactions');
const { emitSemanticSurface } = require('./emit-semantic-surface');
const { emitEditMap, isEditMapPilotPage } = require('./emit-edit-map');
const { collectPageFragments, emitPageFragmentFiles } = require('./emit-page-fragments');
const { emitEditRouteLiteRuntime } = require('./emit-edit-route-lite-runtime');
const { emitPageStyles } = require('./emit-page-style');
const { buildRootPageDir, writePagesRegistry } = require('./package-contract');
const { createProtocolManifest, resolveReadyState } = require('./protocol');

const PROJECT_ROOT = path.resolve(__dirname, '..', '..');

async function ensureGeneratorRoots() {
  await fs.ensureDir(PAGES_ROOT);
  await fs.ensureDir(META_ROOT);
}

function toPosixPath(filePath = '') {
  return String(filePath || '').split(path.sep).join('/');
}

function toProjectRelativePath(filePath = '') {
  if (!filePath) {
    return '';
  }

  return toPosixPath(path.relative(PROJECT_ROOT, filePath));
}

function createDesiredAssetFiles(assets = []) {
  const desiredImageFiles = new Set();
  const desiredFontFiles = new Set();

  assets.forEach((asset) => {
    const fileName = String(asset?.fileName || '').trim();
    if (!fileName) {
      return;
    }

    if (asset.category === 'fonts') {
      desiredFontFiles.add(fileName);
      return;
    }

    desiredImageFiles.add(fileName);
  });

  return {
    desiredImageFiles,
    desiredFontFiles
  };
}

function collectDesiredAssetsFromSource(source, fileSets) {
  const assetPattern = /assets\/(images|fonts)\/([^'"`\s)]+)/g;
  let match = assetPattern.exec(String(source || ''));

  while (match) {
    const [, category, relativeFilePath] = match;
    const fileName = path.posix.basename(relativeFilePath);
    if (fileName) {
      if (category === 'fonts') {
        fileSets.desiredFontFiles.add(fileName);
      } else {
        fileSets.desiredImageFiles.add(fileName);
      }
    }

    match = assetPattern.exec(String(source || ''));
  }
}

async function collectDesiredSharedAssetFiles(pageIR) {
  const desiredFiles = createDesiredAssetFiles(pageIR.assets || []);
  const assetOwnerRouteId = pageIR.baseRouteId || pageIR.routeId;
  const registryPath = path.join(PAGES_ROOT, assetOwnerRouteId, 'pages.json');

  try {
    const registry = await fs.readJson(registryPath);
    const siblingViews = Array.isArray(registry?.views)
      ? registry.views.filter((view) => view?.routeId && view.routeId !== pageIR.routeId)
      : [];

    await Promise.all(siblingViews.map(async (view) => {
      const assetsPath = path.join(PAGES_ROOT, view.routeId, 'assets.ts');
      try {
        const source = await fs.readFile(assetsPath, 'utf8');
        collectDesiredAssetsFromSource(source, desiredFiles);
      } catch (_error) {
        return;
      }
    }));
  } catch (_error) {
    return desiredFiles;
  }

  return desiredFiles;
}

async function pruneGeneratedRoot(rootDir, pageDir, desiredRelativePaths) {
  let hasRemainingEntries = false;

  let entries = [];
  try {
    entries = await fs.readdir(rootDir, { withFileTypes: true });
  } catch (error) {
    if (error?.code === 'ENOENT') {
      return false;
    }
    throw error;
  }

  for (const entry of entries) {
    const absolutePath = path.join(rootDir, entry.name);
    if (entry.isDirectory()) {
      const nestedHasEntries = await pruneGeneratedRoot(absolutePath, pageDir, desiredRelativePaths);
      if (!nestedHasEntries) {
        await fs.remove(absolutePath);
        continue;
      }

      hasRemainingEntries = true;
      continue;
    }

    const relativePath = toPosixPath(path.relative(pageDir, absolutePath));
    if (!desiredRelativePaths.has(relativePath)) {
      await fs.remove(absolutePath);
      continue;
    }

    hasRemainingEntries = true;
  }

  return hasRemainingEntries;
}

async function removeStaleGeneratedFiles(pageDir, filesToWrite = [], options = {}) {
  const desiredRelativePaths = new Set(
    filesToWrite.map(([fileName]) => toPosixPath(fileName))
  );
  const legacyGeneratedFiles = [
    'model.ts',
    'interactions.ts',
    'edit-route-lite-runtime.ts'
  ];
  const generatedRoots = [
    path.join(pageDir, 'semantic'),
    path.join(pageDir, 'sections'),
    path.join(pageDir, 'styles')
  ];

  if (options.pruneFragmentsRoot) {
    generatedRoots.push(path.join(pageDir, 'fragments'));
  }

  await Promise.all([
    ...generatedRoots.map((rootDir) => (
      pruneGeneratedRoot(rootDir, pageDir, desiredRelativePaths)
    )),
    ...legacyGeneratedFiles.map(async (fileName) => {
      if (!desiredRelativePaths.has(fileName)) {
        await fs.remove(path.join(pageDir, fileName));
      }
    })
  ]);
}

function buildRegistrySyncPageIR(routeId, manifest = {}, sectionDebug = []) {
  return {
    routeId,
    sections: Array.isArray(sectionDebug)
      ? sectionDebug.map((section) => ({
        id: section?.id,
        kind: section?.kind
      })).filter((section) => String(section.id || '').trim())
      : [],
    interactions: Array.isArray(manifest?.interactions) ? manifest.interactions : []
  };
}

async function syncRegistryInteractions(registry = null) {
  const views = Array.isArray(registry?.views) ? registry.views : [];
  const summary = {
    scannedViews: 0,
    updatedViews: 0,
    skippedViews: 0
  };

  await Promise.all(views.map(async (view) => {
    const routeId = String(view?.routeId || '').trim();
    if (!routeId) {
      summary.skippedViews += 1;
      return;
    }

    summary.scannedViews += 1;

    const pageDir = path.join(PAGES_ROOT, routeId);
    const metaDir = path.join(META_ROOT, routeId);
    const interactionsPath = path.join(pageDir, 'interactions.ts');
    const manifestPath = path.join(metaDir, 'manifest.json');
    const sectionDebugPath = path.join(metaDir, 'section-debug.json');

    const requiredPaths = [interactionsPath, manifestPath, sectionDebugPath];
    const requiredStatus = await Promise.all(requiredPaths.map((filePath) => fs.pathExists(filePath)));
    if (requiredStatus.some((status) => !status)) {
      summary.skippedViews += 1;
      return;
    }

    let manifest = {};
    let sectionDebug = [];
    try {
      [manifest, sectionDebug] = await Promise.all([
        fs.readJson(manifestPath),
        fs.readJson(sectionDebugPath)
      ]);
    } catch (_error) {
      summary.skippedViews += 1;
      return;
    }

    const pageIR = buildRegistrySyncPageIR(routeId, manifest, sectionDebug);
    const nextSource = `${String(emitPageInteractions(pageIR, { registry })).replace(/\s+$/, '')}\n`;

    let currentSource = '';
    try {
      currentSource = await fs.readFile(interactionsPath, 'utf8');
    } catch (_error) {
      summary.skippedViews += 1;
      return;
    }

    if (currentSource === nextSource) {
      summary.skippedViews += 1;
      return;
    }

    await fs.writeFile(interactionsPath, nextSource, 'utf8');
    summary.updatedViews += 1;
  }));

  return summary;
}

async function syncAllPageRegistries(rootDir = PAGES_ROOT) {
  const summary = {
    scannedRegistries: 0,
    updatedRegistries: 0,
    scannedViews: 0,
    updatedViews: 0,
    skippedViews: 0
  };

  const visitDirectory = async (currentDir) => {
    let entries = [];
    try {
      entries = await fs.readdir(currentDir, { withFileTypes: true });
    } catch (error) {
      if (error?.code === 'ENOENT') {
        return;
      }
      throw error;
    }

    const pagesJsonEntry = entries.find((entry) => entry.isFile() && entry.name === 'pages.json');
    if (pagesJsonEntry) {
      const registryPath = path.join(currentDir, pagesJsonEntry.name);
      let registry = null;
      try {
        registry = await fs.readJson(registryPath);
      } catch (_error) {
        return;
      }

      summary.scannedRegistries += 1;
      const registrySummary = await syncRegistryInteractions(registry);
      summary.scannedViews += registrySummary.scannedViews;
      summary.updatedViews += registrySummary.updatedViews;
      summary.skippedViews += registrySummary.skippedViews;
      if (registrySummary.updatedViews > 0) {
        summary.updatedRegistries += 1;
      }
      return;
    }

    await Promise.all(entries
      .filter((entry) => entry.isDirectory())
      .map((entry) => visitDirectory(path.join(currentDir, entry.name))));
  };

  await visitDirectory(rootDir);
  return summary;
}

async function copyPageAssets(pageIR) {
  const assetOwnerRouteId = pageIR.baseRouteId || pageIR.routeId;
  const pageAssetsRoot = path.join(PAGES_ROOT, assetOwnerRouteId, 'assets');
  const imagesDir = path.join(pageAssetsRoot, 'images');
  const fontsDir = path.join(pageAssetsRoot, 'fonts');

  await Promise.all([
    fs.ensureDir(imagesDir),
    fs.ensureDir(fontsDir)
  ]);

  await Promise.all((pageIR.assets || []).map(async (asset) => {
    const targetDir = asset.category === 'fonts' ? fontsDir : imagesDir;
    await fs.copy(asset.sourcePath, path.join(targetDir, asset.fileName));
  }));

  const {
    desiredImageFiles,
    desiredFontFiles
  } = await collectDesiredSharedAssetFiles(pageIR);

  const pruneDir = async (targetDir, desiredFiles) => {
    let entries = [];
    try {
      entries = await fs.readdir(targetDir, { withFileTypes: true });
    } catch (error) {
      if (error?.code === 'ENOENT') {
        return;
      }
      throw error;
    }

    await Promise.all(entries.map(async (entry) => {
      if (!entry.isFile() || desiredFiles.has(entry.name)) {
        return;
      }

      await fs.remove(path.join(targetDir, entry.name));
    }));
  };

  await Promise.all([
    pruneDir(imagesDir, desiredImageFiles),
    pruneDir(fontsDir, desiredFontFiles)
  ]);

  return {
    imagesDir,
    fontsDir
  };
}

function buildSectionDebugRecords(pageIR) {
  return (pageIR.sections || []).map((section) => ({
    id: section.id,
    title: section.title,
    kind: section.kind,
    summary: section.summary,
    confidence: Number(section.confidence || 0),
    renderMode: section.renderMode,
    componentName: section.componentName,
    interactionIds: section.interactionIds || [],
    contextWrappers: section.contextWrappers || [],
    stats: section.stats || {},
    diagnostics: section.diagnostics || null,
    blockIds: Array.isArray(section.blocks) ? section.blocks.map((block) => block.id) : []
  }));
}

function buildBlockDebugRecords(pageIR) {
  return (pageIR.sections || []).flatMap((section) => (
    Array.isArray(section.blocks)
      ? section.blocks.map((block) => ({
        id: block.id,
        sectionId: section.id,
        derivedFromBlockId: block.derivedFromBlockId || null,
        sectionComponentName: section.componentName,
        componentName: block.componentName,
        fileName: block.fileName,
        title: block.title,
        kind: block.kind,
        summary: block.summary,
        confidence: Number(block.confidence || 0),
        renderMode: block.renderMode,
        interactionIds: block.interactionIds || [],
        contextWrappers: block.contextWrappers || [],
        stats: block.stats || {},
        diagnostics: block.diagnostics || null
      }))
      : []
  ));
}

function buildGenerationDebug(pageIR, outputPaths, input = {}) {
  const pageSpecificDebug = pageIR?.editability?.pageSpecificDebug || {};

  return {
    resultsSubtreeStatus: pageSpecificDebug?.resultsSubtreeStatus || 'failed',
    carouselSubtreeStatus: pageSpecificDebug?.carouselSubtreeStatus || 'failed',
    resultsFallbackReason: pageSpecificDebug?.resultsFallbackReason || 'missing-required-block',
    carouselFallbackReason: pageSpecificDebug?.carouselFallbackReason || 'missing-required-block',
    biasApplied: Boolean(pageSpecificDebug?.biasApplied),
    biasSkippedReason: pageSpecificDebug?.biasSkippedReason || 'none',
    page: {
      pageSlug: pageIR.pageSlug,
      routeId: pageIR.routeId,
      baseRouteId: pageIR.baseRouteId,
      pageTitle: pageIR.pageTitle,
      sourceUrl: pageIR.sourceUrl,
      view: pageIR.view
    },
    generation: {
      protocolVersion: pageIR.protocolVersion,
      generationMode: pageIR.generationMode,
      readyState: pageIR.readyState,
      qaStatus: pageIR?.qa?.status || 'unknown',
      releaseDecision: pageIR?.qa?.releaseDecision || 'unknown',
      pageConfidence: Number(pageIR?.confidence?.page || 0),
      editabilityScore: Number(pageIR?.editability?.score || 0),
      editabilityStatus: pageIR?.editability?.status || 'unknown'
    },
    counts: {
      sectionCount: Array.isArray(pageIR.sections) ? pageIR.sections.length : 0,
      blockCount: Array.isArray(pageIR.sections)
        ? pageIR.sections.reduce((sum, section) => sum + (Array.isArray(section.blocks) ? section.blocks.length : 0), 0)
        : 0,
      degradedSectionCount: Array.isArray(pageIR.degradedSections) ? pageIR.degradedSections.length : 0,
      interactionCount: Array.isArray(pageIR.interactions) ? pageIR.interactions.length : 0,
      assetCount: Array.isArray(pageIR.assets) ? pageIR.assets.length : 0
    },
    structuralDecomposition: pageIR?.structuralDecomposition
      ? {
        enabled: true,
        strategy: pageIR.structuralDecomposition.strategy,
        rootFragmentName: pageIR.structuralDecomposition.rootFragmentName,
        diagnostics: pageIR.structuralDecomposition.diagnostics || {},
        fragmentCount: Array.isArray(pageIR.structuralDecomposition.fragments)
          ? pageIR.structuralDecomposition.fragments.length
          : 0,
        fragmentNames: Array.isArray(pageIR.structuralDecomposition.fragments)
          ? pageIR.structuralDecomposition.fragments.map((fragment) => fragment?.name).filter(Boolean)
          : []
      }
      : {
        enabled: false,
        fallbackReason: pageIR?.sectionMap?.fallbackReason || 'not-run'
      },
    semanticSchemas: {
      status: pageIR?.semanticSchemas?.status || 'unavailable',
      hasTableSchema: Boolean(pageIR?.semanticSchemas?.tableSchema),
      tableColumnCount: Array.isArray(pageIR?.semanticSchemas?.tableSchema?.columns)
        ? pageIR.semanticSchemas.tableSchema.columns.length
        : 0,
      tableRowCount: Array.isArray(pageIR?.semanticSchemas?.tableSchema?.rows)
        ? pageIR.semanticSchemas.tableSchema.rows.length
        : 0,
      hasFilterSchema: Boolean(pageIR?.semanticSchemas?.filterSchema),
      filterFieldCount: Array.isArray(pageIR?.semanticSchemas?.filterSchema?.fields)
        ? pageIR.semanticSchemas.filterSchema.fields.length
        : 0,
      hasMenuSchema: Boolean(pageIR?.semanticSchemas?.menuSchema),
      menuItemCount: Array.isArray(pageIR?.semanticSchemas?.menuSchema?.items)
        ? pageIR.semanticSchemas.menuSchema.items.length
        : 0,
      diagnostics: pageIR?.semanticSchemas?.diagnostics || []
    },
    debugFocus: {
      qaPrimaryReason: pageIR?.qa?.primaryReason || '',
      qaBlockers: pageIR?.qa?.blockers || [],
      qaWarnings: pageIR?.qa?.warnings || [],
      blockers: pageIR?.editability?.blockers || [],
      warnings: pageIR?.editability?.warnings || [],
      problemAreas: pageIR?.editability?.problemAreas || [],
      recommendedFirstEdits: pageIR?.editability?.recommendedFirstEdits || [],
      lowRiskTargets: pageIR?.editability?.lowRiskTargets || [],
      avoidForNow: pageIR?.editability?.avoidForNow || [],
      pageSpecificDebug
    },
    outputs: {
      pageDir: outputPaths.pageDir,
      entryFilePath: outputPaths.entryFilePath,
      readmeFilePath: outputPaths.readmeFilePath || '',
      specFilePath: outputPaths.specFilePath || '',
      handoffFilePath: outputPaths.handoffFilePath || '',
      metaDir: outputPaths.metaDir,
      sectionsDir: outputPaths.sectionsDir,
      stylesDir: outputPaths.stylesDir,
      pagesJsonPath: outputPaths.pagesJsonPath || '',
      imagesDir: outputPaths.imagesDir,
      fontsDir: outputPaths.fontsDir
    },
    input: {
      captureDir: input.captureDir || '',
      restoreSlug: input.restoreSlug || '',
      restoreRelativeDir: input.restoreRelativeDir || '',
      pageTitle: input.pageTitle || '',
      pageUrl: input.pageUrl || '',
      hasLocalizedHtml: Boolean(input.localizedHtml),
      captureVariant: input.captureVariant || null
    }
  };
}

async function writeEvidencePackage(pageIR, outputPaths, input = {}) {
  const metaDir = outputPaths.metaDir;
  await fs.ensureDir(metaDir);

  const manifest = createProtocolManifest(pageIR, {
    pageDir: outputPaths.pageDir,
    entryFilePath: outputPaths.entryFilePath,
    qaReportPath: outputPaths.qaReportPath,
    imagesDir: outputPaths.imagesDir,
    fontsDir: outputPaths.fontsDir,
    metaDir,
    debugFiles: [
      'section-debug.json',
      'block-debug.json',
      'editability-debug.json',
      'generation-debug.json',
      'qa-report.json',
      'capture-quality.json',
      'section-map.json',
      'semantic-schema.json'
    ]
  });

  await fs.writeJson(path.join(metaDir, 'manifest.json'), manifest, { spaces: 2 });
  await fs.writeJson(path.join(metaDir, 'confidence-report.json'), pageIR.confidence, { spaces: 2 });
  await fs.writeJson(path.join(metaDir, 'editability-report.json'), pageIR.editability || {}, { spaces: 2 });
  await fs.writeJson(path.join(metaDir, 'qa-report.json'), pageIR.qa || {}, { spaces: 2 });
  await fs.writeJson(path.join(metaDir, 'section-map.json'), pageIR.sectionMap || {}, { spaces: 2 });
  await fs.writeJson(path.join(metaDir, 'semantic-schema.json'), pageIR.semanticSchemas || {}, { spaces: 2 });
  await fs.writeJson(path.join(metaDir, 'section-debug.json'), buildSectionDebugRecords(pageIR), { spaces: 2 });
  await fs.writeJson(path.join(metaDir, 'block-debug.json'), buildBlockDebugRecords(pageIR), { spaces: 2 });
  await fs.writeJson(path.join(metaDir, 'editability-debug.json'), {
    summary: {
      score: Number(pageIR?.editability?.score || 0),
      status: pageIR?.editability?.status || 'unknown',
      readyState: pageIR?.readyState || 'blocked',
      qaStatus: pageIR?.qa?.status || 'unknown'
    },
    locationDimensions: pageIR?.editability?.locationDimensions || [],
    hotspots: pageIR?.editability?.hotspots || [],
    blockers: pageIR?.editability?.blockers || [],
    warnings: pageIR?.editability?.warnings || [],
    scoreDrivers: pageIR?.editability?.scoreDrivers || {},
    recommendedFirstEdits: pageIR?.editability?.recommendedFirstEdits || [],
    lowRiskTargets: pageIR?.editability?.lowRiskTargets || [],
    avoidForNow: pageIR?.editability?.avoidForNow || [],
    problemAreas: pageIR?.editability?.problemAreas || [],
    pageSpecificDebug: pageIR?.editability?.pageSpecificDebug || null
  }, { spaces: 2 });
  await fs.writeJson(path.join(metaDir, 'generation-debug.json'), buildGenerationDebug(pageIR, outputPaths, input), { spaces: 2 });
  await fs.writeJson(path.join(metaDir, 'capture-quality.json'), input.captureQuality || {}, { spaces: 2 });

  const captureMetaPath = path.join(input.captureDir || '', 'capture.meta.json');
  const sourceHtmlPath = path.join(input.captureDir || '', 'source.original.html');
  const referenceImagePath = path.join(input.captureDir || '', 'reference_full.png');

  if (input.captureDir && await fs.pathExists(captureMetaPath)) {
    const captureMeta = await fs.readJson(captureMetaPath);
    await fs.writeJson(path.join(metaDir, 'capture.meta.json'), {
      ...captureMeta,
      restoreTargetPath: toProjectRelativePath(outputPaths.pageDir),
      restoreComponentPath: toProjectRelativePath(outputPaths.entryFilePath),
      specPath: toProjectRelativePath(outputPaths.specFilePath),
      restoreAssetsPath: {
        fonts: toProjectRelativePath(outputPaths.fontsDir),
        images: toProjectRelativePath(outputPaths.imagesDir)
      },
      pagesJsonPath: toProjectRelativePath(outputPaths.pagesJsonPath),
      restoreMetaPath: toProjectRelativePath(metaDir),
      qaReportPath: toProjectRelativePath(path.join(metaDir, 'qa-report.json')),
      readyState: pageIR.readyState || captureMeta.readyState || 'unknown',
      editability: pageIR.editability || captureMeta.editability || {},
      qa: pageIR.qa || captureMeta.qa || {}
    }, { spaces: 2 });
  }

  if (input.captureDir && await fs.pathExists(sourceHtmlPath)) {
    await fs.copy(sourceHtmlPath, path.join(metaDir, 'source.original.html'));
  }

  if (input.captureDir && await fs.pathExists(referenceImagePath)) {
    await fs.copy(referenceImagePath, path.join(metaDir, 'reference_full.png'));
  }
}

async function generatePagePackage(input = {}) {
  await ensureGeneratorRoots();

  const pageIR = await buildPageIR(input);
  const pageDir = path.join(PAGES_ROOT, pageIR.routeId);
  const metaDir = path.join(META_ROOT, pageIR.routeId);
  const readyState = pageIR.readyState || resolveReadyState(pageIR.confidence.page, pageIR.degradedSections, pageIR.editability, pageIR.interactions);

  await fs.ensureDir(pageDir);
  const copiedAssets = await copyPageAssets(pageIR);
  const styleBundle = emitPageStyles(pageIR);
  pageIR.previewHead = String(pageIR.previewHeadTemplate || '').replace(
    '__PROTOREC_GENERATED_STYLE__',
    `<style data-protorec-generated-style>${styleBundle.previewCss}</style>`
  );

  const outputPaths = {
    rootPageDir: buildRootPageDir(pageIR),
    pageDir,
    entryFilePath: path.join(pageDir, 'index.tsx'),
    readmeFilePath: path.join(pageDir, 'README.md'),
    specFilePath: path.join(pageDir, 'spec.md'),
    handoffFilePath: path.join(pageDir, 'handoff.md'),
    metaDir,
    qaReportPath: path.join(metaDir, 'qa-report.json'),
    imagesDir: copiedAssets.imagesDir,
    fontsDir: copiedAssets.fontsDir,
    sectionsDir: path.join(pageDir, 'sections'),
    stylesDir: path.join(pageDir, 'styles')
  };
  const registryResult = await writePagesRegistry(pageIR, outputPaths);
  outputPaths.pagesJsonPath = registryResult.registryPath;
  outputPaths.pagesRegistry = registryResult.registry;

  const semanticSurfaceFiles = emitSemanticSurface(pageIR);
  const pageFragments = collectPageFragments(pageIR);
  const pageFragmentFiles = emitPageFragmentFiles(pageIR, pageFragments);
  const useEditRouteLiteThinEntry = pageFragmentFiles.some(([fileName]) => fileName === 'fragments/page.tsx');
  const emittedFragmentPaths = pageFragmentFiles
    .map(([fileName]) => fileName)
    .filter((fileName) => fileName !== 'fragments/page.tsx');
  const editMapFiles = emitEditMap(pageIR, { emittedFragmentPaths });
  const editRouteLiteRuntimeFiles = useEditRouteLiteThinEntry ? emitEditRouteLiteRuntime(pageIR) : [];
  const emittedSemanticPaths = semanticSurfaceFiles.map(([fileName]) => fileName);
  const emittedEditMapPaths = editMapFiles.map(([fileName]) => fileName);
  const emittedRuntimePaths = editRouteLiteRuntimeFiles.map(([fileName]) => fileName);
  const editMapObject = editMapFiles.length ? JSON.parse(editMapFiles[0][1]) : null;
  const editRouteLiteGuidanceOptions = {
    registry: registryResult.registry,
    outputPaths,
    emittedFragmentPaths: pageFragmentFiles.map(([fileName]) => fileName),
    emittedSemanticPaths,
    emittedEditMapPaths,
    emittedRuntimePaths,
    editMapObject
  };
  const filesToWrite = [
    ['README.md', emitPageReadme(pageIR, editRouteLiteGuidanceOptions)],
    ['index.tsx', emitPageEntry(pageIR, { useEditRouteLiteThinEntry })],
    ['assets.ts', emitPageAssets(pageIR)],
    ['spec.md', emitSpec(pageIR, { registry: registryResult.registry, outputPaths })],
    ['handoff.md', emitHandoff(pageIR, { registry: registryResult.registry, outputPaths })]
  ]
    .concat(semanticSurfaceFiles)
    .concat(pageFragmentFiles)
    .concat(editRouteLiteRuntimeFiles)
    .concat(editMapFiles)
    .concat(styleBundle.files);

  await removeStaleGeneratedFiles(pageDir, filesToWrite, {
    pruneFragmentsRoot: isEditMapPilotPage(pageIR)
  });

  for (const [fileName, fileContent] of filesToWrite) {
    const targetPath = path.join(pageDir, fileName);
    await fs.ensureDir(path.dirname(targetPath));
    await fs.writeFile(targetPath, `${String(fileContent).replace(/\s+$/, '')}\n`, 'utf8');
  }

  await writeEvidencePackage(pageIR, outputPaths, input);

  return {
    ...outputPaths,
    pageIR,
    readyState
  };
}

module.exports = {
  generatePagePackage,
  writePagesRegistry,
  syncAllPageRegistries,
  syncRegistryInteractions
};
