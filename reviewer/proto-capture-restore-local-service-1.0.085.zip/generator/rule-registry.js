const { FRAMEWORK_SELECTORS, joinSelectors } = require('../adapters/framework-registry');
const { SITE_ADAPTERS } = require('../adapters/site-registry');

const VMALL_PRODUCT_DETAIL_ADAPTER = SITE_ADAPTERS.vmallProductDetail;
const VMALL_PRODUCT_DETAIL_ADAPTER_ID = VMALL_PRODUCT_DETAIL_ADAPTER?.id || 'vmall-product-detail';

const STRONG_SECTION_KINDS = new Set([
  'top-bar',
  'sidebar',
  'footer',
  'hero',
  'tabs',
  'form',
  'table',
  'detail-panel',
  'notice',
  'review-feed',
  'product-grid',
  'feature-list',
  'gallery',
  'promo-strip',
  'floating-layer'
]);

const BLOCKABLE_SECTION_KINDS = new Set([
  'top-bar',
  'main-content',
  'detail-panel',
  'notice',
  'review-feed',
  'hero',
  'product-grid',
  'feature-list',
  'gallery',
  'promo-strip',
  'content-grid',
  'footer'
]);

const BLOCK_SECTION_PROMOTION_KINDS = new Set([
  'top-bar',
  'hero-media',
  'product-detail-hero',
  'promo-banner',
  'icon-grid',
  'featured-shelf',
  'product-shelf',
  'recommend-shelf',
  'detail-anchor-bar',
  'detail-content',
  'spec-list',
  'legal-notice',
  'review-feed',
  'service-strip',
  'footer',
  'floating-layer',
  'media-cluster'
]);

const GENERATOR_SELECTORS = {
  tabContainer: joinSelectors([...FRAMEWORK_SELECTORS.tabs.containers, '[class*="tabs"]']),
  tab: joinSelectors(FRAMEWORK_SELECTORS.tabs.tabs),
  panel: joinSelectors(FRAMEWORK_SELECTORS.tabs.panels),
  carouselContainer: joinSelectors([
    '.swiper',
    '.swiper-container',
    '#swiper',
    '[id="swiper"]',
    '[id*="swiper"]',
    '.slick-slider',
    '.ant-carousel',
    '[class*="carousel"]',
    '[class*="swiper"]',
    '[data-carousel]',
    '[data-swiper]'
  ]),
  carouselSlide: joinSelectors([
    '.swiper-slide',
    '.slick-slide',
    '.ant-carousel .slick-slide',
    '.r-cpa5s6',
    '[class*="slide"]',
    '[data-slide]'
  ]),
  carouselControl: joinSelectors([
    '.slick-dots li',
    '.swiper-pagination-bullet',
    '.swiper-button-next',
    '.swiper-button-prev',
    '[data-slide-to]',
    '[aria-label*="slide"]',
    '[data-carousel-control]'
  ]),
  dismissibleLayer: joinSelectors([
    '[role="dialog"]',
    '[class*="cookie"]',
    '[class*="banner"]',
    '[class*="modal"]',
    '[class*="dialog"]',
    '[class*="drawer"]',
    '[class*="toast"]',
    '[class*="popup"]'
  ]),
  dismissButton: joinSelectors([
    'button',
    '[role="button"]',
    '[aria-label*="close"]',
    '[class*="close"]',
    '[class*="dismiss"]',
    '[data-close]'
  ]),
  dropdownGroup: joinSelectors([
    '.dropdown',
    '[class*="dropdown"]',
    '.hammer-basic-download-center',
    '[data-dropdown]',
    '[aria-haspopup="true"]'
  ]),
  dropdownMenu: joinSelectors([
    '[role="menu"]',
    '[role="listbox"]',
    'ul',
    '.menu',
    '.dropdown-menu',
    '.select-dropdown'
  ])
};

function containsAnyTerm(text, terms = []) {
  const normalizedText = String(text || '');
  return terms.some((term) => normalizedText.includes(term));
}

function resolveActiveAdapterId(signals = {}) {
  return String(signals?.activeAdapterId || signals?.siteAdapter?.id || '').trim();
}

function isAdapterActive(signals = {}, adapterId = '') {
  return Boolean(adapterId) && resolveActiveAdapterId(signals) === adapterId;
}

function getActiveVmallAdapter(signals = {}) {
  return isAdapterActive(signals, VMALL_PRODUCT_DETAIL_ADAPTER_ID)
    ? VMALL_PRODUCT_DETAIL_ADAPTER
    : null;
}

function getActiveVmallTextHints(signals = {}, key) {
  return getActiveVmallAdapter(signals)?.textHints?.[key] || [];
}

function getActiveVmallList(signals = {}, key) {
  return getActiveVmallAdapter(signals)?.[key] || [];
}

function matchesAnchorTabLabel(label = '', siteAdapter = null) {
  const labels = Array.isArray(siteAdapter?.detailAnchorLabels)
    ? siteAdapter.detailAnchorLabels.map((value) => String(value || '').trim()).filter(Boolean)
    : [];
  if (!labels.length) {
    return false;
  }

  const pattern = new RegExp(`^(${labels.join('|')})(?:\\([^)]+\\))?$`);
  return pattern.test(String(label || '').trim());
}

const SECTION_KIND_RULES = [
  {
    id: 'footer-keywords',
    kind: 'footer',
    match: ({ identity }) => /footer|copyright|warrant|legal/.test(identity)
  },
  {
    id: 'overlay-positioning',
    kind: 'floating-layer',
    match: ({ looksLikeOverlay }) => looksLikeOverlay
  },
  {
    id: 'top-bar-signals',
    kind: 'top-bar',
    match: ({ tagName, identity }) => tagName === 'header' || tagName === 'nav' || /(header|nav|navigation|toolbar|topbar|top-bar|menu-bar|navigationlayout)/.test(identity)
  },
  {
    id: 'sidebar-signals',
    kind: 'sidebar',
    match: ({ tagName, identity }) => tagName === 'aside' || /(sidebar|sider|aside)/.test(identity)
  },
  {
    id: 'hero-keywords',
    kind: 'hero',
    match: ({ identity }) => /(hero|banner|kv|masthead|carousel|swiper|slick)/.test(identity)
  },
  {
    id: 'tab-signals',
    kind: 'tabs',
    match: ({ identity, hasTabs }) => /(tab|tabs)/.test(identity) || hasTabs
  },
  {
    id: 'product-density',
    kind: 'product-grid',
    match: (signals = {}) => {
      const {
        identity,
        textContent,
        stats = {},
        hasStableIdentity,
        isGenericIdentity,
        looksLikeDetailContent
      } = signals;

      return !looksLikeDetailContent
        && (!isGenericIdentity || hasStableIdentity || /(product|goods|sku|recommend|floor|card|commodity)/.test(identity))
        && (
          /(product|goods|sku|recommend|floor|card|commodity)/.test(identity)
          || containsAnyTerm(textContent, getActiveVmallTextHints(signals, 'productGrid'))
        )
        && (stats.imageCount >= 2 || stats.childCount >= 3)
        && (stats.htmlLength >= 600 || stats.imageCount >= 3);
    }
  },
  {
    id: 'feature-keywords',
    kind: 'feature-list',
    match: ({ identity, isGenericIdentity, looksLikeDetailContent }) => {
      return /(service|feature|benefit|advantage)/.test(identity)
        && !isGenericIdentity
        && !looksLikeDetailContent;
    }
  },
  {
    id: 'gallery-density',
    kind: 'gallery',
    match: ({ identity, stats }) => /(gallery|album)/.test(identity) && stats.imageCount >= 3
  },
  {
    id: 'promo-keywords',
    kind: 'promo-strip',
    match: ({ identity }) => /(promo|campaign|activity|sale|coupon)/.test(identity)
  },
  {
    id: 'table-grid-structure',
    kind: 'table',
    match: ({ identity, hasTable, stats }) => (/(table|list|grid)/.test(identity) || hasTable) && stats.childCount >= 2
  },
  {
    id: 'form-input-signals',
    kind: 'form',
    match: ({ identity, stats = {}, isGenericIdentity }) => {
      const hasFormKeyword = /(form|filter)/.test(identity);
      const hasSearchKeyword = /search/.test(identity);

      return stats.inputCount >= 2
        || (!isGenericIdentity && (hasFormKeyword || (hasSearchKeyword && stats.inputCount >= 1)));
    }
  },
  {
    id: 'dense-visual-grid',
    kind: 'content-grid',
    match: ({ stats }) => stats.imageCount >= 4 && stats.childCount >= 4
  }
];

const BLOCK_KIND_RULES = [
  {
    id: 'footer-signals',
    kind: 'footer',
    match: ({ identity, textContent }) => /footer|copyright|warrant|legal|vbiz-footer/.test(identity) || /隐私政策|服务协议|版权所有|备案|友情链接/.test(textContent)
  },
  {
    id: 'detail-anchor-signals',
    kind: 'detail-anchor-bar',
    match: (signals = {}) => {
      const { compactText, textContent } = signals;
      return /详情参数评价/.test(compactText)
        && containsAnyTerm(textContent, getActiveVmallList(signals, 'purchaseActionLabels'));
    }
  },
  {
    id: 'review-feed-signals',
    kind: 'review-feed',
    match: (signals = {}) => {
      const { identity, textContent } = signals;
      return /prd-reviews|reviewsscrollviewid|prd-reviews-tl/.test(identity)
        || containsAnyTerm(textContent, getActiveVmallTextHints(signals, 'reviewFeed'));
    }
  },
  {
    id: 'legal-notice-signals',
    kind: 'legal-notice',
    match: (signals = {}) => containsAnyTerm(signals.textContent, getActiveVmallTextHints(signals, 'legalNotice'))
  },
  {
    id: 'spec-list-signals',
    kind: 'spec-list',
    match: (signals = {}) => {
      const { textContent, stats = {} } = signals;
      return (
      /主要参数|规格参数/.test(textContent)
      || (containsAnyTerm(textContent, getActiveVmallTextHints(signals, 'specList')) && stats.childCount >= 8)
      );
    }
  },
  {
    id: 'top-bar-signals',
    kind: 'top-bar',
    match: ({ identity }) => /header|nav|navigation|toolbar|topbar|top-bar|menu-bar|navigationlayout/.test(identity)
  },
  {
    id: 'overlay-signals',
    kind: 'floating-layer',
    match: ({ looksLikeOverlay }) => looksLikeOverlay
  },
  {
    id: 'product-detail-signals',
    kind: 'product-detail-hero',
    match: ({ identity }) => /product[_-]content[_-]box|product[_-]gallery[_-]box|prd[_-]gallery|prd[_-]detail|product-installment-menu/.test(identity)
  },
  {
    id: 'recommend-shelf-signals',
    kind: 'recommend-shelf',
    match: (signals = {}) => {
      const { identity, textContent } = signals;
      return /rndiyweb|recommenditem/.test(identity)
        || containsAnyTerm(textContent, getActiveVmallList(signals, 'recommendationHeadings'));
    }
  },
  {
    id: 'detail-content-signals',
    kind: 'detail-content',
    match: ({ identity, loweredText, textContent, stats = {} }) => {
      return /proddetail|detail-content|detailcontent/.test(identity)
        || /richtextcontent/.test(loweredText)
        || ((/图文详情|商品详情/.test(textContent) || /richtextcontent/.test(identity)) && stats.htmlLength >= 2000);
    }
  },
  {
    id: 'hero-banner-signals',
    kind: 'hero-media',
    match: (signals = {}) => {
      const { identity, idCandidate, textContent, stats = {} } = signals;
      return (
      /picture-whole|hero|banner|kv|masthead/.test(identity) || /^picture-whole-\d+$/.test(idCandidate || '')
    ) && !(containsAnyTerm(textContent, getActiveVmallTextHints(signals, 'serviceStrip')))
      && (stats.imageCount >= 3 || stats.htmlLength >= 5000)
      ;
    }
  },
  {
    id: 'promo-banner-fragment',
    kind: 'promo-banner',
    match: (signals = {}) => {
      const { identity, idCandidate, textContent, stats = {} } = signals;
      return (
      /picture-whole|hero|banner|kv|masthead/.test(identity) || /^picture-whole-\d+$/.test(idCandidate || '')
    ) && !(containsAnyTerm(textContent, getActiveVmallTextHints(signals, 'serviceStrip')))
      && !(stats.imageCount >= 3 || stats.htmlLength >= 5000)
      ;
    }
  },
  {
    id: 'service-strip-signals',
    kind: 'service-strip',
    match: (signals = {}) => {
      const { identity, textContent, looksLikeDetailContent } = signals;
      return !looksLikeDetailContent
        && (
          /service|support|benefit|warrant/.test(identity)
          || containsAnyTerm(textContent, getActiveVmallTextHints(signals, 'serviceStrip'))
        );
    }
  },
  {
    id: 'icon-grid-signals',
    kind: 'icon-grid',
    match: ({ identity, stats = {}, textContent, looksLikeDetailContent }) => {
      if (looksLikeDetailContent) {
        return false;
      }

      return /icon\s*grid|icongrid/.test(identity)
        || (
          /(feature|benefit)/.test(identity)
          && stats.childCount >= 4
          && textContent.length <= 160
        )
        || (stats.imageCount >= 8 && stats.childCount >= 4 && textContent.length <= 120);
    }
  },
  {
    id: 'product-shelf-signals',
    kind: 'featured-shelf',
    match: (signals = {}) => {
      const { identity, textContent, loweredText, stats = {}, looksLikeDetailContent } = signals;
      return !looksLikeDetailContent && (
      (/(product|goods|sku|recommend|floor|card|commodity|prod-)/.test(identity)
      || ((/更多|立即购买|¥/.test(textContent) || /buy|price/.test(loweredText)) && stats.imageCount >= 3))
      && containsAnyTerm(textContent, getActiveVmallTextHints(signals, 'featuredShelf'))
      && !/更多/.test(textContent)
      );
    }
  },
  {
    id: 'product-shelf-signals',
    kind: 'product-shelf',
    match: ({ identity, textContent, loweredText, stats = {}, looksLikeDetailContent }) => (
      !looksLikeDetailContent && (
      /(product|goods|sku|recommend|floor|card|commodity|prod-)/.test(identity)
      || ((/更多|立即购买|¥/.test(textContent) || /buy|price/.test(loweredText)) && stats.imageCount >= 3)
      )
    )
  },
  {
    id: 'dense-media-cluster',
    kind: 'media-cluster',
    match: ({ stats }) => stats.imageCount >= 4 && stats.childCount >= 3
  }
];

const SECTION_RULE_MATCHERS = SECTION_KIND_RULES.concat([
  {
    id: 'dense-visual-grid',
    match: ({ stats }) => stats.imageCount >= 4 && stats.childCount >= 4
  }
]);

const BLOCK_RULE_MATCHERS = [
  {
    id: 'footer-signals',
    match: ({ blockKind, identity }) => blockKind === 'footer' || /footer|copyright|warrant|legal|vbiz-footer/.test(identity)
  },
  {
    id: 'top-bar-signals',
    match: ({ blockKind, identity }) => blockKind === 'top-bar' || /header|nav|navigation|toolbar|topbar|top-bar|menu-bar|navigationlayout/.test(identity)
  },
  {
    id: 'product-detail-signals',
    match: ({ blockKind, identity }) => blockKind === 'product-detail-hero' || /product[_-]content[_-]box|product[_-]gallery[_-]box|prd[_-]gallery|prd[_-]detail/.test(identity)
  },
  {
    id: 'overlay-signals',
    match: ({ blockKind, looksLikeOverlay }) => blockKind === 'floating-layer' || looksLikeOverlay
  },
  {
    id: 'icon-grid-signals',
    match: ({ blockKind, identity, stats = {}, textContent = '', looksLikeDetailContent }) => {
      if (blockKind === 'icon-grid') {
        return true;
      }

      if (looksLikeDetailContent) {
        return false;
      }

      return /icon\s*grid|icongrid/.test(identity)
        || (
          /(feature|benefit)/.test(identity)
          && stats.childCount >= 4
          && textContent.length <= 160
        )
        || (stats.imageCount >= 8 && stats.childCount >= 4 && textContent.length <= 120);
    }
  },
  {
    id: 'service-strip-signals',
    match: (signals = {}) => {
      const { blockKind, textContent, looksLikeDetailContent } = signals;
      return !looksLikeDetailContent
        && (
          blockKind === 'service-strip'
          || containsAnyTerm(textContent, getActiveVmallTextHints(signals, 'serviceStrip'))
        );
    }
  },
  {
    id: 'hero-banner-signals',
    match: ({ blockKind, identity }) => blockKind === 'hero-media' || /picture-whole|hero|banner|kv|masthead/.test(identity)
  },
  {
    id: 'promo-banner-fragment',
    match: ({ blockKind }) => blockKind === 'promo-banner'
  },
  {
    id: 'featured-product-signals',
    match: ({ blockKind }) => blockKind === 'featured-shelf'
  },
  {
    id: 'product-shelf-signals',
    match: ({ blockKind, identity }) => blockKind === 'product-shelf' || /(product|goods|sku|recommend|floor|card|commodity|prod-)/.test(identity)
  },
  {
    id: 'recommend-shelf-signals',
    match: (signals = {}) => {
      const { blockKind, identity, textContent } = signals;
      return blockKind === 'recommend-shelf'
        || /rndiyweb|recommenditem/.test(identity)
        || containsAnyTerm(textContent, getActiveVmallList(signals, 'recommendationHeadings'));
    }
  },
  {
    id: 'detail-anchor-signals',
    match: ({ blockKind, compactText }) => blockKind === 'detail-anchor-bar' || /详情参数评价/.test(compactText)
  },
  {
    id: 'detail-content-signals',
    match: ({ blockKind, identity, loweredText, looksLikeDetailContent }) => {
      return blockKind === 'detail-content'
        || looksLikeDetailContent
        || /richtextcontent|主要参数/.test(identity + loweredText);
    }
  },
  {
    id: 'spec-list-signals',
    match: (signals = {}) => {
      const { blockKind, textContent } = signals;
      return blockKind === 'spec-list'
        || containsAnyTerm(textContent, getActiveVmallTextHints(signals, 'specList'));
    }
  },
  {
    id: 'legal-notice-signals',
    match: (signals = {}) => {
      const { blockKind, textContent } = signals;
      return blockKind === 'legal-notice'
        || containsAnyTerm(textContent, getActiveVmallTextHints(signals, 'legalNotice'));
    }
  },
  {
    id: 'review-feed-signals',
    match: ({ blockKind, identity, textContent }) => blockKind === 'review-feed' || /prd-reviews|评价/.test(identity + textContent)
  },
  {
    id: 'dense-media-cluster',
    match: ({ stats }) => stats.imageCount >= 4 && stats.childCount >= 3
  },
  {
    id: 'stable-dom-identity',
    match: ({ hasStableIdentity }) => hasStableIdentity
  }
];

function inferSectionKindFromSignals(signals = {}) {
  return SECTION_KIND_RULES.find((rule) => rule.match(signals))?.kind || 'main-content';
}

function inferBlockKindFromSignals(signals = {}) {
  return BLOCK_KIND_RULES.find((rule) => rule.match(signals))?.kind || 'content-block';
}

function collectSectionRuleMatchesFromSignals(signals = {}) {
  return SECTION_RULE_MATCHERS.filter((rule) => rule.match(signals)).map((rule) => rule.id);
}

function collectBlockRuleMatchesFromSignals(signals = {}) {
  return SECTION_RULE_MATCHERS
    .filter((rule) => rule.match(signals))
    .map((rule) => rule.id)
    .concat(BLOCK_RULE_MATCHERS.filter((rule) => rule.match(signals)).map((rule) => rule.id))
    .filter((value, index, list) => list.indexOf(value) === index);
}

function matchesStableIdentityHint(identity = '', siteAdapter = null) {
  const hints = Array.isArray(siteAdapter?.stableIdentityHints)
    ? siteAdapter.stableIdentityHints.map((value) => String(value || '').trim()).filter(Boolean)
    : [];
  if (!hints.length) {
    return false;
  }

  const pattern = new RegExp(`(${hints.join('|')})`);
  return pattern.test(String(identity || ''));
}

module.exports = {
  BLOCKABLE_SECTION_KINDS,
  BLOCK_SECTION_PROMOTION_KINDS,
  GENERATOR_SELECTORS,
  STRONG_SECTION_KINDS,
  collectBlockRuleMatchesFromSignals,
  collectSectionRuleMatchesFromSignals,
  inferBlockKindFromSignals,
  inferSectionKindFromSignals,
  matchesAnchorTabLabel,
  matchesStableIdentityHint
};
