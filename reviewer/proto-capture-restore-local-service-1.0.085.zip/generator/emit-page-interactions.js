const TAB_ROUTE_VIEW_KINDS = new Set(['tab', 'root-tab']);

function normalizeRegistryViewKind(view) {
  return String(view?.kind || '').trim();
}

function buildTabRouteTargets(registry = null) {
  const views = Array.isArray(registry?.views) ? registry.views : [];
  const eligibleViews = views.filter((view) => (
    String(view?.id || '').trim()
    && String(view?.routeId || '').trim()
  ));
  const tabLikeViews = eligibleViews.filter((view) => TAB_ROUTE_VIEW_KINDS.has(normalizeRegistryViewKind(view)));
  const sourceViews = tabLikeViews.length >= 2 ? tabLikeViews : eligibleViews;
  const seenRouteIds = new Set();

  return sourceViews.reduce((targets, view) => {
    const viewId = String(view?.id || '').trim();
    const routeId = String(view?.routeId || '').trim();
    if (!viewId || !routeId || seenRouteIds.has(routeId)) {
      return targets;
    }

    seenRouteIds.add(routeId);
    targets.push({
      index: targets.length,
      viewId,
      routeId,
      label: String(view?.label || view?.title || view?.id || '').trim(),
      isDefault: Boolean(view?.isDefault)
    });
    return targets;
  }, []);
}

function resolveRouteAwareTabsInteraction(pageIR, tabRouteTargets = []) {
  if (tabRouteTargets.length < 2) {
    return {
      interactionId: '',
      matchingInteractionIds: [],
      reason: 'insufficient-tab-routes'
    };
  }

  const sections = Array.isArray(pageIR?.sections) ? pageIR.sections : [];
  const sectionById = new Map(sections.map((section) => [String(section?.id || ''), section]));
  const interactions = Array.isArray(pageIR?.interactions) ? pageIR.interactions : [];
  const matchingCandidates = interactions.filter((interaction) => (
    interaction
    && interaction.kind === 'tabs'
    && Number(interaction.itemCount || 0) === tabRouteTargets.length
  ));
  const matchingInteractionIds = matchingCandidates
    .map((interaction) => String(interaction?.id || '').trim())
    .filter(Boolean);

  if (!matchingCandidates.length) {
    return {
      interactionId: '',
      matchingInteractionIds,
      reason: 'no-tabs-candidate'
    };
  }

  const tabsSectionCandidates = matchingCandidates.filter((interaction) => {
    return sectionById.get(String(interaction?.sectionId || ''))?.kind === 'tabs';
  });

  if (tabsSectionCandidates.length === 1) {
    return {
      interactionId: String(tabsSectionCandidates[0]?.id || '').trim(),
      matchingInteractionIds,
      reason: 'matched-tabs-section'
    };
  }

  if (tabsSectionCandidates.length > 1) {
    return {
      interactionId: '',
      matchingInteractionIds,
      reason: 'ambiguous-tabs-section'
    };
  }

  if (matchingCandidates.length === 1) {
    return {
      interactionId: String(matchingCandidates[0]?.id || '').trim(),
      matchingInteractionIds,
      reason: 'matched-single-tabs'
    };
  }

  return {
    interactionId: '',
    matchingInteractionIds,
    reason: 'ambiguous-tabs-candidate'
  };
}

function appendInteractionDiagnostic(interaction, diagnostic) {
  if (!diagnostic) {
    return interaction;
  }

  const existingDiagnostics = Array.isArray(interaction?.interactionDiagnostics)
    ? interaction.interactionDiagnostics.map((value) => String(value || '').trim()).filter(Boolean)
    : [];
  if (existingDiagnostics.includes(diagnostic)) {
    return interaction;
  }

  return {
    ...interaction,
    interactionDiagnostics: existingDiagnostics.concat(diagnostic)
  };
}

function enrichInteractionDescriptors(pageIR, registry = null) {
  const interactions = Array.isArray(pageIR?.interactions) ? pageIR.interactions : [];
  const tabRouteTargets = buildTabRouteTargets(registry);
  const routeAwareResolution = resolveRouteAwareTabsInteraction(pageIR, tabRouteTargets);
  const ambiguousRouteTabs = new Set(
    routeAwareResolution.reason.startsWith('ambiguous')
      ? routeAwareResolution.matchingInteractionIds
      : []
  );

  return interactions.map((rawInteraction) => {
    if (!rawInteraction) {
      return rawInteraction;
    }

    let interaction = {
      ...rawInteraction,
      interactionMode: String(rawInteraction?.interactionMode || '').trim()
        || (rawInteraction.kind === 'dismissible' ? 'disabled' : 'local')
    };

    if (!String(interaction.scopeRootSelector || '').trim()) {
      interaction = appendInteractionDiagnostic(interaction, 'missing-scope-root-selector');
    }

    if (interaction.kind === 'dismissible') {
      return appendInteractionDiagnostic({
        ...interaction,
        interactionMode: 'disabled'
      }, 'dismissible-disabled');
    }

    if (interaction.kind !== 'tabs') {
      return interaction;
    }

    const interactionId = String(interaction.id || '').trim();
    if (ambiguousRouteTabs.has(interactionId)) {
      return appendInteractionDiagnostic({
        ...interaction,
        interactionMode: 'disabled'
      }, 'tabs-mode-ambiguous');
    }

    if (routeAwareResolution.interactionId && interactionId === routeAwareResolution.interactionId) {
      return {
        ...interaction,
        interactionMode: 'view-switch',
        currentRouteId: pageIR.routeId,
        tabRoutes: tabRouteTargets
      };
    }

    return {
      ...interaction,
      interactionMode: interaction.interactionMode || 'local'
    };
  });
}

function buildPreviewInteractionScript(descriptors = []) {
  const serializedDescriptors = JSON.stringify(descriptors)
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e');

  return `(function () {
  if (typeof window === 'undefined' || typeof document === 'undefined') {
    return;
  }

  const descriptors = ${serializedDescriptors};
  const params = new URLSearchParams(window.location.search);
  const debugEnabled = params.get('debugInteractions') === '1';
  const root = document.getElementById('root');
  if (!root) {
    return;
  }

  const ACTIVE_CLASS_NAMES = ['active', 'is-active', 'selected', 'current', 'ant-tabs-tab-active', 'hammer-tabs-tab-active'];
  const debugState = {
    missing: [],
    bound: [],
    actions: []
  };

  function normalizeRouteValue(value) {
    return String(value || '').replace(/^\\/+|\\/+$/g, '');
  }

  function getOrderedTabRoutes(descriptor, tabCount) {
    const tabRoutes = Array.isArray(descriptor.tabRoutes) ? descriptor.tabRoutes : [];
    return tabRoutes
      .filter((target) => Number.isFinite(Number(target && target.index)))
      .sort((left, right) => Number(left.index || 0) - Number(right.index || 0))
      .filter((target, index) => index < tabCount);
  }

  function resolveCurrentPreviewPath() {
    try {
      const url = new URL(window.location.href);
      return normalizeRouteValue(url.searchParams.get('path') || '');
    } catch (_error) {
      return '';
    }
  }

  function resolveCurrentRouteIndex(routeTargets, descriptor) {
    const descriptorRouteId = normalizeRouteValue(descriptor.currentRouteId || '');
    const previewPath = resolveCurrentPreviewPath();
    const currentRouteId = descriptorRouteId || previewPath;
    return routeTargets.findIndex((target) => normalizeRouteValue(target.routeId || '') === currentRouteId);
  }

  function buildPreviewHref(routeId) {
    const normalizedRouteId = normalizeRouteValue(routeId);
    if (!normalizedRouteId) {
      return '';
    }

    try {
      const url = new URL(window.location.href);
      if (/\\/preview\\/?$/.test(url.pathname)) {
        url.searchParams.set('path', normalizedRouteId);
        return url.toString();
      }
    } catch (_error) {
      // Fall through to relative preview URL.
    }

    return '/preview?path=' + encodeURIComponent(normalizedRouteId);
  }

  function setNodeActive(node, active) {
    ACTIVE_CLASS_NAMES.forEach((className) => {
      if (active) {
        node.classList.add(className);
      } else {
        node.classList.remove(className);
      }
    });

    if (node.getAttribute('role') === 'tab' || node.hasAttribute('aria-selected')) {
      node.setAttribute('aria-selected', active ? 'true' : 'false');
      node.setAttribute('tabindex', active ? '0' : '-1');
    }
  }

  function markBound(scopeRoot, descriptor) {
    if (!debugEnabled || !scopeRoot) {
      return;
    }

    scopeRoot.dataset.protorecDebugBound = descriptor.id;
    scopeRoot.dataset.protorecDebugKind = descriptor.kind;
    scopeRoot.dataset.protorecDebugOwnerBlockId = String(descriptor.ownerBlockId || '');
    scopeRoot.dataset.protorecDebugProtocolLevel = String(descriptor.protocolLevel || 'full');
    scopeRoot.dataset.protorecDebugInteractionMode = String(descriptor.interactionMode || 'local');
  }

  function markAction(scopeRoot, descriptor, action, detail) {
    if (!debugEnabled || !scopeRoot) {
      return;
    }

    const suffix = detail === undefined ? action : action + ':' + String(detail);
    scopeRoot.dataset.protorecDebugLastAction = suffix;
    debugState.actions.push({
      id: descriptor.id,
      action,
      detail: detail === undefined ? null : detail
    });
  }

  function registerMissing(descriptor, reason) {
    if (!debugEnabled) {
      return;
    }

    debugState.missing.push({
      id: descriptor.id,
      kind: descriptor.kind,
      reason
    });
  }

  function getInteractionMode(descriptor) {
    const normalizedMode = String(descriptor && descriptor.interactionMode || '').trim();
    if (normalizedMode === 'view-switch' || normalizedMode === 'disabled') {
      return normalizedMode;
    }

    return descriptor && descriptor.kind === 'dismissible' ? 'disabled' : 'local';
  }

  function resolveScopeRoot(rootNode, descriptor, expectedKind) {
    const selector = String(descriptor && descriptor.scopeRootSelector || '').trim();
    if (!selector) {
      registerMissing(descriptor, 'missing-scope-root-selector');
      return null;
    }

    let matches = [];
    try {
      matches = Array.from(rootNode.querySelectorAll(selector)).filter((candidate) => candidate instanceof HTMLElement);
    } catch (_error) {
      registerMissing(descriptor, 'invalid-scope-root-selector');
      return null;
    }

    if (matches.length !== 1) {
      registerMissing(descriptor, matches.length ? 'ambiguous-scope-root' : 'missing-scope-root');
      return null;
    }

    const scopeRoot = matches[0];
    const scopeKind = String(scopeRoot.getAttribute('data-protorec-interaction-kind') || '').trim();
    if (expectedKind && scopeKind && scopeKind !== expectedKind) {
      registerMissing(descriptor, 'scope-root-kind-mismatch');
      return null;
    }

    return scopeRoot;
  }

  function bindTabs(descriptor) {
    const scopeRoot = resolveScopeRoot(root, descriptor, 'tabs');
    if (!scopeRoot) {
      return function () {};
    }

    const tabs = Array.from(scopeRoot.querySelectorAll('[data-protorec-tab-index][data-protorec-interaction-id="' + descriptor.id + '"]'))
      .sort((left, right) => Number(left.dataset.protorecTabIndex || 0) - Number(right.dataset.protorecTabIndex || 0));
    if (tabs.length < 2) {
      registerMissing(descriptor, 'insufficient-tabs');
      return function () {};
    }

    const panels = Array.from(scopeRoot.querySelectorAll('[data-protorec-panel-index][data-protorec-interaction-id="' + descriptor.id + '"]'))
      .sort((left, right) => Number(left.dataset.protorecPanelIndex || 0) - Number(right.dataset.protorecPanelIndex || 0));
    const interactionMode = getInteractionMode(descriptor);
    const routeTargets = getOrderedTabRoutes(descriptor, tabs.length);
    const shouldNavigateBetweenViews = interactionMode === 'view-switch';
    if (shouldNavigateBetweenViews && routeTargets.length < tabs.length) {
      registerMissing(descriptor, 'missing-tab-routes');
      return function () {};
    }

    const currentRouteIndex = shouldNavigateBetweenViews
      ? resolveCurrentRouteIndex(routeTargets, descriptor)
      : -1;
    const canSyncPanelsToRoute = shouldNavigateBetweenViews
      && panels.length >= tabs.length
      && panels.length > 1;
    const activate = (index) => {
      tabs.forEach((tab, tabIndex) => {
        tab.dataset.protorecTabActive = tabIndex === index ? 'true' : 'false';
        setNodeActive(tab, tabIndex === index);
      });

      if ((!shouldNavigateBetweenViews || canSyncPanelsToRoute) && panels.length) {
        const safePanelIndex = Math.max(0, Math.min(index, panels.length - 1));
        panels.forEach((panel, panelIndex) => {
          const isActive = panelIndex === safePanelIndex;
          panel.dataset.protorecPanelActive = isActive ? 'true' : 'false';
          panel.hidden = !isActive;
        });
      } else {
        panels.forEach((panel) => {
          panel.dataset.protorecPanelActive = 'true';
          panel.hidden = false;
        });
      }

      markAction(scopeRoot, descriptor, 'activate', index);
    };

    const initialIndex = tabs.findIndex((tab) => tab.dataset.protorecTabActive === 'true');
    const resolvedInitialIndex = currentRouteIndex >= 0
      ? currentRouteIndex
      : (initialIndex >= 0 ? initialIndex : Math.max(0, descriptor.defaultIndex || 0));
    activate(resolvedInitialIndex);
    markBound(scopeRoot, descriptor);
    debugState.bound.push({ id: descriptor.id, kind: descriptor.kind });

    const cleanups = tabs.map((tab) => {
      const index = Number(tab.dataset.protorecTabIndex || 0);
      const onClick = (event) => {
        event.preventDefault();
        if (shouldNavigateBetweenViews) {
          const routeTarget = routeTargets.find((target) => Number(target.index || 0) === index);
          const targetRouteId = normalizeRouteValue(routeTarget && routeTarget.routeId);
          const currentRouteId = normalizeRouteValue(descriptor.currentRouteId || '') || resolveCurrentPreviewPath();
          if (targetRouteId && targetRouteId !== currentRouteId) {
            const nextHref = buildPreviewHref(targetRouteId);
            if (nextHref) {
              markAction(scopeRoot, descriptor, 'navigate', targetRouteId);
              window.location.assign(nextHref);
              return;
            }
          }
        }

        activate(index);
      };

      tab.addEventListener('click', onClick);
      return function () { tab.removeEventListener('click', onClick); };
    });

    return function () {
      cleanups.forEach((cleanup) => cleanup());
    };
  }

  function bindCarousel(descriptor) {
    const scopeRoot = resolveScopeRoot(root, descriptor, 'carousel');
    if (!scopeRoot) {
      return function () {};
    }

    const slideSelector = '[data-protorec-slide-index][data-protorec-interaction-id="' + descriptor.id + '"]';
    const rawSlides = Array.from(scopeRoot.querySelectorAll(slideSelector))
      .filter((slide) => !slide.querySelector(slideSelector))
      .sort((left, right) => Number(left.dataset.protorecSlideIndex || 0) - Number(right.dataset.protorecSlideIndex || 0));
    const logicalSlides = (() => {
      const nonClonedSlides = rawSlides.filter((slide) => !slide.classList.contains('slick-cloned'));
      return nonClonedSlides.length >= 2 ? nonClonedSlides : rawSlides;
    })();
    const logicalSlideCount = logicalSlides.length;
    if (logicalSlideCount < 2) {
      registerMissing(descriptor, 'insufficient-slides');
      return function () {};
    }

    const controls = Array.from(scopeRoot.querySelectorAll('[data-protorec-interaction-id="' + descriptor.id + '"]'))
      .filter((control) => control.matches('[data-protorec-carousel-prev], [data-protorec-carousel-next], [data-protorec-slide-target]'));
    if (!controls.length) {
      registerMissing(descriptor, 'missing-carousel-controls');
      return function () {};
    }

    const track = scopeRoot.querySelector('.slick-track');
    const usesTrackLayout = Boolean(
      track
      && rawSlides.some((slide) => slide.closest('.slick-track') === track)
    );

    const getLogicalIndex = (slide) => {
      if (!slide) {
        return -1;
      }

      const rawIndex = Number(slide.getAttribute('data-index'));
      if (Number.isFinite(rawIndex) && logicalSlideCount > 0) {
        const normalizedIndex = rawIndex % logicalSlideCount;
        return normalizedIndex < 0 ? normalizedIndex + logicalSlideCount : normalizedIndex;
      }

      const fallbackIndex = logicalSlides.indexOf(slide);
      return fallbackIndex >= 0 ? fallbackIndex : -1;
    };

    const trackAxis = (() => {
      if (!usesTrackLayout || !(track instanceof HTMLElement)) {
        return 'x';
      }

      const translate3dMatch = String(track.style.transform || '').match(/translate3d\\(\\s*([-+]?\\d+(?:\\.\\d+)?)px,\\s*([-+]?\\d+(?:\\.\\d+)?)px/i);
      if (translate3dMatch) {
        const translateX = Number(translate3dMatch[1] || 0);
        const translateY = Number(translate3dMatch[2] || 0);
        if (Math.abs(translateY) > Math.abs(translateX)) {
          return 'y';
        }
      }

      const maxOffsetLeft = rawSlides.reduce((maxOffset, slide) => Math.max(maxOffset, slide.offsetLeft), 0);
      const maxOffsetTop = rawSlides.reduce((maxOffset, slide) => Math.max(maxOffset, slide.offsetTop), 0);
      return maxOffsetTop > maxOffsetLeft ? 'y' : 'x';
    })();

    const resolveAnchorSlide = (safeIndex) => {
      const preferredSlide = logicalSlides[safeIndex];
      if (preferredSlide) {
        return preferredSlide;
      }

      return rawSlides.find((slide) => getLogicalIndex(slide) === safeIndex) || rawSlides[0];
    };

    const syncTrackToSlide = (anchorSlide) => {
      if (!usesTrackLayout || !(track instanceof HTMLElement) || !(anchorSlide instanceof HTMLElement)) {
        return;
      }

      const offset = trackAxis === 'y' ? anchorSlide.offsetTop : anchorSlide.offsetLeft;
      const normalizedOffset = Math.max(0, Math.round(offset));
      track.style.transform = trackAxis === 'y'
        ? 'translate3d(0px, -' + String(normalizedOffset) + 'px, 0px)'
        : 'translate3d(-' + String(normalizedOffset) + 'px, 0px, 0px)';
    };

    const activate = (nextIndex) => {
      const safeIndex = (nextIndex + logicalSlideCount) % logicalSlideCount;
      const anchorSlide = resolveAnchorSlide(safeIndex);
      rawSlides.forEach((slide) => {
        const logicalIndex = getLogicalIndex(slide);
        const isActive = slide === anchorSlide;
        slide.dataset.protorecSlideLogicalIndex = logicalIndex >= 0 ? String(logicalIndex) : '';
        slide.dataset.protorecSlideActive = isActive ? 'true' : 'false';

        if (usesTrackLayout) {
          slide.hidden = false;
          slide.style.removeProperty('display');
          slide.setAttribute('aria-hidden', isActive ? 'false' : 'true');
          slide.style.pointerEvents = isActive ? 'auto' : 'none';
          slide.classList.toggle('slick-current', isActive);
          slide.classList.toggle('slick-active', isActive);
          setNodeActive(slide, isActive);
          return;
        }

        slide.hidden = !isActive;
        setNodeActive(slide, isActive);
      });

      syncTrackToSlide(anchorSlide);
      controls.forEach((control) => {
        if (!control.hasAttribute('data-protorec-slide-target')) {
          return;
        }

        const controlIndex = Number(control.dataset.protorecSlideTarget || 0);
        const isActive = controlIndex === safeIndex;
        control.dataset.protorecSlideActive = isActive ? 'true' : 'false';
        setNodeActive(control, isActive);
      });
      markAction(scopeRoot, descriptor, 'activate', safeIndex);
    };

    const initialRawSlide = rawSlides.find((slide) => (
      slide.dataset.protorecSlideActive === 'true'
      || slide.classList.contains('slick-current')
      || slide.classList.contains('slick-active')
      || slide.getAttribute('aria-hidden') === 'false'
    ));
    const initialIndex = getLogicalIndex(initialRawSlide);
    activate(initialIndex >= 0 ? initialIndex : 0);
    markBound(scopeRoot, descriptor);
    debugState.bound.push({ id: descriptor.id, kind: descriptor.kind });

    const cleanups = controls.map((control) => {
      const onClick = (event) => {
        event.preventDefault();
        const activeIndex = getLogicalIndex(rawSlides.find((slide) => slide.dataset.protorecSlideActive === 'true'));
        if (control.hasAttribute('data-protorec-carousel-prev')) {
          activate((activeIndex >= 0 ? activeIndex : 0) - 1);
          return;
        }

        if (control.hasAttribute('data-protorec-carousel-next')) {
          activate((activeIndex >= 0 ? activeIndex : 0) + 1);
          return;
        }

        const explicitTarget = Number(control.dataset.protorecSlideTarget || 0);
        activate(explicitTarget);
      };

      control.addEventListener('click', onClick);
      return function () { control.removeEventListener('click', onClick); };
    });

    return function () {
      cleanups.forEach((cleanup) => cleanup());
    };
  }

  function bindPassiveSlickCarousels(rootNode) {
    const sliders = Array.from(rootNode.querySelectorAll('.slick-slider'))
      .filter((slider) => !slider.closest('[data-protorec-interaction-kind="carousel"]'));

    const cleanups = sliders.map((slider) => {
      const track = slider.querySelector('.slick-track');
      if (!(track instanceof HTMLElement)) {
        return function () {};
      }

      const rawSlides = Array.from(track.children)
        .filter((slide) => slide instanceof HTMLElement && slide.classList.contains('slick-slide'));
      const logicalSlides = (() => {
        const nonClonedSlides = rawSlides.filter((slide) => !slide.classList.contains('slick-cloned'));
        return nonClonedSlides.length >= 2 ? nonClonedSlides : rawSlides;
      })();
      const logicalSlideCount = logicalSlides.length;
      if (logicalSlideCount < 2) {
        return function () {};
      }

      const dotButtons = Array.from(slider.querySelectorAll('.slick-dots li button'));
      const prevButtons = Array.from(slider.querySelectorAll('.slick-prev'));
      const nextButtons = Array.from(slider.querySelectorAll('.slick-next'));
      const translate3dMatch = String(track.style.transform || '').match(/translate3d\\(\\s*([-+]?\\d+(?:\\.\\d+)?)px,\\s*([-+]?\\d+(?:\\.\\d+)?)px/i);
      const trackAxis = (() => {
        if (translate3dMatch) {
          const translateX = Number(translate3dMatch[1] || 0);
          const translateY = Number(translate3dMatch[2] || 0);
          if (Math.abs(translateY) > Math.abs(translateX)) {
            return 'y';
          }
        }

        const maxOffsetLeft = rawSlides.reduce((maxOffset, slide) => Math.max(maxOffset, slide.offsetLeft), 0);
        const maxOffsetTop = rawSlides.reduce((maxOffset, slide) => Math.max(maxOffset, slide.offsetTop), 0);
        return maxOffsetTop > maxOffsetLeft ? 'y' : 'x';
      })();

      const getLogicalIndex = (slide) => {
        if (!slide) {
          return -1;
        }

        const rawIndex = Number(slide.getAttribute('data-index'));
        if (Number.isFinite(rawIndex) && logicalSlideCount > 0) {
          const normalizedIndex = rawIndex % logicalSlideCount;
          return normalizedIndex < 0 ? normalizedIndex + logicalSlideCount : normalizedIndex;
        }

        const fallbackIndex = logicalSlides.indexOf(slide);
        return fallbackIndex >= 0 ? fallbackIndex : -1;
      };

      const syncTrackToSlide = (anchorSlide) => {
        if (!(anchorSlide instanceof HTMLElement)) {
          return;
        }

        const offset = trackAxis === 'y' ? anchorSlide.offsetTop : anchorSlide.offsetLeft;
        const normalizedOffset = Math.max(0, Math.round(offset));
        track.style.transform = trackAxis === 'y'
          ? 'translate3d(0px, -' + String(normalizedOffset) + 'px, 0px)'
          : 'translate3d(-' + String(normalizedOffset) + 'px, 0px, 0px)';
      };

      const activate = (nextIndex) => {
        const safeIndex = (nextIndex + logicalSlideCount) % logicalSlideCount;
        const anchorSlide = logicalSlides[safeIndex] || rawSlides.find((slide) => getLogicalIndex(slide) === safeIndex) || rawSlides[0];

        rawSlides.forEach((slide) => {
          const logicalIndex = getLogicalIndex(slide);
          const isAnchorSlide = slide === anchorSlide;
          slide.dataset.protorecPassiveSlickIndex = logicalIndex >= 0 ? String(logicalIndex) : '';
          slide.dataset.protorecPassiveSlickActive = isAnchorSlide ? 'true' : 'false';
          slide.hidden = false;
          slide.style.removeProperty('display');
          slide.setAttribute('aria-hidden', isAnchorSlide ? 'false' : 'true');
          slide.style.pointerEvents = isAnchorSlide ? 'auto' : 'none';
          slide.classList.toggle('slick-current', isAnchorSlide);
          slide.classList.toggle('slick-active', isAnchorSlide);
        });

        syncTrackToSlide(anchorSlide);

        dotButtons.forEach((button, index) => {
          const isActive = index === safeIndex;
          if (button.parentElement) {
            button.parentElement.classList.toggle('slick-active', isActive);
          }
        });

        slider.dataset.protorecPassiveSlickActiveIndex = String(safeIndex);
      };

      const initialSlide = rawSlides.find((slide) => (
        slide.dataset.protorecPassiveSlickActive === 'true'
        || slide.classList.contains('slick-current')
        || slide.classList.contains('slick-active')
        || slide.getAttribute('aria-hidden') === 'false'
      ));
      const initialIndex = getLogicalIndex(initialSlide);
      activate(initialIndex >= 0 ? initialIndex : 0);

      const listeners = [];
      dotButtons.forEach((button, index) => {
        const onClick = (event) => {
          event.preventDefault();
          activate(index);
        };
        button.addEventListener('click', onClick);
        listeners.push(() => button.removeEventListener('click', onClick));
      });

      prevButtons.forEach((button) => {
        const onClick = (event) => {
          event.preventDefault();
          const activeIndex = Number(slider.dataset.protorecPassiveSlickActiveIndex || 0);
          activate(activeIndex - 1);
        };
        button.addEventListener('click', onClick);
        listeners.push(() => button.removeEventListener('click', onClick));
      });

      nextButtons.forEach((button) => {
        const onClick = (event) => {
          event.preventDefault();
          const activeIndex = Number(slider.dataset.protorecPassiveSlickActiveIndex || 0);
          activate(activeIndex + 1);
        };
        button.addEventListener('click', onClick);
        listeners.push(() => button.removeEventListener('click', onClick));
      });

      return function () {
        listeners.forEach((cleanup) => cleanup());
      };
    });

    return function () {
      cleanups.forEach((cleanup) => cleanup());
    };
  }

  function bindDismissible(descriptor) {
    registerMissing(descriptor, 'disabled-mode');
    return function () {};
  }

  function bindDropdown(descriptor) {
    const scopeRoot = resolveScopeRoot(root, descriptor, 'dropdown');
    if (!scopeRoot) {
      return function () {};
    }

    const trigger = scopeRoot.querySelector('[data-protorec-dropdown-trigger="' + descriptor.id + '"]');
    const menu = scopeRoot.querySelector('[data-protorec-dropdown-menu="' + descriptor.id + '"]');
    if (!trigger || !menu) {
      registerMissing(descriptor, 'missing-trigger-or-menu');
      return function () {};
    }

    const setOpen = (open) => {
      scopeRoot.dataset.protorecOpen = open ? 'true' : 'false';
      menu.hidden = !open;
      menu.setAttribute('aria-hidden', open ? 'false' : 'true');
      setNodeActive(trigger, open);
      markAction(scopeRoot, descriptor, open ? 'open' : 'close');
    };

    setOpen(false);
    markBound(scopeRoot, descriptor);
    debugState.bound.push({ id: descriptor.id, kind: descriptor.kind });

    const onTriggerClick = (event) => {
      event.preventDefault();
      setOpen(scopeRoot.dataset.protorecOpen !== 'true');
    };
    const onRootClick = (event) => {
      if (!(event.target instanceof Node) || scopeRoot.contains(event.target)) {
        return;
      }

      setOpen(false);
    };
    const onRootKeyDown = (event) => {
      if (event.key === 'Escape') {
        setOpen(false);
      }
    };

    trigger.addEventListener('click', onTriggerClick);
    root.addEventListener('click', onRootClick);
    root.addEventListener('keydown', onRootKeyDown);

    return function () {
      trigger.removeEventListener('click', onTriggerClick);
      root.removeEventListener('click', onRootClick);
      root.removeEventListener('keydown', onRootKeyDown);
    };
  }

  function bindDescriptor(descriptor) {
    if (Array.isArray(descriptor && descriptor.interactionDiagnostics)) {
      descriptor.interactionDiagnostics.forEach((diagnostic) => registerMissing(descriptor, diagnostic));
    }

    if (getInteractionMode(descriptor) === 'disabled') {
      return bindDismissible(descriptor);
    }

    switch (descriptor.kind) {
      case 'tabs':
        return bindTabs(descriptor);
      case 'carousel':
        return bindCarousel(descriptor);
      case 'dismissible':
        return bindDismissible(descriptor);
      case 'dropdown':
        return bindDropdown(descriptor);
      default:
        return function () {};
    }
  }

  const cleanups = descriptors.map(bindDescriptor);
  const passiveSlickCleanup = bindPassiveSlickCarousels(root);
  if (debugEnabled) {
    window.__PROTOREC_PREVIEW_INTERACTIONS__ = debugState;
  }

  window.addEventListener('beforeunload', function () {
    passiveSlickCleanup();
    cleanups.forEach((cleanup) => cleanup());
  }, { once: true });
})();`;
}

function emitPageInteractions(pageIR, { registry = null } = {}) {
  const interactionDescriptors = enrichInteractionDescriptors(pageIR, registry);
  return `import React from 'react';

export type InteractionDescriptor = {
  id: string;
  kind: 'tabs' | 'carousel' | 'dismissible' | 'dropdown';
  sectionId: string;
  ownerBlockId?: string | null;
  protocolLevel?: 'full' | 'fallback';
  label: string;
  confidence: number;
  itemCount: number;
  defaultIndex?: number;
  scopeRootId?: string;
  scopeRootSelector?: string;
  interactionMode?: 'local' | 'view-switch' | 'disabled';
  interactionDiagnostics?: string[];
  currentRouteId?: string;
  tabRoutes?: Array<{
    index: number;
    viewId: string;
    routeId: string;
    label: string;
    isDefault: boolean;
  }>;
};

export const pageInteractions: InteractionDescriptor[] = ${JSON.stringify(interactionDescriptors, null, 2)};
export const previewInteractionScript = ${JSON.stringify(buildPreviewInteractionScript(interactionDescriptors))};

const ACTIVE_CLASS_NAMES = ['active', 'is-active', 'selected', 'current', 'ant-tabs-tab-active', 'hammer-tabs-tab-active'];

function setNodeActive(node: Element, active: boolean) {
  ACTIVE_CLASS_NAMES.forEach((className) => {
    if (active) {
      node.classList.add(className);
    } else {
      node.classList.remove(className);
    }
  });

  if (node.getAttribute('role') === 'tab' || node.hasAttribute('aria-selected')) {
    node.setAttribute('aria-selected', active ? 'true' : 'false');
    node.setAttribute('tabindex', active ? '0' : '-1');
  }
}

function normalizeRouteValue(value: string | undefined) {
  return String(value || '').replace(/^\\/+|\\/+$/g, '');
}

function getOrderedTabRoutes(descriptor: InteractionDescriptor, tabCount: number) {
  const tabRoutes = Array.isArray(descriptor.tabRoutes) ? descriptor.tabRoutes : [];
  return tabRoutes
    .filter((target) => Number.isFinite(Number(target && target.index)))
    .sort((left, right) => Number(left.index || 0) - Number(right.index || 0))
    .filter((_target, index) => index < tabCount);
}

function resolveCurrentPreviewPath() {
  try {
    const url = new URL(window.location.href);
    return normalizeRouteValue(url.searchParams.get('path') || '');
  } catch (_error) {
    return '';
  }
}

function resolveCurrentRouteIndex(
  routeTargets: NonNullable<InteractionDescriptor['tabRoutes']>,
  descriptor: InteractionDescriptor
) {
  const descriptorRouteId = normalizeRouteValue(descriptor.currentRouteId);
  const previewPath = resolveCurrentPreviewPath();
  const currentRouteId = descriptorRouteId || previewPath;
  return routeTargets.findIndex((target) => normalizeRouteValue(target.routeId) === currentRouteId);
}

function buildPreviewHref(routeId: string) {
  const normalizedRouteId = normalizeRouteValue(routeId);
  if (!normalizedRouteId) {
    return '';
  }

  try {
    const url = new URL(window.location.href);
    if (/\\/preview\\/?$/.test(url.pathname)) {
      url.searchParams.set('path', normalizedRouteId);
      return url.toString();
    }
  } catch (_error) {
    // Fall through to relative preview URL.
  }

  return \`/preview?path=\${encodeURIComponent(normalizedRouteId)}\`;
}

function getInteractionMode(descriptor: InteractionDescriptor): 'local' | 'view-switch' | 'disabled' {
  const normalizedMode = String(descriptor.interactionMode || '').trim();
  if (normalizedMode === 'view-switch' || normalizedMode === 'disabled') {
    return normalizedMode;
  }

  return descriptor.kind === 'dismissible' ? 'disabled' : 'local';
}

function resolveScopeRoot(
  root: HTMLElement,
  descriptor: InteractionDescriptor,
  expectedKind: InteractionDescriptor['kind']
) {
  const selector = String(descriptor.scopeRootSelector || '').trim();
  if (!selector) {
    return null;
  }

  let matches: HTMLElement[] = [];
  try {
    matches = Array.from(root.querySelectorAll<HTMLElement>(selector));
  } catch (_error) {
    return null;
  }

  if (matches.length !== 1) {
    return null;
  }

  const scopeRoot = matches[0];
  const scopeKind = String(scopeRoot.getAttribute('data-protorec-interaction-kind') || '').trim();
  if (expectedKind && scopeKind && scopeKind !== expectedKind) {
    return null;
  }

  return scopeRoot;
}

function bindTabs(root: HTMLElement, descriptor: InteractionDescriptor) {
  const scopeRoot = resolveScopeRoot(root, descriptor, 'tabs');
  if (!scopeRoot) {
    return () => undefined;
  }

  const tabs = Array.from(scopeRoot.querySelectorAll<HTMLElement>(\`[data-protorec-tab-index][data-protorec-interaction-id="\${descriptor.id}"]\`))
    .sort((left, right) => Number(left.dataset.protorecTabIndex || 0) - Number(right.dataset.protorecTabIndex || 0));
  if (tabs.length < 2) {
    return () => undefined;
  }

  const panels = Array.from(scopeRoot.querySelectorAll<HTMLElement>(\`[data-protorec-panel-index][data-protorec-interaction-id="\${descriptor.id}"]\`))
    .sort((left, right) => Number(left.dataset.protorecPanelIndex || 0) - Number(right.dataset.protorecPanelIndex || 0));
  const interactionMode = getInteractionMode(descriptor);
  const routeTargets = getOrderedTabRoutes(descriptor, tabs.length);
  const shouldNavigateBetweenViews = interactionMode === 'view-switch';
  if (shouldNavigateBetweenViews && routeTargets.length < tabs.length) {
    return () => undefined;
  }

  const currentRouteIndex = shouldNavigateBetweenViews
    ? resolveCurrentRouteIndex(routeTargets, descriptor)
    : -1;
  const canSyncPanelsToRoute = shouldNavigateBetweenViews
    && panels.length >= tabs.length
    && panels.length > 1;
  const activate = (index: number) => {
    tabs.forEach((tab, tabIndex) => {
      tab.dataset.protorecTabActive = tabIndex === index ? 'true' : 'false';
      setNodeActive(tab, tabIndex === index);
    });

    if ((!shouldNavigateBetweenViews || canSyncPanelsToRoute) && panels.length) {
      const safePanelIndex = Math.max(0, Math.min(index, panels.length - 1));
      panels.forEach((panel, panelIndex) => {
        const isActive = panelIndex === safePanelIndex;
        panel.dataset.protorecPanelActive = isActive ? 'true' : 'false';
        panel.hidden = !isActive;
      });
      return;
    }

    panels.forEach((panel) => {
      panel.dataset.protorecPanelActive = 'true';
      panel.hidden = false;
    });
  };

  const initialIndex = tabs.findIndex((tab) => tab.dataset.protorecTabActive === 'true');
  const resolvedInitialIndex = currentRouteIndex >= 0
    ? currentRouteIndex
    : (initialIndex >= 0 ? initialIndex : Math.max(0, descriptor.defaultIndex || 0));
  activate(resolvedInitialIndex);

  const cleanups = tabs.map((tab) => {
    const index = Number(tab.dataset.protorecTabIndex || 0);
    const onClick = (event: Event) => {
      event.preventDefault();
      if (shouldNavigateBetweenViews) {
        const routeTarget = routeTargets.find((target) => Number(target.index || 0) === index);
        const targetRouteId = normalizeRouteValue(routeTarget?.routeId);
        const currentRouteId = normalizeRouteValue(descriptor.currentRouteId) || resolveCurrentPreviewPath();
        if (targetRouteId && targetRouteId !== currentRouteId) {
          const nextHref = buildPreviewHref(targetRouteId);
          if (nextHref) {
            window.location.assign(nextHref);
            return;
          }
        }
      }

      activate(index);
    };

    tab.addEventListener('click', onClick);
    return () => tab.removeEventListener('click', onClick);
  });

  return () => cleanups.forEach((cleanup) => cleanup());
}

function bindDismissible(_root: HTMLElement, _descriptor: InteractionDescriptor) {
  return () => undefined;
}

function bindCarousel(root: HTMLElement, descriptor: InteractionDescriptor) {
  const scopeRoot = resolveScopeRoot(root, descriptor, 'carousel');
  if (!scopeRoot) {
    return () => undefined;
  }

  const slideSelector = \`[data-protorec-slide-index][data-protorec-interaction-id="\${descriptor.id}"]\`;
  const rawSlides = Array.from(scopeRoot.querySelectorAll<HTMLElement>(slideSelector))
    .filter((slide) => !slide.querySelector(slideSelector))
    .sort((left, right) => Number(left.dataset.protorecSlideIndex || 0) - Number(right.dataset.protorecSlideIndex || 0));
  const logicalSlides = (() => {
    const nonClonedSlides = rawSlides.filter((slide) => !slide.classList.contains('slick-cloned'));
    return nonClonedSlides.length >= 2 ? nonClonedSlides : rawSlides;
  })();
  const logicalSlideCount = logicalSlides.length;
  if (logicalSlideCount < 2) {
    return () => undefined;
  }

  const controls = Array.from(scopeRoot.querySelectorAll<HTMLElement>(\`[data-protorec-interaction-id="\${descriptor.id}"]\`))
    .filter((control) => control.matches('[data-protorec-carousel-prev], [data-protorec-carousel-next], [data-protorec-slide-target]'));
  if (!controls.length) {
    return () => undefined;
  }

  const track = scopeRoot.querySelector<HTMLElement>('.slick-track');
  const usesTrackLayout = Boolean(
    track
    && rawSlides.some((slide) => slide.closest('.slick-track') === track)
  );

  const getLogicalIndex = (slide: HTMLElement | undefined) => {
    if (!slide) {
      return -1;
    }

    const rawIndex = Number(slide.getAttribute('data-index'));
    if (Number.isFinite(rawIndex) && logicalSlideCount > 0) {
      const normalizedIndex = rawIndex % logicalSlideCount;
      return normalizedIndex < 0 ? normalizedIndex + logicalSlideCount : normalizedIndex;
    }

    const fallbackIndex = logicalSlides.indexOf(slide);
    return fallbackIndex >= 0 ? fallbackIndex : -1;
  };

  const trackAxis: 'x' | 'y' = (() => {
    if (!usesTrackLayout || !(track instanceof HTMLElement)) {
      return 'x';
    }

    const translate3dMatch = String(track.style.transform || '').match(/translate3d\\(\\s*([-+]?\\d+(?:\\.\\d+)?)px,\\s*([-+]?\\d+(?:\\.\\d+)?)px/i);
    if (translate3dMatch) {
      const translateX = Number(translate3dMatch[1] || 0);
      const translateY = Number(translate3dMatch[2] || 0);
      if (Math.abs(translateY) > Math.abs(translateX)) {
        return 'y';
      }
    }

    const maxOffsetLeft = rawSlides.reduce((maxOffset, slide) => Math.max(maxOffset, slide.offsetLeft), 0);
    const maxOffsetTop = rawSlides.reduce((maxOffset, slide) => Math.max(maxOffset, slide.offsetTop), 0);
    return maxOffsetTop > maxOffsetLeft ? 'y' : 'x';
  })();

  const resolveAnchorSlide = (safeIndex: number) => {
    const preferredSlide = logicalSlides[safeIndex];
    if (preferredSlide) {
      return preferredSlide;
    }

    return rawSlides.find((slide) => getLogicalIndex(slide) === safeIndex) || rawSlides[0];
  };

  const syncTrackToSlide = (anchorSlide: HTMLElement | undefined) => {
    if (!usesTrackLayout || !(track instanceof HTMLElement) || !(anchorSlide instanceof HTMLElement)) {
      return;
    }

    const offset = trackAxis === 'y' ? anchorSlide.offsetTop : anchorSlide.offsetLeft;
    const normalizedOffset = Math.max(0, Math.round(offset));
    track.style.transform = trackAxis === 'y'
      ? 'translate3d(0px, -' + String(normalizedOffset) + 'px, 0px)'
      : 'translate3d(-' + String(normalizedOffset) + 'px, 0px, 0px)';
  };

  const activate = (nextIndex: number) => {
    const safeIndex = (nextIndex + logicalSlideCount) % logicalSlideCount;
    const anchorSlide = resolveAnchorSlide(safeIndex);
    rawSlides.forEach((slide) => {
      const logicalIndex = getLogicalIndex(slide);
      const isAnchorSlide = slide === anchorSlide;
      slide.dataset.protorecSlideLogicalIndex = logicalIndex >= 0 ? String(logicalIndex) : '';
      slide.dataset.protorecSlideActive = isAnchorSlide ? 'true' : 'false';

      if (usesTrackLayout) {
        slide.hidden = false;
        slide.style.removeProperty('display');
        slide.setAttribute('aria-hidden', isAnchorSlide ? 'false' : 'true');
        slide.style.pointerEvents = isAnchorSlide ? 'auto' : 'none';
        slide.classList.toggle('slick-current', isAnchorSlide);
        slide.classList.toggle('slick-active', isAnchorSlide);
        setNodeActive(slide, isAnchorSlide);
        return;
      }

      slide.hidden = !isAnchorSlide;
      setNodeActive(slide, isAnchorSlide);
    });

    syncTrackToSlide(anchorSlide);
    controls.forEach((control) => {
      if (!control.hasAttribute('data-protorec-slide-target')) {
        return;
      }

      const controlIndex = Number(control.dataset.protorecSlideTarget || 0);
      const isActive = controlIndex === safeIndex;
      control.dataset.protorecSlideActive = isActive ? 'true' : 'false';
      setNodeActive(control, isActive);
    });
  };

  const initialRawSlide = rawSlides.find((slide) => (
    slide.dataset.protorecSlideActive === 'true'
    || slide.classList.contains('slick-current')
    || slide.classList.contains('slick-active')
    || slide.getAttribute('aria-hidden') === 'false'
  ));
  const initialIndex = getLogicalIndex(initialRawSlide);
  activate(initialIndex >= 0 ? initialIndex : 0);

  const cleanups = controls.map((control) => {
    const onClick = (event: Event) => {
      event.preventDefault();
      const activeIndex = getLogicalIndex(rawSlides.find((slide) => slide.dataset.protorecSlideActive === 'true'));
      if (control.hasAttribute('data-protorec-carousel-prev')) {
        activate((activeIndex >= 0 ? activeIndex : 0) - 1);
        return;
      }

      if (control.hasAttribute('data-protorec-carousel-next')) {
        activate((activeIndex >= 0 ? activeIndex : 0) + 1);
        return;
      }

      const explicitTarget = Number(control.dataset.protorecSlideTarget || 0);
      activate(explicitTarget);
    };

    control.addEventListener('click', onClick);
    return () => control.removeEventListener('click', onClick);
  });

  return () => cleanups.forEach((cleanup) => cleanup());
}

function bindPassiveSlickCarousels(root: HTMLElement) {
  const sliders = Array.from(root.querySelectorAll<HTMLElement>('.slick-slider'))
    .filter((slider) => !slider.closest('[data-protorec-interaction-kind="carousel"]'));

  const cleanups = sliders.map((slider) => {
    const track = slider.querySelector<HTMLElement>('.slick-track');
    if (!(track instanceof HTMLElement)) {
      return () => undefined;
    }

    const rawSlides = Array.from(track.children)
      .filter((slide): slide is HTMLElement => slide instanceof HTMLElement && slide.classList.contains('slick-slide'));
    const logicalSlides = (() => {
      const nonClonedSlides = rawSlides.filter((slide) => !slide.classList.contains('slick-cloned'));
      return nonClonedSlides.length >= 2 ? nonClonedSlides : rawSlides;
    })();
    const logicalSlideCount = logicalSlides.length;
    if (logicalSlideCount < 2) {
      return () => undefined;
    }

    const dotButtons = Array.from(slider.querySelectorAll<HTMLButtonElement>('.slick-dots li button'));
    const prevButtons = Array.from(slider.querySelectorAll<HTMLElement>('.slick-prev'));
    const nextButtons = Array.from(slider.querySelectorAll<HTMLElement>('.slick-next'));
    const translate3dMatch = String(track.style.transform || '').match(/translate3d\\(\\s*([-+]?\\d+(?:\\.\\d+)?)px,\\s*([-+]?\\d+(?:\\.\\d+)?)px/i);
    const trackAxis: 'x' | 'y' = (() => {
      if (translate3dMatch) {
        const translateX = Number(translate3dMatch[1] || 0);
        const translateY = Number(translate3dMatch[2] || 0);
        if (Math.abs(translateY) > Math.abs(translateX)) {
          return 'y';
        }
      }

      const maxOffsetLeft = rawSlides.reduce((maxOffset, slide) => Math.max(maxOffset, slide.offsetLeft), 0);
      const maxOffsetTop = rawSlides.reduce((maxOffset, slide) => Math.max(maxOffset, slide.offsetTop), 0);
      return maxOffsetTop > maxOffsetLeft ? 'y' : 'x';
    })();

    const getLogicalIndex = (slide: HTMLElement | undefined) => {
      if (!slide) {
        return -1;
      }

      const rawIndex = Number(slide.getAttribute('data-index'));
      if (Number.isFinite(rawIndex) && logicalSlideCount > 0) {
        const normalizedIndex = rawIndex % logicalSlideCount;
        return normalizedIndex < 0 ? normalizedIndex + logicalSlideCount : normalizedIndex;
      }

      const fallbackIndex = logicalSlides.indexOf(slide);
      return fallbackIndex >= 0 ? fallbackIndex : -1;
    };

    const syncTrackToSlide = (anchorSlide: HTMLElement | undefined) => {
      if (!(anchorSlide instanceof HTMLElement)) {
        return;
      }

      const offset = trackAxis === 'y' ? anchorSlide.offsetTop : anchorSlide.offsetLeft;
      const normalizedOffset = Math.max(0, Math.round(offset));
      track.style.transform = trackAxis === 'y'
        ? 'translate3d(0px, -' + String(normalizedOffset) + 'px, 0px)'
        : 'translate3d(-' + String(normalizedOffset) + 'px, 0px, 0px)';
    };

    const activate = (nextIndex: number) => {
      const safeIndex = (nextIndex + logicalSlideCount) % logicalSlideCount;
      const anchorSlide = logicalSlides[safeIndex] || rawSlides.find((slide) => getLogicalIndex(slide) === safeIndex) || rawSlides[0];

      rawSlides.forEach((slide) => {
        const logicalIndex = getLogicalIndex(slide);
        const isAnchorSlide = slide === anchorSlide;
        slide.dataset.protorecPassiveSlickIndex = logicalIndex >= 0 ? String(logicalIndex) : '';
        slide.dataset.protorecPassiveSlickActive = isAnchorSlide ? 'true' : 'false';
        slide.hidden = false;
        slide.style.removeProperty('display');
        slide.setAttribute('aria-hidden', isAnchorSlide ? 'false' : 'true');
        slide.style.pointerEvents = isAnchorSlide ? 'auto' : 'none';
        slide.classList.toggle('slick-current', isAnchorSlide);
        slide.classList.toggle('slick-active', isAnchorSlide);
      });

      syncTrackToSlide(anchorSlide);

      dotButtons.forEach((button, index) => {
        const isActive = index === safeIndex;
        button.parentElement?.classList.toggle('slick-active', isActive);
      });

      slider.dataset.protorecPassiveSlickActiveIndex = String(safeIndex);
    };

    const initialSlide = rawSlides.find((slide) => (
      slide.dataset.protorecPassiveSlickActive === 'true'
      || slide.classList.contains('slick-current')
      || slide.classList.contains('slick-active')
      || slide.getAttribute('aria-hidden') === 'false'
    ));
    const initialIndex = getLogicalIndex(initialSlide);
    activate(initialIndex >= 0 ? initialIndex : 0);

    const listeners: Array<() => void> = [];
    dotButtons.forEach((button, index) => {
      const onClick = (event: Event) => {
        event.preventDefault();
        activate(index);
      };
      button.addEventListener('click', onClick);
      listeners.push(() => button.removeEventListener('click', onClick));
    });

    prevButtons.forEach((button) => {
      const onClick = (event: Event) => {
        event.preventDefault();
        const activeIndex = Number(slider.dataset.protorecPassiveSlickActiveIndex || 0);
        activate(activeIndex - 1);
      };
      button.addEventListener('click', onClick);
      listeners.push(() => button.removeEventListener('click', onClick));
    });

    nextButtons.forEach((button) => {
      const onClick = (event: Event) => {
        event.preventDefault();
        const activeIndex = Number(slider.dataset.protorecPassiveSlickActiveIndex || 0);
        activate(activeIndex + 1);
      };
      button.addEventListener('click', onClick);
      listeners.push(() => button.removeEventListener('click', onClick));
    });

    return () => listeners.forEach((cleanup) => cleanup());
  });

  return () => cleanups.forEach((cleanup) => cleanup());
}

function bindDropdown(root: HTMLElement, descriptor: InteractionDescriptor) {
  const scopeRoot = resolveScopeRoot(root, descriptor, 'dropdown');
  if (!scopeRoot) {
    return () => undefined;
  }

  const trigger = scopeRoot.querySelector<HTMLElement>(\`[data-protorec-dropdown-trigger="\${descriptor.id}"]\`);
  const menu = scopeRoot.querySelector<HTMLElement>(\`[data-protorec-dropdown-menu="\${descriptor.id}"]\`);
  if (!trigger || !menu) {
    return () => undefined;
  }

  const setOpen = (open: boolean) => {
    scopeRoot.dataset.protorecOpen = open ? 'true' : 'false';
    menu.hidden = !open;
    menu.setAttribute('aria-hidden', open ? 'false' : 'true');
    setNodeActive(trigger, open);
  };

  setOpen(false);

  const onTriggerClick = (event: Event) => {
    event.preventDefault();
    setOpen(scopeRoot.dataset.protorecOpen !== 'true');
  };
  const onRootClick = (event: Event) => {
    if (!(event.target instanceof Node) || scopeRoot.contains(event.target)) {
      return;
    }

    setOpen(false);
  };
  const onRootKeyDown = (event: KeyboardEvent) => {
    if (event.key === 'Escape') {
      setOpen(false);
    }
  };

  trigger.addEventListener('click', onTriggerClick);
  root.addEventListener('click', onRootClick);
  root.addEventListener('keydown', onRootKeyDown);

  return () => {
    trigger.removeEventListener('click', onTriggerClick);
    root.removeEventListener('click', onRootClick);
    root.removeEventListener('keydown', onRootKeyDown);
  };
}

function bindDescriptor(root: HTMLElement, descriptor: InteractionDescriptor) {
  if (getInteractionMode(descriptor) === 'disabled') {
    return bindDismissible(root, descriptor);
  }

  switch (descriptor.kind) {
    case 'tabs':
      return bindTabs(root, descriptor);
    case 'carousel':
      return bindCarousel(root, descriptor);
    case 'dismissible':
      return bindDismissible(root, descriptor);
    case 'dropdown':
      return bindDropdown(root, descriptor);
    default:
      return () => undefined;
  }
}

export function useProtoPageInteractions(
  rootRef: React.RefObject<HTMLElement>,
  descriptors: InteractionDescriptor[]
) {
  React.useEffect(() => {
    const root = rootRef.current;
    if (!root || typeof window === 'undefined') {
      return undefined;
    }

    const cleanups = descriptors.map((descriptor) => bindDescriptor(root, descriptor));
    const passiveSlickCleanup = bindPassiveSlickCarousels(root);
    return () => {
      passiveSlickCleanup();
      cleanups.forEach((cleanup) => cleanup());
    };
  }, [rootRef, descriptors]);
}
`;
}

module.exports = {
  emitPageInteractions,
  buildPreviewInteractionScript,
  enrichInteractionDescriptors
};
