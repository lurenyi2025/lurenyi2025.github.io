const path = require('path');

const SERVICE_ROOT = path.resolve(__dirname, '..');
const PROJECT_ROOT = path.resolve(SERVICE_ROOT, '..');
const SRC_ROOT = path.join(PROJECT_ROOT, 'src');
const PAGES_ROOT = path.join(SRC_ROOT, 'pages');
const PROTOTYPES_ROOT = path.join(SRC_ROOT, 'prototypes');
const PAGES_ASSETS_ROOT = path.join(PAGES_ROOT, 'assets');
const PAGE_IMAGES_ROOT = path.join(PAGES_ASSETS_ROOT, 'images');
const PAGE_FONTS_ROOT = path.join(PAGES_ASSETS_ROOT, 'fonts');
const META_ROOT = path.join(PROJECT_ROOT, '.protorec', 'pages');

const PROTOCOL_VERSION = '3.0';
const GENERATION_MODE = process.env.PROTOREC_GENERATION_MODE || 'balanced';
const PREVIEW_STATIC_ROOT = '/src-pages';
const PROTOTYPE_PREVIEW_STATIC_ROOT = '/src-prototypes';

const CONFIDENCE_THRESHOLDS = {
  ready: 0.78,
  flagged: 0.58
};

const EDITABILITY_THRESHOLDS = {
  ready: 78,
  workable: 58
};

module.exports = {
  SERVICE_ROOT,
  PROJECT_ROOT,
  SRC_ROOT,
  PAGES_ROOT,
  PROTOTYPES_ROOT,
  PAGES_ASSETS_ROOT,
  PAGE_IMAGES_ROOT,
  PAGE_FONTS_ROOT,
  META_ROOT,
  PROTOCOL_VERSION,
  GENERATION_MODE,
  PREVIEW_STATIC_ROOT,
  PROTOTYPE_PREVIEW_STATIC_ROOT,
  CONFIDENCE_THRESHOLDS,
  EDITABILITY_THRESHOLDS
};
