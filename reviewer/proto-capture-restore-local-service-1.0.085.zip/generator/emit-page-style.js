const { resolveSiteAdapterByUrl } = require('../adapters/site-registry');
const { sanitizeExtractedSourceCss } = require('./css-sanitizer');

function buildCssVarFallback(tokens = [], fallbackValue) {
  const normalizedTokens = Array.isArray(tokens)
    ? tokens.map((token) => String(token || '').trim()).filter(Boolean)
    : [];

  return normalizedTokens.reduceRight((result, token) => {
    return `var(${token}, ${result})`;
  }, fallbackValue);
}

function buildTokensCss(pageIR) {
  const pageClassName = `page-${pageIR.pageSlug}`;
  const siteAdapter = resolveSiteAdapterByUrl(pageIR.sourceUrl);
  const backgroundVarChain = buildCssVarFallback(siteAdapter?.pageThemeTokens?.background, '#f5f5f5');
  const surfaceVarChain = buildCssVarFallback(siteAdapter?.pageThemeTokens?.surface, '#ffffff');

  return [
    `.${pageClassName} {`,
    `  --protorec-page-bg: ${backgroundVarChain};`,
    `  --protorec-page-surface: ${surfaceVarChain};`,
    '  --protorec-page-text: #111827;',
    '  --protorec-page-muted: rgba(17, 24, 39, 0.6);',
    '  --protorec-page-border: rgba(17, 24, 39, 0.08);',
    '  --protorec-page-radius: 16px;',
    '  --protorec-page-gap: 24px;',
    '  min-height: 100vh;',
    '  color: var(--protorec-page-text);',
    '  background: var(--protorec-page-bg);',
    '}',
    '',
    `.${pageClassName}, .${pageClassName} * {`,
    '  box-sizing: border-box;',
    '}',
    '',
    `.${pageClassName} [hidden] {`,
    '  display: none !important;',
    '}',
    ''
  ].join('\n');
}

function buildSectionsCss(pageIR) {
  const pageClassName = `page-${pageIR.pageSlug}`;
  const preservedWorkbenchShellSections = Array.isArray(pageIR.sections)
    ? pageIR.sections.filter((section) => {
      return String(section?.diagnostics?.extraction?.reason || '').trim() === 'preserve-hammer-workbench-shell';
    })
    : [];
  const kindRules = pageIR.sections.map((section) => {
    const lines = [
      `.${pageClassName}__section--${section.id} {`
    ];

    if (section.kind === 'floating-layer') {
      lines.push('  z-index: 12;');
    } else if (section.kind === 'top-bar') {
      lines.push('  z-index: 8;');
    }

    if (section.kind === 'footer') {
      lines.push('  border-top: 1px solid var(--protorec-page-border);');
    }

    lines.push('}');
    return lines.join('\n');
  }).join('\n\n');
  const preservedWorkbenchSectionSelectors = preservedWorkbenchShellSections
    .map((section) => `.${pageClassName}[data-protorec-is-subview="false"] .${pageClassName}__section--${section.id}`);
  const preservedWorkbenchViewportCss = preservedWorkbenchSectionSelectors.length
    ? [
      `.${pageClassName}[data-protorec-is-subview="false"] {`,
      '  height: 100vh;',
      '  height: 100dvh;',
      '  min-height: 100vh;',
      '  min-height: 100dvh;',
      '  overflow: hidden;',
      '}',
      '',
      `${preservedWorkbenchSectionSelectors.join(',\n')} {`,
      '  position: relative;',
      '  height: 100%;',
      '  min-height: 100%;',
      '  overflow: hidden;',
      '}',
      '',
      `${[
        ...preservedWorkbenchSectionSelectors.map((selector) => `${selector} > *`),
        ...preservedWorkbenchSectionSelectors.map((selector) => `${selector} > .${pageClassName}__section-shell`)
      ].join(',\n')} {`,
      '  height: 100%;',
      '  min-height: 100%;',
      '}',
      '',
      `${[
        ...preservedWorkbenchSectionSelectors.map((selector) => `${selector} > * > .hammer-app`),
        ...preservedWorkbenchSectionSelectors.map((selector) => `${selector} > * > .hammer-layout`),
        ...preservedWorkbenchSectionSelectors.map((selector) => `${selector} > * > .hammer-pro-layout`),
        ...preservedWorkbenchSectionSelectors.map((selector) => `${selector} > .${pageClassName}__section-shell > *`),
        ...preservedWorkbenchSectionSelectors.map((selector) => `${selector} > .${pageClassName}__section-shell > * > .hammer-app`),
        ...preservedWorkbenchSectionSelectors.map((selector) => `${selector} > .${pageClassName}__section-shell > * > .hammer-layout`),
        ...preservedWorkbenchSectionSelectors.map((selector) => `${selector} > .${pageClassName}__section-shell > * > .hammer-pro-layout`)
      ].join(',\n')} {`,
      '  height: 100%;',
      '  min-height: 100%;',
      '}',
      ''
    ].join('\n')
    : '';

  return [
    `.${pageClassName} {`,
    '  position: relative;',
    '}',
    '',
    `.${pageClassName}__section {`,
    '  position: relative;',
    '}',
    '',
    `.${pageClassName}__section-shell {`,
    '  position: relative;',
    '}',
    '',
    `.${pageClassName} [data-protorec-interaction-kind="tabs"] [data-protorec-panel-index][data-protorec-panel-active="false"] {`,
    '  display: none;',
    '}',
    '',
    `.${pageClassName} [data-protorec-interaction-kind="dropdown"][data-protorec-open="false"] [data-protorec-dropdown-menu] {`,
    '  display: none;',
    '}',
    '',
    `.${pageClassName} .protorec-synthetic-dropdown-menu {`,
    '  position: absolute;',
    '  top: calc(100% + 4px);',
    '  left: 0;',
    '  z-index: 1050;',
    '  min-width: 100%;',
    '  width: max-content;',
    '  max-width: min(320px, calc(100vw - 16px));',
    '  max-height: min(320px, calc(100vh - 16px));',
    '  padding: 4px;',
    '  overflow: auto;',
    '  color: #262626;',
    '  white-space: nowrap;',
    '  background: #ffffff;',
    '  border-radius: 2px;',
    '  box-shadow: 0 6px 16px 0 rgba(0, 0, 0, 0.08), 0 3px 6px -4px rgba(0, 0, 0, 0.12), 0 9px 28px 8px rgba(0, 0, 0, 0.05);',
    '}',
    '',
    `.${pageClassName} .protorec-synthetic-dropdown-item {`,
    '  padding: 5px 12px;',
    '  border-radius: 2px;',
    '  line-height: 1.57143;',
    '}',
    '',
    `.${pageClassName} .protorec-synthetic-dropdown-item:hover {`,
    '  background: rgba(38, 38, 38, 0.04);',
    '}',
    '',
    `.${pageClassName} .hammer-menu .hammer-menu-submenu > .hammer-menu-submenu-title > .hammer-menu-submenu-expand-icon {`,
    '  display: flex;',
    '  align-items: center;',
    '  justify-content: center;',
    '  line-height: 1;',
    '  transform: translateY(-50%);',
    '}',
    '',
    `.${pageClassName} .hammer-menu .hammer-menu-submenu > .hammer-menu-submenu-title > .hammer-menu-submenu-expand-icon > svg {`,
    '  display: block;',
    '  width: 100%;',
    '  height: 100%;',
    '}',
    '',
    `.${pageClassName} [data-protorec-interaction-kind="dismissible"][data-protorec-closed="true"] {`,
    '  display: none !important;',
    '}',
    '',
    preservedWorkbenchViewportCss,
    kindRules,
    ''
  ].join('\n');
}

function buildSourceCss(pageIR, cssText) {
  const normalizedCssText = sanitizeExtractedSourceCss(cssText);
  return normalizedCssText
    ? ['/* ProtoRec extracted source styles */', normalizedCssText, ''].join('\n')
    : '/* ProtoRec extracted source styles: none */\n';
}

function emitPageStyles(pageIR) {
  const tokensCss = buildTokensCss(pageIR);
  const sectionsCss = buildSectionsCss(pageIR);
  const sourceCss = buildSourceCss(pageIR, pageIR.sourceCssText);
  const previewCss = [
    tokensCss,
    sectionsCss,
    buildSourceCss(pageIR, pageIR.previewCssText)
  ].join('\n');

  return {
    files: [
      [
        'style.css',
        [
          tokensCss,
          sectionsCss,
          sourceCss,
          ''
        ].join('\n')
      ]
    ],
    previewCss
  };
}

module.exports = {
  emitPageStyles
};
