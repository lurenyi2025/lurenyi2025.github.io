const { isEditRouteLitePilotSlug } = require('./edit-route-lite-fragment-compact');

function normalizeRouteId(pageIR = {}) {
  return String(pageIR.routeId || pageIR.pageSlug || '').trim();
}

function hasPilotSchema(schema = {}) {
  return Boolean(schema.tableSchema || schema.filterSchema || schema.menuSchema);
}

function isSingleViewPage(pageIR = {}) {
  const view = pageIR.view || {};
  return !view.isSubview && String(view.viewKind || 'page') === 'page';
}

function isEditMapPilotPage(pageIR = {}) {
  const routeId = normalizeRouteId(pageIR);
  if (!isEditRouteLitePilotSlug(routeId)) {
    return false;
  }

  if (!isSingleViewPage(pageIR)) {
    return false;
  }

  return hasPilotSchema(pageIR.semanticSchemas || {});
}

function compactArray(values = []) {
  return Array.from(new Set(
    values
      .map((value) => String(value || '').trim())
      .filter(Boolean)
  ));
}

function normalizeEmittedFragmentPaths(values = []) {
  return new Set(compactArray(values));
}

function fragmentPathFor(blockId, emittedFragmentPaths) {
  const fragmentPath = `fragments/${blockId}.tsx`;
  return emittedFragmentPaths.has(fragmentPath) ? fragmentPath : '';
}

function selectorAnchors(selector = '') {
  const normalized = String(selector || '').trim();
  if (!normalized) {
    return [];
  }
  return [normalized];
}

function createAvailableBlock({
  blockId,
  semanticType,
  schema,
  semanticPath,
  fragmentPath,
  cssAnchors,
  supportedEdits
}) {
  const block = {
    blockId,
    semanticType,
    capability: 'available',
    semanticPath,
    rootSelector: String(schema?.selector || '').trim(),
    cssAnchors: compactArray(cssAnchors),
    supportedEdits: compactArray(supportedEdits),
    fallbackMode: 'whole-page-ai-rewrite',
    diagnostics: {
      schemaId: String(schema?.id || ''),
      schemaConfidence: Number(schema?.confidence || 0),
      schemaSource: String(schema?.diagnostics?.source || ''),
      fragmentStatus: fragmentPath ? 'emitted' : 'not-emitted'
    }
  };

  if (fragmentPath) {
    block.fragmentPath = fragmentPath;
  }

  return block;
}

function createMissingBlock({ blockId, semanticType, reason }) {
  return {
    blockId,
    semanticType,
    capability: 'missing',
    supportedEdits: [],
    fallbackMode: 'whole-page-ai-rewrite',
    diagnostics: {
      reason,
      fragmentStatus: 'not-emitted'
    }
  };
}

function emitEditMapObject(pageIR = {}) {
  return emitEditMapObjectWithOptions(pageIR);
}

function emitEditMapObjectWithOptions(pageIR = {}, options = {}) {
  const routeId = normalizeRouteId(pageIR);
  const schema = pageIR.semanticSchemas || {};
  const emittedFragmentPaths = normalizeEmittedFragmentPaths(options.emittedFragmentPaths || []);
  const blocks = [];
  const diagnostics = [];

  if (schema.tableSchema) {
    blocks.push(createAvailableBlock({
      blockId: 'table',
      semanticType: 'table',
      schema: schema.tableSchema,
      semanticPath: 'semantic/table.ts',
      fragmentPath: fragmentPathFor('table', emittedFragmentPaths),
      cssAnchors: selectorAnchors(schema.tableSchema.selector).concat([
        'table',
        '[role="table"]',
        '.ant-table',
        '.el-table',
        '.datatable-table'
      ]),
      supportedEdits: [
        'rename-label',
        'visibility',
        'reorder',
        'edit-cell-value',
        'action-label'
      ]
    }));
  } else {
    diagnostics.push('table-schema-unavailable');
  }

  if (schema.filterSchema) {
    blocks.push(createAvailableBlock({
      blockId: 'filter',
      semanticType: 'filter',
      schema: schema.filterSchema,
      semanticPath: 'semantic/filter.ts',
      fragmentPath: fragmentPathFor('filter', emittedFragmentPaths),
      cssAnchors: selectorAnchors(schema.filterSchema.selector).concat([
        'form',
        '.ant-pro-query-filter',
        '.ant-form',
        '.filter',
        '.search'
      ]),
      supportedEdits: [
        'rename-label',
        'visibility',
        'field-label',
        'field-visibility',
        'collapse'
      ]
    }));
  } else if (routeId === 'plugins-data-tables-html') {
    blocks.push(createMissingBlock({
      blockId: 'filter',
      semanticType: 'filter',
      reason: 'filter-schema-unavailable'
    }));
  } else {
    diagnostics.push('filter-schema-unavailable');
  }

  if (schema.menuSchema) {
    blocks.push(createAvailableBlock({
      blockId: 'menu',
      semanticType: 'menu',
      schema: schema.menuSchema,
      semanticPath: 'semantic/menu.ts',
      fragmentPath: fragmentPathFor('menu', emittedFragmentPaths),
      cssAnchors: selectorAnchors(schema.menuSchema.selector).concat([
        'aside',
        'nav',
        '[role="navigation"]',
        '[role="menu"]',
        '.ant-menu',
        '.drawer-menu',
        '.sidenav-menu'
      ]),
      supportedEdits: [
        'rename-label',
        'visibility',
        'item-label',
        'add-item'
      ]
    }));
  } else {
    diagnostics.push('menu-schema-unavailable');
  }

  return {
    version: 1,
    mode: 'edit-route-lite',
    phase: 'edit-map-only',
    slug: routeId,
    pilot: true,
    status: blocks.some((block) => block.capability === 'available') ? 'available' : 'low-confidence',
    blocks,
    diagnostics: compactArray([
      ...(Array.isArray(schema.diagnostics) ? schema.diagnostics : []),
      emittedFragmentPaths.size ? 'fragments-sidecar-emitted' : '',
      ...diagnostics
    ])
  };
}

function emitEditMap(pageIR = {}, options = {}) {
  if (!isEditMapPilotPage(pageIR)) {
    return [];
  }

  return [
    ['edit-map.json', JSON.stringify(emitEditMapObjectWithOptions(pageIR, options), null, 2)]
  ];
}

module.exports = {
  emitEditMap,
  emitEditMapObject,
  emitEditMapObjectWithOptions,
  isEditMapPilotPage
};
