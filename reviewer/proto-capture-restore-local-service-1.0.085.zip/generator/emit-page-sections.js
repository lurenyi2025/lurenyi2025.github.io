function emitSharedSectionRuntime() {
  return `import React from 'react';

export type ContextWrapper = {
  tagName: string;
  attrs: Record<string, string>;
  selectorHint?: string;
  reason?: string;
};

export type SectionMeta = {
  id: string;
  title: string;
  kind: string;
  confidence: number;
  summary: string;
  renderMode: string;
  shellTag: string;
  componentName: string;
  interactionIds: string[];
  pageClassName: string;
  blockCount: number;
  contextWrappers: ContextWrapper[];
  diagnostics: Record<string, unknown> | null;
};

export type SectionBlockMeta = {
  id: string;
  sectionId: string;
  title: string;
  kind: string;
  confidence: number;
  summary: string;
  renderMode: string;
  componentName: string;
  fileName: string;
  parentComponentName: string;
  pageClassName: string;
  interactionIds: string[];
  contextWrappers: ContextWrapper[];
  diagnostics: Record<string, unknown> | null;
};

export const PreviewLayoutContext = React.createContext<{
  isSubview: boolean;
  activeContextWrappers: ContextWrapper[];
}>({
  isSubview: false,
  activeContextWrappers: []
});

const CONTEXT_OVERFLOW_PROPERTIES = new Set([
  'overflow',
  'overflow-x',
  'overflow-y'
]);

function sanitizeContextStyleText(
  styleText: string,
  reason = '',
  options: {
    isSubview?: boolean;
  } = {}
) {
  const normalizedReason = String(reason || '').trim().toLowerCase();
  const isSubview = Boolean(options.isSubview);
  if (!styleText.trim()) {
    return '';
  }

  return String(styleText || '')
    .split(';')
    .map((entry) => entry.trim())
    .filter(Boolean)
    .filter((declaration) => {
      const separatorIndex = declaration.indexOf(':');
      if (separatorIndex < 0) {
        return false;
      }

      const property = declaration.slice(0, separatorIndex).trim().toLowerCase();
      const value = declaration.slice(separatorIndex + 1).trim().toLowerCase();
      if (!property || !value) {
        return false;
      }

      if (!normalizedReason) {
        return true;
      }

      if (CONTEXT_OVERFLOW_PROPERTIES.has(property)) {
        return false;
      }

      if (
        isSubview
        && ['height', 'min-height', 'max-height'].includes(property)
        && /(calc\\([^;]*100(?:d|s|l)?vh|100(?:d|s|l)?vh)\\b/.test(value)
      ) {
        return false;
      }

      return true;
    })
    .join('; ');
}

function styleTextToObject(styleText: string) {
  return String(styleText || '')
    .split(';')
    .map((entry) => entry.trim())
    .filter(Boolean)
    .reduce<Record<string, string>>((result, declaration) => {
      const separatorIndex = declaration.indexOf(':');
      if (separatorIndex < 0) {
        return result;
      }

      const property = declaration.slice(0, separatorIndex).trim();
      const value = declaration.slice(separatorIndex + 1).trim();
      if (!property || !value) {
        return result;
      }

      if (property.startsWith('--')) {
        result[property] = value;
        return result;
      }

      const reactProperty = property.replace(/-([a-z])/g, (_, character) => character.toUpperCase());
      result[reactProperty] = value;
      return result;
    }, {});
}

function buildContextProps(
  attrs: Record<string, string> = {},
  options: {
    reason?: string;
    isSubview?: boolean;
  } = {}
) {
  const props: Record<string, unknown> = {};
  const reason = String(options.reason || '');
  const isSubview = Boolean(options.isSubview);

  Object.entries(attrs).forEach(([name, value]) => {
    if (name === 'class') {
      props.className = value;
      return;
    }

    if (name === 'style') {
      const sanitizedStyleText = sanitizeContextStyleText(value, reason, {
        isSubview
      });
      if (sanitizedStyleText.trim()) {
        props.style = styleTextToObject(sanitizedStyleText);
      }
      return;
    }

    if (name === 'tabindex') {
      const numericTabIndex = Number(value);
      props.tabIndex = Number.isFinite(numericTabIndex) ? numericTabIndex : value;
      return;
    }

    props[name] = value;
  });

  return props;
}

function areContextWrappersEquivalent(left?: ContextWrapper | null, right?: ContextWrapper | null) {
  if (!left || !right) {
    return false;
  }

  return String(left.tagName || '') === String(right.tagName || '')
    && JSON.stringify(left.attrs || {}) === JSON.stringify(right.attrs || {});
}

function stripContextWrapperPrefix(wrappers: ContextWrapper[] = [], activeContextWrappers: ContextWrapper[] = []) {
  if (!Array.isArray(wrappers) || !wrappers.length || !Array.isArray(activeContextWrappers) || !activeContextWrappers.length) {
    return Array.isArray(wrappers) ? wrappers : [];
  }

  const maxPrefixLength = Math.min(wrappers.length, activeContextWrappers.length);
  let matchedLength = 0;

  while (
    matchedLength < maxPrefixLength
    && areContextWrappersEquivalent(wrappers[matchedLength], activeContextWrappers[matchedLength])
  ) {
    matchedLength += 1;
  }

  return wrappers.slice(matchedLength);
}

function getSectionTag(section: SectionMeta) {
  switch (section.shellTag) {
    case 'header':
      return 'header';
    case 'footer':
      return 'footer';
    case 'aside':
      return 'aside';
    default:
      return 'section';
  }
}

export function ContextShell({
  wrappers,
  children
}: {
  wrappers: ContextWrapper[];
  children: React.ReactNode;
}) {
  if (!Array.isArray(wrappers) || !wrappers.length) {
    return <>{children}</>;
  }

  const layoutContext = React.useContext(PreviewLayoutContext);
  const { isSubview, activeContextWrappers } = layoutContext;
  const effectiveWrappers = stripContextWrapperPrefix(wrappers, activeContextWrappers);
  if (!effectiveWrappers.length) {
    return <>{children}</>;
  }

  const renderedChildren = effectiveWrappers.reduceRight<React.ReactNode>((inner, wrapper, index) => {
    const Tag = (wrapper.tagName || 'div') as keyof React.JSX.IntrinsicElements;
    return React.createElement(
      Tag,
      {
        key: \`\${wrapper.tagName || 'div'}-\${index}\`,
        ...buildContextProps(wrapper.attrs || {}, {
          reason: wrapper.reason,
          isSubview
        })
      },
      inner
    );
  }, children);

  return (
    <PreviewLayoutContext.Provider
      value={{
        ...layoutContext,
        activeContextWrappers: activeContextWrappers.concat(effectiveWrappers)
      }}
    >
      {renderedChildren}
    </PreviewLayoutContext.Provider>
  );
}

export function SectionFrame({
  section,
  html,
  children
}: {
  section: SectionMeta;
  html?: string | null;
  children?: React.ReactNode;
}) {
  const Tag = getSectionTag(section);
  const { activeContextWrappers } = React.useContext(PreviewLayoutContext);
  const frameProps = {
    className: \`\${section.pageClassName}__section \${section.pageClassName}__section--\${section.id}\`,
    'data-section-id': section.id,
    'data-section-kind': section.kind,
    'data-section-confidence': section.confidence,
    style: activeContextWrappers.length ? ({ display: 'contents' } as const) : undefined
  } as const;

  if (typeof html === 'string') {
    return (
      <Tag
        {...frameProps}
        dangerouslySetInnerHTML={{ __html: html }}
      />
    );
  }

  return (
    <Tag {...frameProps}>{children}</Tag>
  );
}

export function ContextShellHtml({
  wrappers,
  html,
  pageClassName
}: {
  wrappers: ContextWrapper[];
  html: string;
  pageClassName: string;
}) {
  if (!String(html || '').trim()) {
    return null;
  }

  const layoutContext = React.useContext(PreviewLayoutContext);
  const { isSubview, activeContextWrappers } = layoutContext;
  const effectiveWrappers = stripContextWrapperPrefix(wrappers, activeContextWrappers);

  if (!Array.isArray(effectiveWrappers) || !effectiveWrappers.length) {
    return (
      <div
        className={\`\${pageClassName}__section-shell\`}
        style={{ display: 'contents' }}
        dangerouslySetInnerHTML={{ __html: html }}
      />
    );
  }

  const lastWrapperIndex = effectiveWrappers.length - 1;

  const renderedChildren = effectiveWrappers.reduceRight<React.ReactNode>((inner, wrapper, index) => {
    const Tag = (wrapper.tagName || 'div') as keyof React.JSX.IntrinsicElements;
    const props = {
      key: \`\${wrapper.tagName || 'div'}-\${index}\`,
      ...buildContextProps(wrapper.attrs || {}, {
        reason: wrapper.reason,
        isSubview
      })
    };

    if (index === lastWrapperIndex) {
      return React.createElement(Tag, {
        ...props,
        dangerouslySetInnerHTML: { __html: html }
      });
    }

    return React.createElement(Tag, props, inner);
  }, null);

  return (
    <PreviewLayoutContext.Provider
      value={{
        ...layoutContext,
        activeContextWrappers: activeContextWrappers.concat(effectiveWrappers)
      }}
    >
      {renderedChildren}
    </PreviewLayoutContext.Provider>
  );
}

export function RawHtmlBlock({
  html,
  pageClassName
}: {
  html: string;
  pageClassName: string;
}) {
  return (
    <div
      className={\`\${pageClassName}__block-content\`}
      style={{ display: 'contents' }}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}

export function SectionBlockFrame({
  block,
  pageClassName,
  children
}: {
  block: SectionBlockMeta;
  pageClassName: string;
  children: React.ReactNode;
}) {
  return (
    <div
      className={\`\${pageClassName}__block \${pageClassName}__block--\${block.id}\`}
      data-block-id={block.id}
      data-block-kind={block.kind}
      data-block-confidence={block.confidence}
      style={{ display: 'contents' }}
    >
      {children}
    </div>
  );
}
`;
}

const RENDERED_HTML_SEGMENT_THRESHOLD = 16384;
const RENDERED_HTML_SEGMENT_SIZE = 8192;
const RENDERED_HTML_TARGET_KINDS = new Set(['section', 'block']);
const RENDERED_HTML_PATH_KINDS = new Set(['standard', 'custom']);

function splitRenderedHtmlSegments(html = '') {
  const normalizedHtml = String(html || '');
  const segments = [];

  for (let index = 0; index < normalizedHtml.length; index += RENDERED_HTML_SEGMENT_SIZE) {
    segments.push(normalizedHtml.slice(index, index + RENDERED_HTML_SEGMENT_SIZE));
  }

  return segments;
}

function validateRenderedHtmlContext(context = {}) {
  if (!context || typeof context !== 'object' || Array.isArray(context)) {
    throw new Error('renderedHtml emission context must be a plain object');
  }

  const keys = Object.keys(context).sort();
  const expectedKeys = ['pathKind', 'targetKind'];
  if (keys.length !== expectedKeys.length || keys.some((key, index) => key !== expectedKeys[index])) {
    throw new Error(`renderedHtml emission context must only contain ${expectedKeys.join(', ')}`);
  }

  const targetKind = String(context.targetKind || '').trim();
  const pathKind = String(context.pathKind || '').trim();

  if (!RENDERED_HTML_TARGET_KINDS.has(targetKind)) {
    throw new Error(`Unsupported renderedHtml targetKind: ${targetKind}`);
  }

  if (!RENDERED_HTML_PATH_KINDS.has(pathKind)) {
    throw new Error(`Unsupported renderedHtml pathKind: ${pathKind}`);
  }

  return {
    targetKind,
    pathKind
  };
}

function emitRenderedHtmlDeclaration(html, context = {}) {
  const { targetKind } = validateRenderedHtmlContext(context);
  const declarationPrefix = targetKind === 'block' ? 'export const' : 'const';
  const renderedHtml = String(html || '');

  if (renderedHtml.length <= RENDERED_HTML_SEGMENT_THRESHOLD) {
    return `${declarationPrefix} renderedHtml = ${JSON.stringify(renderedHtml)};`;
  }

  const renderedHtmlSegments = splitRenderedHtmlSegments(renderedHtml);
  return `const renderedHtmlSegments = ${JSON.stringify(renderedHtmlSegments, null, 2)};
${declarationPrefix} renderedHtml = renderedHtmlSegments.join('');`;
}

function emitBlockComponent(pageIR, section, block) {
  const pageClassName = `page-${pageIR.pageSlug}`;
  const blockMeta = {
    id: block.id,
    sectionId: block.sectionId || section.id,
    title: block.title,
    kind: block.kind,
    confidence: block.confidence,
    summary: block.summary,
    renderMode: block.renderMode,
    componentName: block.componentName,
    fileName: block.fileName,
    parentComponentName: section.componentName,
    pageClassName,
    interactionIds: block.interactionIds,
    contextWrappers: Array.isArray(block.contextWrappers) ? block.contextWrappers : [],
    diagnostics: block.diagnostics || null
  };

  return `import React from 'react';
import { RawHtmlBlock, SectionBlockFrame, type SectionBlockMeta } from '../_shared';

${emitRenderedHtmlDeclaration(String(block.markup || ''), {
    targetKind: 'block',
    pathKind: 'standard'
  })}

export const blockMeta: SectionBlockMeta = ${JSON.stringify(blockMeta, null, 2)};

const ${block.componentName}: React.FC = () => {
  return (
    <SectionBlockFrame
      block={blockMeta}
      pageClassName={blockMeta.pageClassName}
    >
      <RawHtmlBlock
        html={renderedHtml}
        pageClassName={blockMeta.pageClassName}
      />
    </SectionBlockFrame>
  );
};

${block.componentName}.displayName = ${JSON.stringify(block.componentName)};

export default ${block.componentName};
`;
}

function emitSectionComponent(pageIR, section) {
  const pageClassName = `page-${pageIR.pageSlug}`;
  const sectionMeta = {
    id: section.id,
    title: section.title,
    kind: section.kind,
    confidence: section.confidence,
    summary: section.summary,
    renderMode: section.renderMode,
    shellTag: section.shellTag,
    componentName: section.componentName,
    interactionIds: section.interactionIds,
    pageClassName,
    blockCount: Array.isArray(section.blocks) ? section.blocks.length : 0,
    contextWrappers: Array.isArray(section.contextWrappers) ? section.contextWrappers : [],
    diagnostics: section.diagnostics || null
  };
  const blockPayload = Array.isArray(section.blocks)
    ? section.blocks.map((block) => ({
      id: block.id,
      componentName: block.componentName
    }))
    : [];
  const renderedHtml = String(section.markup || '');
  const contextWrappers = Array.isArray(section.contextWrappers) ? section.contextWrappers : [];
  const hasBlocks = blockPayload.length > 0;
  const extractionHtmlCoverage = Number(section?.diagnostics?.extraction?.htmlCoverage);
  const shouldPreferRawHtml = hasBlocks
    && renderedHtml.trim()
    && Number.isFinite(extractionHtmlCoverage)
    && extractionHtmlCoverage > 0
    && extractionHtmlCoverage < 0.95;
  const shouldRenderBlocks = hasBlocks && !shouldPreferRawHtml;
  const blockImports = hasBlocks
    && shouldRenderBlocks
    ? blockPayload.map((block) => `import ${block.componentName} from './blocks/${block.componentName}';`).join('\n')
    : '';
  const renderedBlocks = hasBlocks
    && shouldRenderBlocks
    ? blockPayload.map((block) => `        <${block.componentName} key=${JSON.stringify(block.id)} />`).join('\n')
    : '';

  return `import React from 'react';
import { ContextShell, ContextShellHtml, SectionFrame, type SectionMeta } from './_shared';
${blockImports}

${emitRenderedHtmlDeclaration(renderedHtml, {
    targetKind: 'section',
    pathKind: 'standard'
  })}
const contextWrappers = ${JSON.stringify(contextWrappers, null, 2)};

export const sectionMeta: SectionMeta = ${JSON.stringify(sectionMeta, null, 2)};

const ${section.componentName}: React.FC = () => {
  return (
    <SectionFrame
      section={sectionMeta}
      html={!${shouldRenderBlocks} && !contextWrappers.length ? renderedHtml : null}
    >
      ${shouldRenderBlocks ? `{contextWrappers.length ? (
        <ContextShell wrappers={contextWrappers}>
${renderedBlocks}
        </ContextShell>
      ) : (
        <>
${renderedBlocks}
        </>
      )}` : `{contextWrappers.length ? (
        <ContextShellHtml
          wrappers={contextWrappers}
          html={renderedHtml}
          pageClassName={sectionMeta.pageClassName}
        />
      ) : null}`}
    </SectionFrame>
  );
};

${section.componentName}.displayName = ${JSON.stringify(section.componentName)};

export default ${section.componentName};
`;
}

function emitSectionsIndex(pageIR) {
  const imports = pageIR.sections.map((section) => {
    return `import ${section.componentName}, { sectionMeta as ${section.id.replace(/[^a-zA-Z0-9]/g, '')}Meta } from './${section.componentName}';`;
  }).join('\n');

  const sectionEntries = pageIR.sections.map((section) => {
    return `  { meta: ${section.id.replace(/[^a-zA-Z0-9]/g, '')}Meta, Component: ${section.componentName} }`;
  }).join(',\n');

  return `import React from 'react';
import { type SectionMeta } from './_shared';
${imports}

export type GeneratedSectionModule = {
  meta: SectionMeta;
  Component: React.FC;
};

export const pageSections: GeneratedSectionModule[] = [
${sectionEntries}
];
`;
}

function emitPageSections(pageIR) {
  const files = [
    ['sections/_shared.tsx', emitSharedSectionRuntime()],
    ['sections/index.ts', emitSectionsIndex(pageIR)]
  ];

  pageIR.sections.forEach((section) => {
    files.push([`sections/${section.componentName}.tsx`, emitSectionComponent(pageIR, section)]);
    (section.blocks || []).forEach((block) => {
      files.push([`sections/blocks/${block.componentName}.tsx`, emitBlockComponent(pageIR, section, block)]);
    });
  });

  return files;
}

module.exports = {
  emitPageSections
};
