const ROOT_SELECTORS = new Set(['html', 'body', ':root', ':host']);
const NESTED_RULE_AT_RULES = new Set([
  '@container',
  '@document',
  '@layer',
  '@media',
  '@scope',
  '@supports'
]);

function normalizeCssValue(value) {
  return String(value || '')
    .replace(/!important/gi, '')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

function splitTopLevel(input, separator) {
  const source = String(input || '');
  const chunks = [];
  let chunk = '';
  let quote = '';
  let inComment = false;
  let parenDepth = 0;
  let bracketDepth = 0;

  for (let index = 0; index < source.length; index += 1) {
    const character = source[index];
    const nextCharacter = source[index + 1];

    if (inComment) {
      chunk += character;
      if (character === '*' && nextCharacter === '/') {
        chunk += nextCharacter;
        index += 1;
        inComment = false;
      }
      continue;
    }

    if (quote) {
      chunk += character;
      if (character === '\\' && index + 1 < source.length) {
        chunk += source[index + 1];
        index += 1;
        continue;
      }
      if (character === quote) {
        quote = '';
      }
      continue;
    }

    if (character === '/' && nextCharacter === '*') {
      chunk += character + nextCharacter;
      index += 1;
      inComment = true;
      continue;
    }

    if (character === '\'' || character === '"') {
      quote = character;
      chunk += character;
      continue;
    }

    if (character === '(') {
      parenDepth += 1;
    } else if (character === ')' && parenDepth > 0) {
      parenDepth -= 1;
    } else if (character === '[') {
      bracketDepth += 1;
    } else if (character === ']' && bracketDepth > 0) {
      bracketDepth -= 1;
    }

    if (character === separator && parenDepth === 0 && bracketDepth === 0) {
      chunks.push(chunk);
      chunk = '';
      continue;
    }

    chunk += character;
  }

  chunks.push(chunk);
  return chunks;
}

function findMatchingBrace(cssText, openIndex) {
  const source = String(cssText || '');
  let quote = '';
  let inComment = false;
  let depth = 0;

  for (let index = openIndex; index < source.length; index += 1) {
    const character = source[index];
    const nextCharacter = source[index + 1];

    if (inComment) {
      if (character === '*' && nextCharacter === '/') {
        index += 1;
        inComment = false;
      }
      continue;
    }

    if (quote) {
      if (character === '\\') {
        index += 1;
        continue;
      }
      if (character === quote) {
        quote = '';
      }
      continue;
    }

    if (character === '/' && nextCharacter === '*') {
      inComment = true;
      index += 1;
      continue;
    }

    if (character === '\'' || character === '"') {
      quote = character;
      continue;
    }

    if (character === '{') {
      depth += 1;
      continue;
    }

    if (character === '}') {
      depth -= 1;
      if (depth === 0) {
        return index;
      }
    }
  }

  return -1;
}

function parseDeclarations(declarationText) {
  return splitTopLevel(declarationText, ';')
    .map((entry) => entry.trim())
    .filter(Boolean)
    .map((entry) => {
      const separatorIndex = entry.indexOf(':');
      if (separatorIndex < 0) {
        return null;
      }

      const property = entry.slice(0, separatorIndex).trim().toLowerCase();
      const value = entry.slice(separatorIndex + 1).trim();
      if (!property || !value) {
        return null;
      }

      return [property, value];
    })
    .filter(Boolean);
}

function isBareElementSelector(selector) {
  const normalizedSelector = String(selector || '').trim();
  if (!normalizedSelector) {
    return false;
  }

  if (normalizedSelector === '*') {
    return true;
  }

  if (/[\s.#\[:>+~]/.test(normalizedSelector)) {
    return false;
  }

  return /^[a-z][a-z0-9-]*$/i.test(normalizedSelector);
}

function classifyDangerSignals(declarations) {
  const declarationMap = new Map(declarations);
  const signalMap = {
    hidesContent: false,
    zeroTypography: false,
    fillLayout: false
  };

  const visibilityValue = normalizeCssValue(declarationMap.get('visibility'));
  const displayValue = normalizeCssValue(declarationMap.get('display'));
  const opacityValue = normalizeCssValue(declarationMap.get('opacity'));
  const fontSizeValue = normalizeCssValue(declarationMap.get('font-size'));
  const lineHeightValue = normalizeCssValue(declarationMap.get('line-height'));
  const colorValue = normalizeCssValue(declarationMap.get('color'));
  const widthValue = normalizeCssValue(declarationMap.get('width'));
  const heightValue = normalizeCssValue(declarationMap.get('height'));
  const minWidthValue = normalizeCssValue(declarationMap.get('min-width'));
  const minHeightValue = normalizeCssValue(declarationMap.get('min-height'));
  const positionValue = normalizeCssValue(declarationMap.get('position'));
  const overflowValue = normalizeCssValue(declarationMap.get('overflow'));
  const overflowXValue = normalizeCssValue(declarationMap.get('overflow-x'));
  const overflowYValue = normalizeCssValue(declarationMap.get('overflow-y'));
  const leftValue = normalizeCssValue(declarationMap.get('left'));
  const rightValue = normalizeCssValue(declarationMap.get('right'));
  const topValue = normalizeCssValue(declarationMap.get('top'));
  const bottomValue = normalizeCssValue(declarationMap.get('bottom'));
  const insetValue = normalizeCssValue(declarationMap.get('inset'));

  signalMap.hidesContent = (
    visibilityValue === 'hidden'
    || displayValue === 'none'
    || opacityValue === '0'
    || colorValue === 'transparent'
  );
  signalMap.zeroTypography = fontSizeValue === '0' || lineHeightValue === '0';

  const fullWidth = /^(?:100(?:\.0+)?(?:%|vw|dvw|vh|dvh)|calc\(\s*100(?:%|vw|dvw|vh|dvh)[^)]*\))$/i.test(widthValue);
  const fullHeight = /^(?:100(?:\.0+)?(?:%|vw|dvw|vh|dvh)|calc\(\s*100(?:%|vw|dvw|vh|dvh)[^)]*\))$/i.test(heightValue);
  const fullMinWidth = /^(?:100(?:\.0+)?(?:%|vw|dvw|vh|dvh)|calc\(\s*100(?:%|vw|dvw|vh|dvh)[^)]*\))$/i.test(minWidthValue);
  const fullMinHeight = /^(?:100(?:\.0+)?(?:%|vw|dvw|vh|dvh)|calc\(\s*100(?:%|vw|dvw|vh|dvh)[^)]*\))$/i.test(minHeightValue);
  const hasFullSizing = (
    (fullWidth || fullMinWidth)
    && (fullHeight || fullMinHeight)
  );
  const hasLayoutForce = Boolean(
    displayValue
    || positionValue
    || overflowValue
    || overflowXValue
    || overflowYValue
  );
  signalMap.fillLayout = (
    (hasFullSizing && hasLayoutForce)
    || (leftValue.startsWith('-') || rightValue.startsWith('-') || topValue.startsWith('-') || bottomValue.startsWith('-') || insetValue.startsWith('-'))
  );

  return signalMap;
}

function shouldStripSelector(selector, dangerSignals) {
  const normalizedSelector = String(selector || '').trim();
  if (!isBareElementSelector(normalizedSelector)) {
    return false;
  }

  if (ROOT_SELECTORS.has(normalizedSelector.toLowerCase())) {
    return Boolean(dangerSignals.hidesContent || dangerSignals.zeroTypography);
  }

  return Boolean(dangerSignals.hidesContent || dangerSignals.zeroTypography || dangerSignals.fillLayout);
}

function sanitizeStyleRule(selectorText, declarationText) {
  const selectors = splitTopLevel(selectorText, ',')
    .map((entry) => entry.trim())
    .filter(Boolean);
  if (!selectors.length) {
    return '';
  }

  const declarations = parseDeclarations(declarationText);
  const dangerSignals = classifyDangerSignals(declarations);
  if (!dangerSignals.hidesContent && !dangerSignals.zeroTypography && !dangerSignals.fillLayout) {
    return `${selectors.join(', ')}{${declarationText}}`;
  }

  const keptSelectors = selectors.filter((selector) => !shouldStripSelector(selector, dangerSignals));
  if (!keptSelectors.length) {
    return '';
  }

  return `${keptSelectors.join(', ')}{${declarationText}}`;
}

const LAYOUT_SENSITIVE_PROPERTIES = new Set([
  'display',
  'position',
  'top',
  'right',
  'bottom',
  'left',
  'inset',
  'inset-block',
  'inset-inline',
  'width',
  'min-width',
  'max-width',
  'height',
  'min-height',
  'max-height',
  'margin',
  'margin-top',
  'margin-right',
  'margin-bottom',
  'margin-left',
  'flex',
  'flex-grow',
  'flex-shrink',
  'flex-basis',
  'flex-direction',
  'grid',
  'grid-template',
  'grid-template-columns',
  'grid-template-rows',
  'overflow',
  'overflow-x',
  'overflow-y',
  'transform'
]);

function hasLayoutSensitiveDeclarations(declarations) {
  return declarations.some(([property]) => LAYOUT_SENSITIVE_PROPERTIES.has(String(property || '').toLowerCase()));
}

function sanitizeStyleRuleWithSelectorMatchCount(selectorText, declarationText, selectorMatchCount) {
  const selectors = splitTopLevel(selectorText, ',')
    .map((entry) => entry.trim())
    .filter(Boolean);
  if (!selectors.length) {
    return '';
  }

  const declarations = parseDeclarations(declarationText);
  if (!hasLayoutSensitiveDeclarations(declarations) || typeof selectorMatchCount !== 'function') {
    return `${selectors.join(', ')}{${declarationText}}`;
  }

  const keptSelectors = selectors.filter((selector) => {
    try {
      const matchCount = selectorMatchCount(selector);
      if (!Number.isFinite(matchCount)) {
        return true;
      }
      return matchCount === 1;
    } catch (_error) {
      return true;
    }
  });

  if (!keptSelectors.length) {
    return '';
  }

  return `${keptSelectors.join(', ')}{${declarationText}}`;
}

function shouldRecurseAtRule(preludeText) {
  const matchedAtRule = String(preludeText || '').trim().match(/^@([a-z-]+)/i);
  if (!matchedAtRule) {
    return false;
  }

  return NESTED_RULE_AT_RULES.has(`@${matchedAtRule[1].toLowerCase()}`);
}

function sanitizeCssText(cssText) {
  const source = String(cssText || '');
  let output = '';
  let index = 0;

  while (index < source.length) {
    while (index < source.length && /\s/.test(source[index])) {
      index += 1;
    }

    if (index >= source.length) {
      break;
    }

    if (source[index] === '/' && source[index + 1] === '*') {
      const commentEnd = source.indexOf('*/', index + 2);
      if (commentEnd < 0) {
        break;
      }
      index = commentEnd + 2;
      continue;
    }

    let quote = '';
    let inComment = false;
    let parenDepth = 0;
    let bracketDepth = 0;
    let tokenEnd = index;
    let terminator = '';

    while (tokenEnd < source.length) {
      const character = source[tokenEnd];
      const nextCharacter = source[tokenEnd + 1];

      if (inComment) {
        if (character === '*' && nextCharacter === '/') {
          tokenEnd += 2;
          inComment = false;
          continue;
        }
        tokenEnd += 1;
        continue;
      }

      if (quote) {
        if (character === '\\') {
          tokenEnd += 2;
          continue;
        }
        if (character === quote) {
          quote = '';
        }
        tokenEnd += 1;
        continue;
      }

      if (character === '/' && nextCharacter === '*') {
        inComment = true;
        tokenEnd += 2;
        continue;
      }

      if (character === '\'' || character === '"') {
        quote = character;
        tokenEnd += 1;
        continue;
      }

      if (character === '(') {
        parenDepth += 1;
      } else if (character === ')' && parenDepth > 0) {
        parenDepth -= 1;
      } else if (character === '[') {
        bracketDepth += 1;
      } else if (character === ']' && bracketDepth > 0) {
        bracketDepth -= 1;
      }

      if (parenDepth === 0 && bracketDepth === 0 && (character === '{' || character === ';')) {
        terminator = character;
        break;
      }

      tokenEnd += 1;
    }

    const token = source.slice(index, tokenEnd).trim();
    if (!token) {
      index = tokenEnd + (terminator ? 1 : 0);
      continue;
    }

    if (terminator === ';') {
      output += `${token};`;
      index = tokenEnd + 1;
      continue;
    }

    if (terminator === '{') {
      const blockEnd = findMatchingBrace(source, tokenEnd);
      if (blockEnd < 0) {
        output += token;
        break;
      }

      const blockBody = source.slice(tokenEnd + 1, blockEnd);
      if (token.startsWith('@')) {
        const sanitizedBody = shouldRecurseAtRule(token) ? sanitizeCssText(blockBody) : blockBody;
        output += `${token}{${sanitizedBody}}`;
      } else {
        const sanitizedRule = sanitizeStyleRule(token, blockBody);
        if (sanitizedRule) {
          output += sanitizedRule;
        }
      }

      index = blockEnd + 1;
      continue;
    }

    output += token;
    break;
  }

  return output.trim();
}

function sanitizeCssTextWithSelectorMatchCount(cssText, selectorMatchCount) {
  const source = String(cssText || '');
  let output = '';
  let index = 0;

  while (index < source.length) {
    while (index < source.length && /\s/.test(source[index])) {
      index += 1;
    }

    if (index >= source.length) {
      break;
    }

    if (source[index] === '/' && source[index + 1] === '*') {
      const commentEnd = source.indexOf('*/', index + 2);
      if (commentEnd < 0) {
        break;
      }
      index = commentEnd + 2;
      continue;
    }

    let quote = '';
    let inComment = false;
    let parenDepth = 0;
    let bracketDepth = 0;
    let tokenEnd = index;
    let terminator = '';

    while (tokenEnd < source.length) {
      const character = source[tokenEnd];
      const nextCharacter = source[tokenEnd + 1];

      if (inComment) {
        if (character === '*' && nextCharacter === '/') {
          tokenEnd += 2;
          inComment = false;
          continue;
        }
        tokenEnd += 1;
        continue;
      }

      if (quote) {
        if (character === '\\') {
          tokenEnd += 2;
          continue;
        }
        if (character === quote) {
          quote = '';
        }
        tokenEnd += 1;
        continue;
      }

      if (character === '/' && nextCharacter === '*') {
        inComment = true;
        tokenEnd += 2;
        continue;
      }

      if (character === '\'' || character === '"') {
        quote = character;
        tokenEnd += 1;
        continue;
      }

      if (character === '(') {
        parenDepth += 1;
      } else if (character === ')' && parenDepth > 0) {
        parenDepth -= 1;
      } else if (character === '[') {
        bracketDepth += 1;
      } else if (character === ']' && bracketDepth > 0) {
        bracketDepth -= 1;
      }

      if (parenDepth === 0 && bracketDepth === 0 && (character === '{' || character === ';')) {
        terminator = character;
        break;
      }

      tokenEnd += 1;
    }

    const token = source.slice(index, tokenEnd).trim();
    if (!token) {
      index = tokenEnd + (terminator ? 1 : 0);
      continue;
    }

    if (terminator === ';') {
      output += `${token};`;
      index = tokenEnd + 1;
      continue;
    }

    if (terminator === '{') {
      const blockEnd = findMatchingBrace(source, tokenEnd);
      if (blockEnd < 0) {
        output += token;
        break;
      }

      const blockBody = source.slice(tokenEnd + 1, blockEnd);
      if (token.startsWith('@')) {
        const sanitizedBody = shouldRecurseAtRule(token)
          ? sanitizeCssTextWithSelectorMatchCount(blockBody, selectorMatchCount)
          : blockBody;
        output += `${token}{${sanitizedBody}}`;
      } else {
        const sanitizedRule = sanitizeStyleRuleWithSelectorMatchCount(token, blockBody, selectorMatchCount);
        if (sanitizedRule) {
          output += sanitizedRule;
        }
      }

      index = blockEnd + 1;
      continue;
    }

    output += token;
    break;
  }

  return output.trim();
}

function stripResidualDangerousBareRules(cssText) {
  const source = String(cssText || '');
  if (!source) {
    return source;
  }

  const residualPatterns = [
    /(^|[}\s])([a-z][a-z0-9-]*|\*)\s*\{(?=[^{}]*visibility\s*:\s*hidden)[^{}]*\}/gi,
    /(^|[}\s])([a-z][a-z0-9-]*|\*)\s*\{(?=[^{}]*display\s*:\s*none)[^{}]*\}/gi,
    /(^|[}\s])([a-z][a-z0-9-]*|\*)\s*\{(?=[^{}]*opacity\s*:\s*0(?:[;}]|\s))[^{}]*\}/gi,
    /(^|[}\s])([a-z][a-z0-9-]*|\*)\s*\{(?=[^{}]*font-size\s*:\s*0(?:[;}]|\s)|[^{}]*line-height\s*:\s*0(?:[;}]|\s))[^{}]*\}/gi,
    /(^|[}\s])([a-z][a-z0-9-]*|\*)\s*\{(?=[^{}]*width\s*:\s*100%)(?=[^{}]*height\s*:\s*100%)(?=[^{}]*position\s*:\s*(?:relative|absolute|fixed|sticky))(?=[^{}]*display\s*:\s*(?:block|flex|inline-block))[^{}]*\}/gi
  ];

  return residualPatterns.reduce((currentCss, pattern) => {
    return currentCss.replace(pattern, (match, prefix, selector) => {
      const normalizedSelector = String(selector || '').trim().toLowerCase();
      if (ROOT_SELECTORS.has(normalizedSelector) && !/visibility\s*:\s*hidden|display\s*:\s*none|opacity\s*:\s*0/i.test(match)) {
        return match;
      }

      return prefix || '';
    });
  }, source).trim();
}

function sanitizeExtractedSourceCss(cssText) {
  const normalizedCssText = String(cssText || '').trim();
  if (!normalizedCssText) {
    return '';
  }

  return stripResidualDangerousBareRules(sanitizeCssText(normalizedCssText));
}

function sanitizeRuntimeStyleTextWithSelectorMatchCount(cssText, selectorMatchCount) {
  const normalizedCssText = String(cssText || '').trim();
  if (!normalizedCssText) {
    return '';
  }

  return stripResidualDangerousBareRules(
    sanitizeCssTextWithSelectorMatchCount(normalizedCssText, selectorMatchCount)
  );
}

module.exports = {
  sanitizeExtractedSourceCss,
  sanitizeRuntimeStyleTextWithSelectorMatchCount
};
