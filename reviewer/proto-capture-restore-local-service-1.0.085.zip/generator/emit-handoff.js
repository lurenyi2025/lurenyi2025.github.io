const path = require('path');

function toPosixPath(filePath = '') {
  return String(filePath || '').split(path.sep).join('/');
}

function relativeFrom(rootDir, targetPath) {
  if (!rootDir || !targetPath) {
    return '';
  }

  return toPosixPath(path.relative(rootDir, targetPath));
}

function formatPathList(paths = []) {
  const uniquePaths = Array.from(new Set(
    paths.map((value) => String(value || '').trim()).filter(Boolean)
  ));

  if (!uniquePaths.length) {
    return ['- (none)'];
  }

  return uniquePaths.map((value) => `- \`${value}\``);
}

function emitHandoff(pageIR, { outputPaths = {} } = {}) {
  const pageDir = outputPaths.pageDir || '';
  const metaDir = outputPaths.metaDir || '';
  const specPath = relativeFrom(pageDir, outputPaths.specFilePath || path.join(pageDir, 'spec.md')) || 'spec.md';
  const entryPath = relativeFrom(pageDir, outputPaths.entryFilePath || path.join(pageDir, 'index.tsx')) || 'index.tsx';
  const stylePath = relativeFrom(pageDir, path.join(pageDir, 'style.css')) || 'style.css';
  const evidenceDir = relativeFrom(pageDir, metaDir) || '.protorec/pages';
  const qa = pageIR.qa || {};
  const editability = pageIR.editability || {};
  const viewLabel = String(pageIR?.view?.viewLabel || pageIR.pageTitle || '').trim();
  const currentView = `${pageIR.view.viewId} (${viewLabel})`;

  return `---
pageSlug: ${pageIR.pageSlug}
pageTitle: ${pageIR.pageTitle}
viewId: ${pageIR.view.viewId}
viewLabel: ${pageIR.view.viewLabel}
specPath: ${specPath}
readyState: ${pageIR.readyState || 'unknown'}
qaStatus: ${qa.status || 'unknown'}
releaseDecision: ${qa.releaseDecision || 'unknown'}
---

# 只读摘要

> 这是当前页面包的只读摘要。真正的编辑入口是 \`${specPath}\`。

## Package
- currentView: \`${currentView}\`
- previewEntry: \`${entryPath}\`
- styleEntry: \`${stylePath}\`
- readOnlySpec: \`${specPath}\`

## Delivery State
- readyState: \`${pageIR.readyState || 'unknown'}\`
- qaStatus: \`${qa.status || 'unknown'}\`
- releaseDecision: \`${qa.releaseDecision || 'unknown'}\`
- summary: ${qa.summary?.label || 'unknown'}
- primaryReason: ${qa.primaryReason || 'unknown'}

## Editing Notes
- 当前页面的推荐编辑入口请以 \`spec.md\` 为准。
- 当前 Level 1 / Level 1.5 包是恢复产物与基线预览，\`index.tsx\` 和 \`style.css\` 是旧预览所需的核心文件。
- 新 capture-pack 路线的最终可编辑 prototype 应创建在 \`src/prototypes/${pageIR.routeId}/\`，不要把 \`${evidenceDir}\` 下的过程资产复制进去。
- 如果目标命中了交互协议，先在 \`spec.md\` 中确认交互意图，再对 \`index.tsx\` 中对应标记做小步修改。

## Recommended Entry Points
${formatPathList((editability.recommendedFirstEdits || []).map((target) => {
  const targetId = String(target?.targetId || target?.sectionId || '').trim();
  return targetId ? `index.tsx#${targetId}` : '';
})).join('\n')}

## Evidence
- \`${evidenceDir}/manifest.json\`
- \`${evidenceDir}/qa-report.json\`
- \`${evidenceDir}/editability-report.json\`
- \`${evidenceDir}/section-map.json\`
- \`${evidenceDir}/generation-debug.json\`
- \`${evidenceDir}/capture.meta.json\`
- \`${evidenceDir}/source.original.html\`
- \`${evidenceDir}/reference_full.png\`
`;
}

module.exports = {
  emitHandoff
};
