const { toPascalCase } = require('./naming');
const { hasSemanticSurface } = require('./emit-semantic-surface');

function escapeJsonForSource(value) {
  return JSON.stringify(value)
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e')
    .replace(/\u2028/g, '\\u2028')
    .replace(/\u2029/g, '\\u2029');
}

function buildPreviewBodyMarkup(pageIR) {
  if (pageIR?.structuralDecomposition?.previewBodyMarkup) {
    return String(pageIR.structuralDecomposition.previewBodyMarkup || '');
  }

  return (Array.isArray(pageIR.sections) ? pageIR.sections : [])
    .map((section) => String(section?.previewMarkup || section?.markup || '').trim())
    .filter(Boolean)
    .join('\n');
}

function buildNamedFallbackFragmentSource(pageIR) {
  const decomposition = pageIR?.structuralDecomposition || null;
  const fragments = Array.isArray(decomposition?.fragments) ? decomposition.fragments : [];
  const rootFragmentName = String(decomposition?.rootFragmentName || '').trim();
  if (!fragments.length || !rootFragmentName) {
    return 'const previewBodyMarkupBase = previewBodyMarkupRaw;';
  }

  const fragmentDeclarations = fragments.map((fragment) => (
    `const ${fragment.name} = ${escapeJsonForSource(fragment.html || '')};`
  ));
  const fragmentMapEntries = fragments.map((fragment) => (
    `  ${escapeJsonForSource(fragment.name)}: ${fragment.name}`
  ));

  return `${fragmentDeclarations.join('\n')}

const namedFallbackFragments: Record<string, string> = {
${fragmentMapEntries.join(',\n')}
};

function renderNamedFallbackFragment(markup: string, depth = 0): string {
  if (depth > 20) return String(markup || '');
  return String(markup || '').replace(/<!--__PROTOREC_FRAGMENT:([A-Za-z0-9_]+)__-->/g, (_match, name) => {
    return renderNamedFallbackFragment(namedFallbackFragments[name] || '', depth + 1);
  });
}

const previewBodyMarkupBase = renderNamedFallbackFragment(${rootFragmentName});`;
}

function buildSemanticRuntimeSource() {
  return `
function hasSemanticEdits(editConfig: Record<string, any>) {
  return Boolean(
    editConfig?.table
    || editConfig?.filter
    || editConfig?.menu
  );
}

function escapeSemanticHtml(value: any) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function resolveEditedTableColumns(schema: any, tableEdits: any) {
  const originalColumns = Array.isArray(schema?.columns) ? schema.columns.slice() : [];
  const removed = new Set(Array.isArray(tableEdits?.removeColumnIds) ? tableEdits.removeColumnIds : []);
  let columns = originalColumns.filter((column: any) => !removed.has(column.id));
  if (Array.isArray(tableEdits?.addColumns)) {
    tableEdits.addColumns.forEach((column: any, index: number) => {
      const nextColumn = {
        id: String(column.id || 'new-column-' + (index + 1)),
        label: String(column.label || column.id || '新增字段'),
        sourceIndex: columns.length,
        kind: String(column.kind || 'text'),
        defaultValue: String(column.defaultValue ?? '')
      };
      const afterIndex = column.afterId ? columns.findIndex((item: any) => item.id === column.afterId) : -1;
      if (afterIndex >= 0) columns.splice(afterIndex + 1, 0, nextColumn);
      else columns.push(nextColumn);
    });
  }
  if (Array.isArray(tableEdits?.addActions) && tableEdits.addActions.length) {
    columns = columns.filter((column: any) => column.kind !== 'action');
    columns.push({
      id: 'actions',
      label: String(tableEdits.actionColumnLabel || '操作'),
      sourceIndex: columns.length,
      kind: 'action'
    });
  }
  if (Array.isArray(tableEdits?.columnOrder) && tableEdits.columnOrder.length) {
    const byId = new Map(columns.map((column: any) => [column.id, column]));
    const ordered = tableEdits.columnOrder.map((id: string) => byId.get(id)).filter(Boolean);
    columns.forEach((column: any) => {
      if (!ordered.includes(column)) ordered.push(column);
    });
    columns = ordered;
  }
  return columns;
}

function stableSemanticJson(value: any) {
  return JSON.stringify(value ?? null);
}

function semanticItemsById(items: any[]) {
  return new Map((Array.isArray(items) ? items : [])
    .filter((item: any) => String(item?.id || '').trim())
    .map((item: any) => [String(item.id), item]));
}

function buildSemanticSurfaceEditConfig(currentSchemas: any, baselineSchemas: any) {
  const editConfig: Record<string, any> = {};
  const currentTable = currentSchemas?.tableSchema;
  const baselineTable = baselineSchemas?.tableSchema;
  if (currentTable && baselineTable) {
    const tableChanged = stableSemanticJson({
      columns: currentTable.columns || [],
      rows: currentTable.rows || [],
      actions: currentTable.actions || []
    }) !== stableSemanticJson({
      columns: baselineTable.columns || [],
      rows: baselineTable.rows || [],
      actions: baselineTable.actions || []
    });
    if (tableChanged) {
      editConfig.table = {
        columnOrder: (Array.isArray(currentTable.columns) ? currentTable.columns : [])
          .map((column: any) => String(column?.id || '').trim())
          .filter(Boolean)
      };
    }
  }

  const currentFilter = currentSchemas?.filterSchema;
  const baselineFilter = baselineSchemas?.filterSchema;
  if (currentFilter && baselineFilter) {
    const currentFields = Array.isArray(currentFilter.fields) ? currentFilter.fields : [];
    const baselineFields = Array.isArray(baselineFilter.fields) ? baselineFilter.fields : [];
    const currentById = semanticItemsById(currentFields);
    const baselineById = semanticItemsById(baselineFields);
    const addFields = currentFields.filter((field: any) => {
      const baselineField = baselineById.get(String(field?.id || ''));
      return !baselineField || stableSemanticJson(field) !== stableSemanticJson(baselineField);
    });
    const removeFields = baselineFields.filter((field: any) => {
      const currentField = currentById.get(String(field?.id || ''));
      return !currentField || stableSemanticJson(field) !== stableSemanticJson(currentField);
    });
    if (
      addFields.length
      || removeFields.length
      || Boolean(currentFilter.collapsible) !== Boolean(baselineFilter.collapsible)
      || Boolean(currentFilter.defaultCollapsed) !== Boolean(baselineFilter.defaultCollapsed)
    ) {
      editConfig.filter = {
        addFields,
        removeFieldIds: removeFields.map((field: any) => field.id).filter(Boolean),
        removeFields,
        collapsible: Boolean(currentFilter.collapsible),
        defaultCollapsed: Boolean(currentFilter.defaultCollapsed)
      };
    }
  }

  const currentMenu = currentSchemas?.menuSchema;
  const baselineMenu = baselineSchemas?.menuSchema;
  if (currentMenu && baselineMenu) {
    const baselineById = semanticItemsById(baselineMenu.items || []);
    const addItems = (Array.isArray(currentMenu.items) ? currentMenu.items : [])
      .filter((item: any) => !baselineById.has(String(item?.id || '')));
    if (addItems.length) {
      editConfig.menu = { addItems };
    }
  }

  return editConfig;
}

function mergeSemanticEditConfigs(surfaceEditConfig: Record<string, any>, explicitEditConfig: Record<string, any>) {
  return {
    ...(surfaceEditConfig || {}),
    ...(explicitEditConfig || {}),
    table: surfaceEditConfig?.table || explicitEditConfig?.table
      ? { ...(surfaceEditConfig?.table || {}), ...(explicitEditConfig?.table || {}) }
      : undefined,
    filter: surfaceEditConfig?.filter || explicitEditConfig?.filter
      ? { ...(surfaceEditConfig?.filter || {}), ...(explicitEditConfig?.filter || {}) }
      : undefined,
    menu: surfaceEditConfig?.menu || explicitEditConfig?.menu
      ? { ...(surfaceEditConfig?.menu || {}), ...(explicitEditConfig?.menu || {}) }
      : undefined
  };
}

function renderSemanticTableCells(sourceRow: any, columns: any[], tableEdits: any, cellTag: 'td' | 'th') {
  const cellUpdates = new Map(
    (Array.isArray(tableEdits?.cellUpdates) ? tableEdits.cellUpdates : [])
      .map((update: any) => [String(update.rowId || '') + '::' + String(update.columnId || ''), String(update.value ?? '')])
  );
  return columns.map((column: any) => {
    let content = '';
    if (cellTag === 'th') {
      content = escapeSemanticHtml(column.label || column.id || '');
    } else if (column.kind === 'action' && Array.isArray(tableEdits?.addActions)) {
      content = tableEdits.addActions.map((action: any) => {
        const label = escapeSemanticHtml(action.label || action.id || '操作');
        const id = escapeSemanticHtml(action.id || action.label || 'action');
        return '<a href="#" data-protorec-row-action="' + id + '">' + label + '</a>';
      }).join(' ');
    } else {
      const updateKey = String(sourceRow?.id || '') + '::' + String(column.id || '');
      const value = cellUpdates.has(updateKey)
        ? cellUpdates.get(updateKey)
        : (sourceRow?.cells?.[column.id] ?? column.defaultValue ?? '');
      content = escapeSemanticHtml(value);
    }
    return '<' + cellTag + '>' + content + '</' + cellTag + '>';
  }).join('');
}

function applySemanticListEditsByString(markup: string, schemas: any, editConfig: Record<string, any>, semanticState: Record<string, any> = {}) {
  let nextMarkup = String(markup || '');
  if (editConfig?.table && schemas?.tableSchema) {
    const columns = resolveEditedTableColumns(schemas.tableSchema, editConfig.table);
    const rows = Array.isArray(schemas.tableSchema.rows) ? schemas.tableSchema.rows : [];
    const headerHtml = renderSemanticTableCells(null, columns, editConfig.table, 'th');
    let rowIndex = 0;
    nextMarkup = nextMarkup.replace(/<thead\\b([^>]*)>[\\s\\S]*?<\\/thead>/gi, (_match, attrs) => (
      '<thead' + attrs + '><tr>' + headerHtml + '</tr></thead>'
    ));
    nextMarkup = nextMarkup.replace(/<tbody\\b([^>]*)>([\\s\\S]*?)<\\/tbody>/gi, (_match, attrs, body) => {
      const replacedBody = String(body || '').replace(/<tr\\b([^>]*)>[\\s\\S]*?<\\/tr>/gi, (_rowMatch, rowAttrs) => {
        const sourceRow = rows[rowIndex] || { id: 'row-' + (rowIndex + 1), cells: {} };
        rowIndex += 1;
        return '<tr' + rowAttrs + '>' + renderSemanticTableCells(sourceRow, columns, editConfig.table, 'td') + '</tr>';
      });
      return '<tbody' + attrs + '>' + replacedBody + '</tbody>';
    });
  }
  if (editConfig?.filter) {
    if (editConfig.filter.collapsible && !/data-protorec-filter-toggle/.test(nextMarkup)) {
      nextMarkup = nextMarkup.replace(/<form\\b([^>]*)>/i, '<form$1><button type="button" data-protorec-filter-toggle="true">' + (semanticState?.filterCollapsed ? '展开' : '收起') + '</button><div data-protorec-filter-collapsed="true"' + (semanticState?.filterCollapsed ? ' hidden' : '') + '>');
      nextMarkup = nextMarkup.replace(/<\\/form>/i, '</div></form>');
    }
    (Array.isArray(editConfig.filter.addFields) ? editConfig.filter.addFields : []).forEach((field: any, index: number) => {
      const id = escapeSemanticHtml(field.id || 'new-filter-' + (index + 1));
      const label = escapeSemanticHtml(field.label || id);
      const placeholder = escapeSemanticHtml(field.placeholder || '');
      const fieldMarkup = '<div class="ant-form-item protorec-semantic-filter-field" data-protorec-filter-field="' + id + '"><label>' + label + '</label><input placeholder="' + placeholder + '" /></div>';
      nextMarkup = nextMarkup.replace(/<\\/form>/i, fieldMarkup + '</form>');
    });
  }
  if (editConfig?.menu) {
    (Array.isArray(editConfig.menu.addItems) ? editConfig.menu.addItems : []).forEach((item: any, index: number) => {
      const id = escapeSemanticHtml(item.id || 'new-menu-' + (index + 1));
      const label = escapeSemanticHtml(item.label || id);
      const href = escapeSemanticHtml(item.href || '#');
      const itemMarkup = '<a class="nav-link protorec-semantic-menu-item" data-protorec-menu-item="' + id + '" href="' + href + '">' + label + '</a>';
      if (/<\\/aside>/i.test(nextMarkup)) nextMarkup = nextMarkup.replace(/<\\/aside>/i, itemMarkup + '</aside>');
      else if (/<\\/nav>/i.test(nextMarkup)) nextMarkup = nextMarkup.replace(/<\\/nav>/i, itemMarkup + '</nav>');
      else nextMarkup += itemMarkup;
    });
  }
  return nextMarkup;
}

function findSemanticTarget(root: ParentNode, selector: string, fallbackSelector: string) {
  const normalizedSelector = String(selector || '').trim();
  if (normalizedSelector) {
    try {
      const target = root.querySelector(normalizedSelector);
      if (target) return target;
    } catch (_error) {
      // Fall back to semantic selectors below.
    }
  }
  return root.querySelector(fallbackSelector);
}

function updateTableFromSchema(root: ParentNode, schema: any, tableEdits: any) {
  if (!schema || !tableEdits) return;
  const table = findSemanticTarget(root, schema.selector, 'table, [role="table"], .ant-table, .el-table, .datatable-table') as HTMLElement | null;
  const tableEditRoot = table?.matches('table') && !table.querySelector('tbody tr')
    ? (table.closest('.ant-table, .ant-table-container, .ant-table-wrapper, .el-table, .datatable-wrapper') as HTMLElement | null) || table
    : table;
  const nativeTables = tableEditRoot
    ? (tableEditRoot.matches('table') ? [tableEditRoot] : Array.from(tableEditRoot.querySelectorAll('table')))
    : [];
  if (!nativeTables.length) return;

  const columns = resolveEditedTableColumns(schema, tableEdits);

  nativeTables.forEach((nativeTable) => {
    const headerRow = nativeTable.querySelector('thead tr');
    if (!headerRow) return;
    headerRow.innerHTML = '';
    columns.forEach((column: any) => {
      const th = document.createElement('th');
      th.textContent = String(column.label || column.id || '');
      headerRow.appendChild(th);
    });
  });

  const bodyRows = nativeTables.flatMap((nativeTable) => Array.from(nativeTable.querySelectorAll('tbody tr')));
  const schemaRows = Array.isArray(schema.rows) ? schema.rows : [];
  const cellUpdates = new Map(
    (Array.isArray(tableEdits.cellUpdates) ? tableEdits.cellUpdates : [])
      .map((update: any) => [String(update.rowId || '') + '::' + String(update.columnId || ''), String(update.value ?? '')])
  );
  bodyRows.forEach((row, rowIndex) => {
    const sourceRow = schemaRows[rowIndex] || { id: 'row-' + (rowIndex + 1), cells: {} };
    row.innerHTML = '';
    columns.forEach((column: any) => {
      const td = document.createElement('td');
      if (column.kind === 'action' && Array.isArray(tableEdits.addActions)) {
        tableEdits.addActions.forEach((action: any, actionIndex: number) => {
          if (actionIndex > 0) td.appendChild(document.createTextNode(' '));
          const actionElement = document.createElement(String(action.kind || 'link') === 'button' ? 'button' : 'a');
          actionElement.textContent = String(action.label || action.id || '操作');
          if (actionElement.tagName.toLowerCase() === 'a') actionElement.setAttribute('href', String(action.href || '#'));
          actionElement.setAttribute('data-protorec-row-action', String(action.id || action.label || 'action'));
          td.appendChild(actionElement);
        });
      } else {
        const updateKey = String(sourceRow.id || '') + '::' + String(column.id || '');
        const value = cellUpdates.has(updateKey)
          ? cellUpdates.get(updateKey)
          : (sourceRow.cells?.[column.id] ?? column.defaultValue ?? '');
        td.textContent = String(value ?? '');
      }
      row.appendChild(td);
    });
  });
}

function removeFilterField(root: ParentNode, field: any) {
  const label = String(field?.label || '').trim();
  if (!label) return;
  Array.from(root.querySelectorAll('label, .ant-form-item, .form-group, .mb-3, .row, .col')).some((element) => {
    if (!String(element.textContent || '').replace(/\\s+/g, ' ').includes(label)) return false;
    const removable = element.closest('.ant-form-item, .form-group, .mb-3, .row, .col') || element;
    removable.parentElement?.removeChild(removable);
    return true;
  });
}

function updateFilterFromSchema(root: ParentNode, schema: any, filterEdits: any, semanticState: any) {
  if (!schema || !filterEdits) return;
  const form = findSemanticTarget(root, schema.selector, 'form, .ant-pro-query-filter, .ant-form, .filter, .search') as HTMLElement | null;
  if (!form) return;

  const fields = Array.isArray(schema.fields) ? schema.fields : [];
  const removeIds = new Set(Array.isArray(filterEdits.removeFieldIds) ? filterEdits.removeFieldIds : []);
  const removeFields = Array.isArray(filterEdits.removeFields)
    ? filterEdits.removeFields
    : fields.filter((field: any) => removeIds.has(field.id));
  removeFields.forEach((field: any) => removeFilterField(form, field));

  if (filterEdits.collapsible && !form.querySelector('[data-protorec-filter-toggle]')) {
    const toggle = document.createElement('button');
    toggle.type = 'button';
    toggle.setAttribute('data-protorec-filter-toggle', 'true');
    toggle.textContent = semanticState?.filterCollapsed ? '展开' : '收起';
    form.insertBefore(toggle, form.firstChild);
  }
  const collapsed = Boolean(filterEdits.collapsible && semanticState?.filterCollapsed);
  Array.from(form.children).forEach((child) => {
    if ((child as HTMLElement).matches('[data-protorec-filter-toggle]')) return;
    if (collapsed) (child as HTMLElement).setAttribute('hidden', '');
    else (child as HTMLElement).removeAttribute('hidden');
  });

  (Array.isArray(filterEdits.addFields) ? filterEdits.addFields : []).forEach((field: any, index: number) => {
    const id = String(field.id || 'new-filter-' + (index + 1));
    if (form.querySelector('[data-protorec-filter-field="' + CSS.escape(id) + '"]')) return;
    const wrapper = document.createElement('div');
    wrapper.className = 'ant-form-item protorec-semantic-filter-field';
    wrapper.setAttribute('data-protorec-filter-field', id);
    const label = document.createElement('label');
    label.textContent = String(field.label || id);
    const input = document.createElement(String(field.control || 'input') === 'select' ? 'select' : 'input');
    if (input.tagName.toLowerCase() === 'input') input.setAttribute('placeholder', String(field.placeholder || ''));
    wrapper.appendChild(label);
    wrapper.appendChild(input);
    form.appendChild(wrapper);
  });
}

function ensureFilterAddFieldsRendered(root: ParentNode, filterEdits: any) {
  const addFields = Array.isArray(filterEdits?.addFields) ? filterEdits.addFields : [];
  if (!addFields.length) return;
  const target = root.querySelector('form, .ant-pro-query-filter, .ant-form, .filter, .search') as HTMLElement | null;
  const container = target || root as HTMLElement;
  addFields.forEach((field: any, index: number) => {
    const id = String(field.id || 'new-filter-' + (index + 1));
    if (root.querySelector('[data-protorec-filter-field="' + CSS.escape(id) + '"]')) return;
    const wrapper = document.createElement('div');
    wrapper.className = 'ant-form-item protorec-semantic-filter-field';
    wrapper.setAttribute('data-protorec-filter-field', id);
    const label = document.createElement('label');
    label.textContent = String(field.label || id);
    const input = document.createElement(String(field.control || 'input') === 'select' ? 'select' : 'input');
    if (input.tagName.toLowerCase() === 'input') input.setAttribute('placeholder', String(field.placeholder || ''));
    wrapper.appendChild(label);
    wrapper.appendChild(input);
    container.appendChild(wrapper);
  });
}

function updateMenuFromSchema(root: ParentNode, schema: any, menuEdits: any) {
  if (!schema || !menuEdits) return;
  const menu = findSemanticTarget(root, schema.selector, 'aside, nav, [role="navigation"], [role="menu"], .ant-menu, .drawer-menu, .sidenav-menu') as HTMLElement | null;
  if (!menu) return;
  (Array.isArray(menuEdits.addItems) ? menuEdits.addItems : []).forEach((item: any, index: number) => {
    const id = String(item.id || 'new-menu-' + (index + 1));
    if (menu.querySelector('[data-protorec-menu-item="' + CSS.escape(id) + '"]')) return;
    const anchor = document.createElement('a');
    anchor.className = 'nav-link protorec-semantic-menu-item';
    anchor.setAttribute('data-protorec-menu-item', id);
    anchor.setAttribute('href', String(item.href || '#'));
    anchor.textContent = String(item.label || id);
    menu.appendChild(anchor);
  });
}

function applySemanticListEdits(markup: string, schemas: any, editConfig: Record<string, any>, semanticState: Record<string, any> = {}) {
  if (!hasSemanticEdits(editConfig) || typeof DOMParser === 'undefined' || typeof document === 'undefined') {
    return applySemanticListEditsByString(markup, schemas, editConfig, semanticState);
  }
  const parser = new DOMParser();
  const doc = parser.parseFromString('<div id="__protorec-edit-root">' + String(markup || '') + '</div>', 'text/html');
  const root = doc.querySelector('#__protorec-edit-root');
  if (!root) return String(markup || '');
  updateTableFromSchema(root, schemas?.tableSchema, editConfig.table);
  updateFilterFromSchema(root, schemas?.filterSchema, editConfig.filter, semanticState);
  ensureFilterAddFieldsRendered(root, editConfig.filter);
  updateMenuFromSchema(root, schemas?.menuSchema, editConfig.menu);
  return root.innerHTML;
}

function useSemanticListInteractions(setSemanticState: React.Dispatch<React.SetStateAction<Record<string, any>>>) {
  React.useEffect(() => {
    if (typeof document === 'undefined') return undefined;
    const handleClick = (event: MouseEvent) => {
      const target = event.target as HTMLElement | null;
      if (!target?.closest('[data-protorec-filter-toggle]')) return;
      event.preventDefault();
      setSemanticState((current) => ({
        ...current,
        filterCollapsed: !Boolean(current.filterCollapsed)
      }));
    };
    document.addEventListener('click', handleClick);
    return () => document.removeEventListener('click', handleClick);
  }, [setSemanticState]);
}
`;
}

function emitEditRouteLitePageEntry(pageIR = {}) {
  const pageClassName = `page-${pageIR.pageSlug}`;
  const componentName = `${toPascalCase(pageIR.pageSlug)}Page`;
  const previewBodyMarkup = '';
  const pageInteractions = Array.isArray(pageIR.interactions) ? pageIR.interactions : [];
  const semanticImportSource = "import { semanticSchemas as semanticSchemasFromSurface } from './semantic';\n";
  const semanticSchemasSource = 'semanticSchemasFromSurface';
  const semanticSchemaBaselineSource = escapeJsonForSource(pageIR.semanticSchemas || {});
  const hasFilterFragment = Boolean(pageIR?.semanticSchemas?.filterSchema);
  const filterFragmentImport = hasFilterFragment ? "import { fragmentHtml as filterFragmentHtml } from './fragments/filter';\n" : '';
  const routeFragmentImports = [
    "import { pageShellHtml, routeFragmentMarkers, fallbackFragments } from './fragments/page';",
    "import { fragmentHtml as tableFragmentHtml } from './fragments/table';",
    "import { fragmentHtml as menuFragmentHtml } from './fragments/menu';"
  ];
  if (hasFilterFragment) {
    routeFragmentImports.splice(2, 0, "import { fragmentHtml as filterFragmentHtml } from './fragments/filter';");
  }

  return `import React from 'react';
import './style.css';
${semanticImportSource}import {
  composeEditRouteLiteMarkup,
  applySemanticListEdits,
  buildSemanticSurfaceEditConfig,
  mergeSemanticEditConfigs,
  useSemanticListInteractions,
  sanitizePreviewBodyStyle,
  sanitizePreviewBodyDataAttributes
} from './edit-route-lite-runtime';
${routeFragmentImports.join('\n')}

type GeneratedPageComponent = React.FC & {
  previewHead?: string;
  previewBodyMarkup?: string;
  previewBodyClassName?: string;
  previewBodyStyle?: string;
  previewBodyDataAttributes?: string;
  pageInteractions?: unknown[];
  restoreSlug?: string;
  protocolVersion?: string;
};

const pageClassName = ${escapeJsonForSource(pageClassName)};
const pageMeta = ${escapeJsonForSource(pageIR.pageMeta || {})};
const viewMeta = ${escapeJsonForSource(pageIR.view || {})};
const readyState = ${escapeJsonForSource(pageIR.readyState || 'unknown')};
const editability = ${escapeJsonForSource(pageIR.editability || {})};
const semanticSchemas = ${semanticSchemasSource};
const semanticSchemaBaseline = ${semanticSchemaBaselineSource};
const semanticEditConfig: Record<string, any> = {};
const semanticSurfaceEditConfig = buildSemanticSurfaceEditConfig(semanticSchemas, semanticSchemaBaseline);
const activeSemanticEditConfig = mergeSemanticEditConfigs(semanticSurfaceEditConfig, semanticEditConfig);
const previewHead = ${escapeJsonForSource(pageIR.previewHead || '')};
const routeFragments: Record<string, string> = {
  table: tableFragmentHtml,
${hasFilterFragment ? '  filter: filterFragmentHtml,\n' : ''}  menu: menuFragmentHtml
};
const composedPreviewBodyMarkup = composeEditRouteLiteMarkup(pageShellHtml, routeFragments, fallbackFragments, routeFragmentMarkers);
const previewBodyMarkup = applySemanticListEdits(composedPreviewBodyMarkup, semanticSchemas, activeSemanticEditConfig, {
  filterCollapsed: Boolean(activeSemanticEditConfig?.filter?.defaultCollapsed)
});
const previewBodyClassName = ${escapeJsonForSource(pageIR.bodyAttributes?.className || '')};
const previewBodyStyle = ${escapeJsonForSource(pageIR.bodyAttributes?.style || '')};
const previewBodyDataAttributes = ${escapeJsonForSource(pageIR.bodyAttributes?.dataAttributes || '')};
const pageInteractions = ${escapeJsonForSource(pageInteractions)};

const BODY_SCROLL_LOCK_PROPERTIES = new Set([
  'overflow',
  'overflow-x',
  'overflow-y'
]);

const BODY_SCROLL_LOCK_DATA_ATTRIBUTE_NAMES = new Set([
  'data-restore-layout-overflow-x',
  'data-restore-layout-overflow-y',
  'data-restore-scroll-overflow-x',
  'data-restore-scroll-overflow-y'
]);

function escapePreviewBodyAttributeValue(value: string) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;');
}

function usePreviewBodyEnvironment(className: string, styleText: string, dataAttributes: string) {
  React.useEffect(() => {
    if (typeof document === 'undefined' || !document.body) return undefined;

    const body = document.body;
    const previousClassName = body.getAttribute('class') || '';
    const previousStyle = body.getAttribute('style') || '';
    const previousDataAttributes = Array.from(body.attributes)
      .filter((attribute) => attribute.name.startsWith('data-'))
      .map((attribute) => [attribute.name, attribute.value] as const);

    Array.from(body.attributes)
      .filter((attribute) => attribute.name.startsWith('data-'))
      .forEach((attribute) => body.removeAttribute(attribute.name));

    const sanitizedDataAttributes = sanitizePreviewBodyDataAttributes(dataAttributes);
    if (sanitizedDataAttributes.trim()) {
      const parser = document.createElement('div');
      parser.innerHTML = '<body ' + sanitizedDataAttributes + '></body>';
      const desiredBody = parser.firstElementChild;
      if (desiredBody) {
        Array.from(desiredBody.attributes).forEach((attribute) => {
          body.setAttribute(attribute.name, attribute.value);
        });
      }
    }

    if (className.trim()) body.setAttribute('class', className);
    else body.removeAttribute('class');

    const sanitizedStyleText = sanitizePreviewBodyStyle(styleText);
    if (sanitizedStyleText.trim()) body.setAttribute('style', sanitizedStyleText);
    else body.removeAttribute('style');

    return () => {
      previousDataAttributes.forEach(([name, value]) => body.setAttribute(name, value));
      Array.from(body.attributes)
        .filter((attribute) => attribute.name.startsWith('data-') && !previousDataAttributes.find(([name]) => name === attribute.name))
        .forEach((attribute) => body.removeAttribute(attribute.name));

      if (previousClassName) body.setAttribute('class', previousClassName);
      else body.removeAttribute('class');
      if (previousStyle) body.setAttribute('style', previousStyle);
      else body.removeAttribute('style');
    };
  }, [className, styleText, dataAttributes]);
}

const ${componentName}: GeneratedPageComponent = () => {
  usePreviewBodyEnvironment(previewBodyClassName, previewBodyStyle, previewBodyDataAttributes);
  const [semanticState, setSemanticState] = React.useState<Record<string, any>>({
    filterCollapsed: Boolean(activeSemanticEditConfig?.filter?.defaultCollapsed)
  });
  useSemanticListInteractions(setSemanticState);
  const renderedPreviewBodyMarkup = React.useMemo(() => (
    applySemanticListEdits(composedPreviewBodyMarkup, semanticSchemas, activeSemanticEditConfig, semanticState)
  ), [semanticState.filterCollapsed]);

  return (
    <div
      className={pageClassName}
      data-page-id={pageMeta.id}
      data-route-id={pageMeta.routeId}
      data-view-id={pageMeta.viewId}
      data-view-kind={viewMeta.viewKind}
      data-protorec-is-subview={viewMeta.isSubview ? 'true' : 'false'}
      data-archetype={pageMeta.archetype}
      data-generation-mode={pageMeta.generationMode}
      data-ready-state={readyState}
      data-editability-status={editability.status}
      data-editability-score={editability.score}
      dangerouslySetInnerHTML={{ __html: renderedPreviewBodyMarkup }}
    />
  );
};

${componentName}.previewHead = previewHead;
${componentName}.previewBodyMarkup = '<div class="' + pageClassName + '" data-page-id="' + String(pageMeta.id || '') + '" data-route-id="' + String(pageMeta.routeId || '') + '" data-view-id="' + String(pageMeta.viewId || '') + '" data-view-kind="' + String(viewMeta.viewKind || '') + '" data-protorec-is-subview="' + (viewMeta.isSubview ? 'true' : 'false') + '" data-archetype="' + String(pageMeta.archetype || '') + '" data-generation-mode="' + String(pageMeta.generationMode || '') + '" data-ready-state="' + readyState + '" data-editability-status="' + String(editability.status || '') + '" data-editability-score="' + String(editability.score || '') + '">' + previewBodyMarkup + '</div>';
${componentName}.previewBodyClassName = previewBodyClassName;
${componentName}.previewBodyStyle = sanitizePreviewBodyStyle(previewBodyStyle);
${componentName}.previewBodyDataAttributes = sanitizePreviewBodyDataAttributes(previewBodyDataAttributes);
${componentName}.pageInteractions = pageInteractions;
${componentName}.restoreSlug = pageMeta.routeId;
${componentName}.protocolVersion = pageMeta.protocolVersion;
${componentName}.displayName = ${escapeJsonForSource(componentName)};

export default ${componentName};
`;
}

function emitPageEntry(pageIR, options = {}) {
  if (options.useEditRouteLiteThinEntry) {
    return emitEditRouteLitePageEntry(pageIR);
  }

  const pageClassName = `page-${pageIR.pageSlug}`;
  const componentName = `${toPascalCase(pageIR.pageSlug)}Page`;
  const previewBodyMarkup = pageIR?.structuralDecomposition
    ? ''
    : buildPreviewBodyMarkup(pageIR);
  const namedFallbackFragmentSource = buildNamedFallbackFragmentSource(pageIR);
  const pageInteractions = Array.isArray(pageIR.interactions) ? pageIR.interactions : [];
  const usesSemanticSurface = hasSemanticSurface(pageIR);
  const semanticImportSource = usesSemanticSurface
    ? "import { semanticSchemas as semanticSchemasFromSurface } from './semantic';\n"
    : '';
  const semanticSchemasSource = usesSemanticSurface
    ? 'semanticSchemasFromSurface'
    : escapeJsonForSource(pageIR.semanticSchemas || {});
  const semanticSchemaBaselineSource = usesSemanticSurface
    ? escapeJsonForSource(pageIR.semanticSchemas || {})
    : 'semanticSchemas';

  return `import React from 'react';
import './style.css';
${semanticImportSource}

type GeneratedPageComponent = React.FC & {
  previewHead?: string;
  previewBodyMarkup?: string;
  previewBodyClassName?: string;
  previewBodyStyle?: string;
  previewBodyDataAttributes?: string;
  pageInteractions?: unknown[];
  restoreSlug?: string;
  protocolVersion?: string;
};

const pageClassName = ${escapeJsonForSource(pageClassName)};
const pageMeta = ${escapeJsonForSource(pageIR.pageMeta || {})};
const viewMeta = ${escapeJsonForSource(pageIR.view || {})};
const readyState = ${escapeJsonForSource(pageIR.readyState || 'unknown')};
const editability = ${escapeJsonForSource(pageIR.editability || {})};
const semanticSchemas = ${semanticSchemasSource};
const semanticSchemaBaseline = ${semanticSchemaBaselineSource};
const semanticEditConfig: Record<string, any> = {};
const semanticSurfaceEditConfig = buildSemanticSurfaceEditConfig(semanticSchemas, semanticSchemaBaseline);
const activeSemanticEditConfig = mergeSemanticEditConfigs(semanticSurfaceEditConfig, semanticEditConfig);
const previewHead = ${escapeJsonForSource(pageIR.previewHead || '')};
const previewBodyMarkupRaw = ${escapeJsonForSource(previewBodyMarkup)};
${namedFallbackFragmentSource}
${buildSemanticRuntimeSource()}
const previewBodyMarkup = applySemanticListEdits(previewBodyMarkupBase, semanticSchemas, activeSemanticEditConfig, {
  filterCollapsed: Boolean(activeSemanticEditConfig?.filter?.defaultCollapsed)
});
const previewBodyClassName = ${escapeJsonForSource(pageIR.bodyAttributes?.className || '')};
const previewBodyStyle = ${escapeJsonForSource(pageIR.bodyAttributes?.style || '')};
const previewBodyDataAttributes = ${escapeJsonForSource(pageIR.bodyAttributes?.dataAttributes || '')};
const pageInteractions = ${escapeJsonForSource(pageInteractions)};

const BODY_SCROLL_LOCK_PROPERTIES = new Set([
  'overflow',
  'overflow-x',
  'overflow-y'
]);

const BODY_SCROLL_LOCK_DATA_ATTRIBUTE_NAMES = new Set([
  'data-restore-layout-overflow-x',
  'data-restore-layout-overflow-y',
  'data-restore-scroll-overflow-x',
  'data-restore-scroll-overflow-y'
]);

function sanitizePreviewBodyStyle(styleText: string) {
  return String(styleText || '')
    .split(';')
    .map((entry) => entry.trim())
    .filter(Boolean)
    .filter((declaration) => {
      const separatorIndex = declaration.indexOf(':');
      if (separatorIndex < 0) return false;
      const property = declaration.slice(0, separatorIndex).trim().toLowerCase();
      const value = declaration.slice(separatorIndex + 1).trim().toLowerCase();
      if (!property || !value) return false;
      return !(BODY_SCROLL_LOCK_PROPERTIES.has(property) && /^(hidden|clip)$/.test(value));
    })
    .join('; ');
}

function escapePreviewBodyAttributeValue(value: string) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;');
}

function sanitizePreviewBodyDataAttributes(dataAttributes: string) {
  if (!String(dataAttributes || '').trim() || typeof document === 'undefined') {
    return String(dataAttributes || '');
  }

  const parser = document.createElement('div');
  parser.innerHTML = '<body ' + dataAttributes + '></body>';
  const desiredBody = parser.firstElementChild;
  if (!desiredBody) return String(dataAttributes || '');

  Array.from(desiredBody.attributes).forEach((attribute) => {
    const name = String(attribute.name || '').toLowerCase();
    const value = String(attribute.value || '').trim().toLowerCase();
    if (BODY_SCROLL_LOCK_DATA_ATTRIBUTE_NAMES.has(name) && /^(hidden|clip)$/.test(value)) {
      desiredBody.removeAttribute(attribute.name);
    }
  });

  return Array.from(desiredBody.attributes)
    .map((attribute) => ' ' + attribute.name + '="' + escapePreviewBodyAttributeValue(attribute.value) + '"')
    .join('');
}

function usePreviewBodyEnvironment(className: string, styleText: string, dataAttributes: string) {
  React.useEffect(() => {
    if (typeof document === 'undefined' || !document.body) return undefined;

    const body = document.body;
    const previousClassName = body.getAttribute('class') || '';
    const previousStyle = body.getAttribute('style') || '';
    const previousDataAttributes = Array.from(body.attributes)
      .filter((attribute) => attribute.name.startsWith('data-'))
      .map((attribute) => [attribute.name, attribute.value] as const);

    Array.from(body.attributes)
      .filter((attribute) => attribute.name.startsWith('data-'))
      .forEach((attribute) => body.removeAttribute(attribute.name));

    const sanitizedDataAttributes = sanitizePreviewBodyDataAttributes(dataAttributes);
    if (sanitizedDataAttributes.trim()) {
      const parser = document.createElement('div');
      parser.innerHTML = '<body ' + sanitizedDataAttributes + '></body>';
      const desiredBody = parser.firstElementChild;
      if (desiredBody) {
        Array.from(desiredBody.attributes).forEach((attribute) => {
          body.setAttribute(attribute.name, attribute.value);
        });
      }
    }

    if (className.trim()) body.setAttribute('class', className);
    else body.removeAttribute('class');

    const sanitizedStyleText = sanitizePreviewBodyStyle(styleText);
    if (sanitizedStyleText.trim()) body.setAttribute('style', sanitizedStyleText);
    else body.removeAttribute('style');

    return () => {
      previousDataAttributes.forEach(([name, value]) => body.setAttribute(name, value));
      Array.from(body.attributes)
        .filter((attribute) => attribute.name.startsWith('data-') && !previousDataAttributes.find(([name]) => name === attribute.name))
        .forEach((attribute) => body.removeAttribute(attribute.name));

      if (previousClassName) body.setAttribute('class', previousClassName);
      else body.removeAttribute('class');
      if (previousStyle) body.setAttribute('style', previousStyle);
      else body.removeAttribute('style');
    };
  }, [className, styleText, dataAttributes]);
}

const ${componentName}: GeneratedPageComponent = () => {
  usePreviewBodyEnvironment(previewBodyClassName, previewBodyStyle, previewBodyDataAttributes);
  const [semanticState, setSemanticState] = React.useState<Record<string, any>>({
    filterCollapsed: Boolean(activeSemanticEditConfig?.filter?.defaultCollapsed)
  });
  useSemanticListInteractions(setSemanticState);
  const renderedPreviewBodyMarkup = React.useMemo(() => (
    applySemanticListEdits(previewBodyMarkupBase, semanticSchemas, activeSemanticEditConfig, semanticState)
  ), [semanticState.filterCollapsed]);

  return (
    <div
      className={pageClassName}
      data-page-id={pageMeta.id}
      data-route-id={pageMeta.routeId}
      data-view-id={pageMeta.viewId}
      data-view-kind={viewMeta.viewKind}
      data-protorec-is-subview={viewMeta.isSubview ? 'true' : 'false'}
      data-archetype={pageMeta.archetype}
      data-generation-mode={pageMeta.generationMode}
      data-ready-state={readyState}
      data-editability-status={editability.status}
      data-editability-score={editability.score}
      dangerouslySetInnerHTML={{ __html: renderedPreviewBodyMarkup }}
    />
  );
};

${componentName}.previewHead = previewHead;
${componentName}.previewBodyMarkup = '<div class="' + pageClassName + '" data-page-id="' + String(pageMeta.id || '') + '" data-route-id="' + String(pageMeta.routeId || '') + '" data-view-id="' + String(pageMeta.viewId || '') + '" data-view-kind="' + String(viewMeta.viewKind || '') + '" data-protorec-is-subview="' + (viewMeta.isSubview ? 'true' : 'false') + '" data-archetype="' + String(pageMeta.archetype || '') + '" data-generation-mode="' + String(pageMeta.generationMode || '') + '" data-ready-state="' + readyState + '" data-editability-status="' + String(editability.status || '') + '" data-editability-score="' + String(editability.score || '') + '">' + previewBodyMarkup + '</div>';
${componentName}.previewBodyClassName = previewBodyClassName;
${componentName}.previewBodyStyle = sanitizePreviewBodyStyle(previewBodyStyle);
${componentName}.previewBodyDataAttributes = sanitizePreviewBodyDataAttributes(previewBodyDataAttributes);
${componentName}.pageInteractions = pageInteractions;
${componentName}.restoreSlug = pageMeta.routeId;
${componentName}.protocolVersion = pageMeta.protocolVersion;
${componentName}.displayName = ${escapeJsonForSource(componentName)};

export default ${componentName};
`;
}

module.exports = {
  emitPageEntry,
  emitEditRouteLitePageEntry,
  buildSemanticRuntimeSource
};
