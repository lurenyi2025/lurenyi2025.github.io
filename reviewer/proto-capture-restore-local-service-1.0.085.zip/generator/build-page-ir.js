const fs = require('fs-extra');
const path = require('path');
const cheerio = require('cheerio');
const { sanitizeRuntimeStyleTextWithSelectorMatchCount } = require('./css-sanitizer');

const { GENERATION_MODE, PREVIEW_STATIC_ROOT, PROTOCOL_VERSION } = require('./config');
const { prepareLocalizedHtmlForGeneration } = require('../scripts/restore');
const { classifyPage } = require('./classify-page');
const { applyStructuralDecomposition } = require('./structural-decomposition');
const { compactEditRouteLiteStructuralResult } = require('./edit-route-lite-fragment-compact');
const { extractSemanticSchemas } = require('./semantic-schema');
const { evaluateQAGate, resolveReadyState } = require('./protocol');
const {
  buildPageSlug,
  createUniqueNameFactory,
  getBlockComponentName,
  getSectionComponentName,
  getSectionTitle,
  sanitizeReadableSegment,
  sanitizeSegment
} = require('./naming');
const {
  BLOCKABLE_SECTION_KINDS,
  BLOCK_SECTION_PROMOTION_KINDS,
  GENERATOR_SELECTORS,
  STRONG_SECTION_KINDS,
  collectBlockRuleMatchesFromSignals,
  collectSectionRuleMatchesFromSignals,
  inferBlockKindFromSignals,
  inferSectionKindFromSignals,
  matchesAnchorTabLabel,
  matchesStableIdentityHint
} = require('./rule-registry');
const { resolveSiteAdapterByUrl } = require('../adapters/site-registry');

// Historical page-specific refinements are retained only as an explicit opt-in
// adapter while the active capture path is kept generic.
const ENABLE_HISTORICAL_PAGE_REFINEMENTS = process.env.PROTOREC_ENABLE_HISTORICAL_PAGE_REFINEMENTS === '1';

const FONT_EXTENSIONS = new Set(['.woff', '.woff2', '.ttf', '.otf', '.eot']);
const IMAGE_EXTENSIONS = new Set(['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.ico', '.bmp', '.avif']);
const SVG_DEFINITION_TAGS = new Set([
  'symbol',
  'defs',
  'clippath',
  'mask',
  'pattern',
  'lineargradient',
  'radialgradient',
  'stop',
  'metadata',
  'desc',
  'title'
]);
const CONTEXT_ATTRIBUTE_ALLOWLIST = new Set(['id', 'class', 'style', 'role', 'dir', 'lang', 'title', 'tabindex', 'hidden']);
const NOISE_SELECTORS = [
  'script',
  'noscript',
  '#__caoliao-browser-ext-root',
  '#__caoliao-browser-ext',
  'browser-mcp-container',
  '#c4g-content-root',
  '.c4g-widget'
].join(',');

function normalizePathForUrl(filePath) {
  return filePath.split(path.sep).join('/');
}

function normalizeAbsoluteReference(value, origin) {
  const trimmed = String(value || '').trim();
  if (!trimmed) {
    return '';
  }

  try {
    return new URL(trimmed, origin || 'http://localhost').href;
  } catch (_error) {
    return '';
  }
}

function escapeHtml(value) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function getAssetCategory(fileName) {
  const extension = path.extname(String(fileName || '')).toLowerCase();
  if (FONT_EXTENSIONS.has(extension)) {
    return 'fonts';
  }

  if (IMAGE_EXTENSIONS.has(extension)) {
    return 'images';
  }

  return 'images';
}

function stripProtoAttributes(markup) {
  return String(markup || '')
    .replace(/\sdata-protorec-section="[^"]*"/g, '')
    .replace(/\sdata-protorec-role="[^"]*"/g, '');
}

function normalizeTextSnippet(value, maxLength = 80) {
  return String(value || '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, maxLength);
}

function buildPreviewBodyDataAttributes(attributes = {}) {
  return Object.entries(attributes)
    .filter(([name]) => name.startsWith('data-'))
    .map(([name, value]) => ` ${name}="${escapeHtml(value)}"`)
    .join('');
}

function toNumericScore(value, fallback = 0.55) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) {
    return fallback;
  }

  const normalized = parsed > 1 ? parsed / 100 : parsed;
  return Math.max(0, Math.min(1, Number(normalized.toFixed(4))));
}

function buildGenerationAssetMap(assets = []) {
  const assetMap = new Map();

  assets.forEach((asset) => {
    if (!asset?.fileName || !asset?.relativeAssetPath) {
      return;
    }

    assetMap.set(asset.fileName, asset.relativeAssetPath);
  });

  return assetMap;
}

async function collectCaptureAssets(captureDir, pageAssetSlug, pageDirRelativePath, assetOwnerRelativePath) {
  const assetRoot = path.join(captureDir, 'temp_assets');
  if (!(await fs.pathExists(assetRoot))) {
    return [];
  }

  const assetBaseRelativePath = assetOwnerRelativePath || pageDirRelativePath;
  const relativeToAssetsRoot = normalizePathForUrl(
    path.relative(
      pageDirRelativePath,
      path.join(assetBaseRelativePath, 'assets')
    )
  ) || '.';
  const assetFiles = await fs.readdir(assetRoot);

  return assetFiles
    .sort()
    .map((fileName) => {
      const category = getAssetCategory(fileName);
      const relativeAssetPath = normalizePathForUrl(path.join(relativeToAssetsRoot, category, fileName));
      const previewUrl = `${PREVIEW_STATIC_ROOT}/${normalizePathForUrl(path.join(assetBaseRelativePath, 'assets', category, fileName))}`;

      return {
        fileName,
        category,
        sourcePath: path.join(assetRoot, fileName),
        relativeAssetPath,
        previewUrl
      };
    });
}

function buildAssetReferenceMaps(assets = []) {
  const localAssetReferenceMap = new Map();
  const previewAssetReferenceMap = new Map();
  const byFileName = new Map();

  assets.forEach((asset) => {
    const localCandidates = [
      `./temp_assets/${asset.fileName}`,
      `temp_assets/${asset.fileName}`,
      `/temp_assets/${asset.fileName}`
    ];

    localCandidates.forEach((candidate) => {
      localAssetReferenceMap.set(candidate, asset.relativeAssetPath);
      previewAssetReferenceMap.set(candidate, asset.previewUrl);
    });

    byFileName.set(asset.fileName, asset);
  });

  return {
    byFileName,
    localAssetReferenceMap,
    previewAssetReferenceMap
  };
}

function resolveAssetReference(value, explicitMap, byFileName) {
  const rawValue = String(value || '').trim();
  if (!rawValue) {
    return rawValue;
  }

  if (rawValue.startsWith('data:') || rawValue.startsWith('blob:') || rawValue.startsWith('#') || /^(?:[a-z]+:)?\/\//i.test(rawValue)) {
    return rawValue;
  }

  const withoutHash = rawValue.split('#')[0];
  const [pathPart, queryPart] = withoutHash.split('?');
  const explicitMatch = explicitMap.get(pathPart) || explicitMap.get(rawValue);
  if (explicitMatch) {
    return queryPart ? `${explicitMatch}?${queryPart}` : explicitMatch;
  }

  const fileName = path.basename(pathPart);
  const fileAsset = byFileName.get(fileName);
  if (!fileAsset) {
    return rawValue;
  }

  const explicitPath = explicitMap.get(`./temp_assets/${fileAsset.fileName}`) || explicitMap.get(`temp_assets/${fileAsset.fileName}`);
  return queryPart && explicitPath ? `${explicitPath}?${queryPart}` : (explicitPath || rawValue);
}

function rewriteStyleValue(styleValue, explicitMap, byFileName) {
  if (!styleValue || !String(styleValue).includes('url(')) {
    return styleValue;
  }

  return String(styleValue).replace(/url\((['"]?)([^'")]+)\1\)/g, (match, quote, assetUrl) => {
    const nextUrl = resolveAssetReference(assetUrl, explicitMap, byFileName);
    if (!nextUrl || nextUrl === assetUrl) {
      return match;
    }

    return `url(${quote}${nextUrl}${quote})`;
  });
}

function rewriteSrcsetValue(srcsetValue, explicitMap, byFileName) {
  if (!srcsetValue) {
    return srcsetValue;
  }

  return String(srcsetValue)
    .split(',')
    .map((entry) => {
      const trimmed = entry.trim();
      if (!trimmed) {
        return trimmed;
      }

      const parts = trimmed.split(/\s+/);
      const assetUrl = parts.shift();
      const descriptor = parts.join(' ');
      const nextUrl = resolveAssetReference(assetUrl, explicitMap, byFileName);
      return [nextUrl || assetUrl, descriptor].filter(Boolean).join(' ');
    })
    .join(', ');
}

function rewriteMarkupAssets(markup, explicitMap, byFileName) {
  if (!markup) {
    return markup;
  }

  const $ = cheerio.load(`<div id="__protorec-root">${markup}</div>`, { decodeEntities: false });
  const assetAttributes = ['src', 'poster', 'href', 'data-src', 'data-original', 'data-url', 'data-image', 'data-bg', 'data-background-image'];

  assetAttributes.forEach((attributeName) => {
    $(`[${attributeName}]`).each((_, element) => {
      const $element = $(element);
      const currentValue = $element.attr(attributeName);
      const nextValue = resolveAssetReference(currentValue, explicitMap, byFileName);
      if (nextValue && nextValue !== currentValue) {
        $element.attr(attributeName, nextValue);
      }
    });
  });

  $('[srcset]').each((_, element) => {
    const $element = $(element);
    $element.attr('srcset', rewriteSrcsetValue($element.attr('srcset'), explicitMap, byFileName));
  });

  $('[style*="url("]').each((_, element) => {
    const $element = $(element);
    $element.attr('style', rewriteStyleValue($element.attr('style'), explicitMap, byFileName));
  });

  $('style').each((_, element) => {
    const $element = $(element);
    $element.html(rewriteStyleValue($element.html() || '', explicitMap, byFileName));
  });

  return $('#__protorec-root').html() || markup;
}

function getStylesheetFileName(stylesheetHref) {
  return path.basename(String(stylesheetHref || '').split(/[?#]/)[0]);
}

function buildStylesheetLookupKey(fileName) {
  return String(fileName || '')
    .trim()
    .toLowerCase()
    .replace(/\.css$/i, '')
    .replace(/[^a-z0-9_]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function stripLocalizedStylesheetSuffix(lookupKey) {
  return String(lookupKey || '').replace(/-[a-f0-9]{8,}$/i, '');
}

async function buildTempStylesheetLookup(captureDir) {
  const lookup = {
    exact: new Map(),
    normalized: new Map()
  };

  if (!captureDir) {
    return lookup;
  }

  const tempStylesDir = path.join(captureDir, 'temp_styles');
  if (!(await fs.pathExists(tempStylesDir))) {
    return lookup;
  }

  const entries = await fs.readdir(tempStylesDir, { withFileTypes: true });
  entries.forEach((entry) => {
    if (!entry.isFile()) {
      return;
    }

    const fileName = entry.name;
    const absolutePath = path.join(tempStylesDir, fileName);
    lookup.exact.set(fileName, absolutePath);

    const normalizedKey = stripLocalizedStylesheetSuffix(buildStylesheetLookupKey(fileName));
    if (!normalizedKey) {
      return;
    }

    if (!lookup.normalized.has(normalizedKey)) {
      lookup.normalized.set(normalizedKey, []);
    }

    lookup.normalized.get(normalizedKey).push({
      fileName,
      absolutePath
    });
  });

  lookup.normalized.forEach((candidates) => {
    candidates.sort((left, right) => (
      left.fileName.length - right.fileName.length
      || left.fileName.localeCompare(right.fileName)
    ));
  });

  return lookup;
}

async function resolveLocalStylesheetPath(captureDir, stylesheetHref, lookupPromise) {
  if (!captureDir) {
    return '';
  }

  const fileName = getStylesheetFileName(stylesheetHref);
  if (!fileName) {
    return '';
  }

  const lookup = await lookupPromise;
  if (lookup.exact.has(fileName)) {
    return lookup.exact.get(fileName);
  }

  const normalizedKey = buildStylesheetLookupKey(fileName);
  if (!normalizedKey) {
    return '';
  }

  const candidates = lookup.normalized.get(stripLocalizedStylesheetSuffix(normalizedKey)) || [];
  return candidates[0]?.absolutePath || '';
}

async function collectStyleText({ $, captureDir, metadata = {}, explicitMap, byFileName }) {
  const cssBlocks = [];
  const seenBlocks = new Set();
  const stylesheetLookupPromise = buildTempStylesheetLookup(captureDir);
  const selectorMatchCount = (selector) => {
    const normalizedSelector = String(selector || '').trim();
    if (!normalizedSelector) {
      return null;
    }

    try {
      return $(normalizedSelector).length;
    } catch (_error) {
      return null;
    }
  };

  const pushCssBlock = (cssText) => {
    const normalized = String(cssText || '').trim();
    if (!normalized) {
      return;
    }

    const rewritten = rewriteStyleValue(normalized, explicitMap, byFileName);
    if (seenBlocks.has(rewritten)) {
      return;
    }

    seenBlocks.add(rewritten);
    cssBlocks.push(rewritten);
  };

  $('style').each((_, element) => {
    pushCssBlock($(element).html() || '');
  });

  const stylesheetLinks = $('link[rel~="stylesheet"]')
    .toArray()
    .map((element) => $(element).attr('href'))
    .filter(Boolean);

  for (const stylesheetHref of stylesheetLinks) {
    const localStylePath = await resolveLocalStylesheetPath(captureDir, stylesheetHref, stylesheetLookupPromise);
    if (!localStylePath) {
      continue;
    }

    pushCssBlock(await fs.readFile(localStylePath, 'utf8'));
  }

  const runtimeStyleTexts = Array.isArray(metadata.runtimeStyleTexts) ? metadata.runtimeStyleTexts : [];
  runtimeStyleTexts.forEach((cssText) => {
    pushCssBlock(sanitizeRuntimeStyleTextWithSelectorMatchCount(cssText, selectorMatchCount));
  });

  return cssBlocks.join('\n\n');
}

const GENERIC_NAME_TOKENS = new Set([
  'app',
  'body',
  'box',
  'container',
  'content',
  'default',
  'inner',
  'index',
  'item',
  'layout',
  'main',
  'module',
  'page',
  'panel',
  'react',
  'region',
  'root',
  'select',
  'section',
  'shell',
  'slot',
  'view',
  'wrapper'
]);
const TAB_CONTAINER_SELECTOR = GENERATOR_SELECTORS.tabContainer;
const TAB_SELECTOR = GENERATOR_SELECTORS.tab;
const PANEL_SELECTOR = GENERATOR_SELECTORS.panel;
const CAROUSEL_CONTAINER_SELECTOR = GENERATOR_SELECTORS.carouselContainer;
const CAROUSEL_SLIDE_SELECTOR = GENERATOR_SELECTORS.carouselSlide;
const CAROUSEL_CONTROL_SELECTOR = GENERATOR_SELECTORS.carouselControl;
const DISMISSIBLE_LAYER_SELECTOR = GENERATOR_SELECTORS.dismissibleLayer;
const DISMISS_BUTTON_SELECTOR = GENERATOR_SELECTORS.dismissButton;
const DROPDOWN_GROUP_SELECTOR = GENERATOR_SELECTORS.dropdownGroup;
const DROPDOWN_MENU_SELECTOR = GENERATOR_SELECTORS.dropdownMenu;

function getInlineStyle($element) {
  return String($element.attr('style') || '').toLowerCase();
}

function isFrameworkUtilityNode($, $element, stats = getElementStats($, $element)) {
  const tagName = getElementTagName($element.get(0));
  const identity = getElementIdentity($element);
  const inlineStyle = getInlineStyle($element);
  const ariaLive = String($element.attr('aria-live') || '').toLowerCase();
  const role = String($element.attr('role') || '').toLowerCase();

  if (/^(next-route-announcer|nextjs-portal|nextjs-portal-root|template)$/.test(tagName)) {
    return true;
  }

  if (/(__next-route-announcer__|next-route-announcer|headlessui-portal-root|radix-.*portal)/.test(identity)) {
    return true;
  }

  return !stats.textLength
    && !stats.imageCount
    && !stats.inputCount
    && (ariaLive || role === 'alert')
    && /(clip\s*:|clip-path\s*:|width\s*:\s*1px|height\s*:\s*1px|position\s*:\s*absolute)/.test(inlineStyle);
}

function isFrameworkStructuralRoot($, $element, stats = getElementStats($, $element)) {
  const identity = getElementIdentity($element);

  if (!stats.childCount) {
    return false;
  }

  return $element.attr('data-reactroot') !== undefined
    || /(^|\s)(__next|__nuxt|__remix|gatsby-focus-wrapper|gatsby-announcer)(\s|$)/.test(identity);
}

function isHiddenUtilityNode($, $element, stats = getElementStats($, $element)) {
  const inlineStyle = getInlineStyle($element);
  const identity = getElementIdentity($element);

  if (isFrameworkUtilityNode($, $element, stats)) {
    return true;
  }

  if (!/display\s*:\s*none/.test(inlineStyle) && !/visibility\s*:\s*hidden/.test(inlineStyle)) {
    return false;
  }

  if (/background-image\s*:/.test(inlineStyle)) {
    return false;
  }

  return !stats.textLength
    && !stats.imageCount
    && !stats.inputCount
    && stats.childCount <= 1
    && !/(dialog|modal|cookie|banner|drawer|toast|popup)/.test(identity);
}

function isPlaceholderShell($, $element, stats = getElementStats($, $element)) {
  const tagName = getElementTagName($element.get(0));
  const inlineStyle = getInlineStyle($element);
  const identity = getElementIdentity($element);

  if (/background-image\s*:/.test(inlineStyle)) {
    return false;
  }

  if (stats.textLength || stats.imageCount || stats.inputCount || stats.headingCount) {
    return false;
  }

  if (isHiddenUtilityNode($, $element, stats)) {
    return true;
  }

  if (stats.childCount === 0 && stats.htmlLength <= 96) {
    return true;
  }

  if (
    stats.childCount <= 1
    && stats.htmlLength <= 180
    && /(root|container|wrapper|mount|region|portal|select|slot|placeholder)/.test(identity)
    && ['div', 'section', 'aside', 'nav', 'header', 'footer'].includes(tagName)
  ) {
    return true;
  }

  return false;
}

function isLikelySpacer($, $element, stats = getElementStats($, $element)) {
  const inlineStyle = getInlineStyle($element);
  const identity = getElementIdentity($element);

  if (isPlaceholderShell($, $element, stats)) {
    return true;
  }

  if (
    !stats.textLength
    && !stats.imageCount
    && !stats.inputCount
    && stats.childCount === 0
    && stats.htmlLength <= 96
  ) {
    return true;
  }

  if (
    !stats.textLength
    && !stats.imageCount
    && stats.childCount <= 1
    && stats.htmlLength <= 180
    && /(margin-top|margin-bottom|padding-top|padding-bottom|height\s*:)/.test(inlineStyle)
  ) {
    return true;
  }

  return /(spacer|divider|separator|gap)/.test(identity)
    && !stats.textLength
    && !stats.imageCount;
}

function getElementIdentity($element) {
  return [
    String($element.attr('id') || ''),
    String($element.attr('class') || ''),
    String($element.attr('role') || ''),
    String($element.attr('data-testid') || ''),
    String($element.attr('aria-label') || ''),
    String($element.attr('name') || '')
  ].join(' ').toLowerCase();
}

function getElementTagName(element) {
  return String(element?.tagName || element?.name || '').toLowerCase();
}

function isSvgDefinitionContainer($element) {
  const tagName = getElementTagName($element.get(0));
  if (SVG_DEFINITION_TAGS.has(tagName)) {
    return true;
  }

  if (tagName !== 'svg') {
    return false;
  }

  const childTagNames = $element
    .children()
    .toArray()
    .map((child) => getElementTagName(child))
    .filter(Boolean);

  return childTagNames.length > 0
    && childTagNames.every((childTagName) => SVG_DEFINITION_TAGS.has(childTagName));
}

function getElementStats($, $element) {
  const htmlLength = String($.html($element) || '').trim().length;
  const textContent = normalizeTextSnippet($element.text() || '', 240);

  return {
    htmlLength,
    textLength: textContent.length,
    textSnippet: textContent,
    childCount: $element.children().length,
    headingCount: $element.find('h1, h2, h3, h4, [role="heading"]').length,
    imageCount: $element.find('img, picture, svg, canvas, video').length,
    inputCount: $element.find('input, select, textarea, [role="textbox"], [contenteditable="true"]').length,
    tabCount: $element.find(TAB_SELECTOR).length
  };
}

function isMeaningfulElement($, element) {
  if (!element || element.type !== 'tag') {
    return false;
  }

  const $element = $(element);
  const tagName = getElementTagName(element);
  if (!tagName || ['meta', 'title', 'style', 'link', 'script', 'noscript'].includes(tagName)) {
    return false;
  }

  if (isSvgDefinitionContainer($element)) {
    return false;
  }

  const stats = getElementStats($, $element);
  if (isFrameworkUtilityNode($, $element, stats)) {
    return false;
  }
  if (isPlaceholderShell($, $element, stats)) {
    return false;
  }

  if (
    !stats.textLength
    && !stats.imageCount
    && !stats.inputCount
    && !stats.headingCount
    && stats.childCount <= 1
    && stats.htmlLength <= 1200
  ) {
    return false;
  }

  return Boolean(
    stats.textLength
    || stats.imageCount
    || stats.inputCount
    || stats.headingCount
    || stats.childCount >= 2
    || stats.htmlLength > 320
  );
}

function collectMeaningfulChildren($, $element) {
  return $element
    .children()
    .toArray()
    .filter((element) => isMeaningfulElement($, element))
    .filter((element) => !isLikelySpacer($, $(element)));
}

function normalizeNameCandidate(value) {
  return sanitizeSegment(String(value || '').replace(/([a-z0-9])([A-Z])/g, '$1-$2'));
}

function normalizeCompactText(value) {
  return String(value || '')
    .replace(/\s+/g, '')
    .trim();
}

function isGenericNameToken(value) {
  const normalized = normalizeNameCandidate(value);
  if (!normalized || normalized.length < 3) {
    return true;
  }

  if (/^(react|region|content|page|layout)-/.test(normalized) || /-root$/.test(normalized) && /^(react|region|content|page|layout)/.test(normalized)) {
    return true;
  }

  return normalized
    .split('-')
    .every((segment) => !segment || GENERIC_NAME_TOKENS.has(segment));
}

function looksLikeOverlay($element) {
  const identity = `${getElementTagName($element.get(0))} ${getElementIdentity($element)}`;
  const inlineStyle = String($element.attr('style') || '').toLowerCase();

  return /(cookie|modal|dialog|drawer|offcanvas|customizer|style-switcher|popover|tooltip|toast|popup|float|floating)/.test(identity)
    || /position\s*:\s*fixed/.test(inlineStyle)
    || /position\s*:\s*sticky/.test(inlineStyle);
}

function buildElementRuleSignals($element, stats = null, options = {}) {
  const fallbackTextContent = normalizeTextSnippet($element.text() || '', 240);
  const resolvedStats = stats || {
    htmlLength: String($element.toString?.() || '').trim().length,
    textLength: fallbackTextContent.length,
    textSnippet: fallbackTextContent,
    childCount: $element.children().length,
    headingCount: $element.find('h1, h2, h3, h4, [role="heading"]').length,
    imageCount: $element.find('img, picture, svg, canvas, video').length,
    inputCount: $element.find('input, select, textarea, [role="textbox"], [contenteditable="true"]').length,
    tabCount: $element.find(TAB_SELECTOR).length
  };
  const textContent = normalizeTextSnippet($element.text() || '', 160);
  const loweredText = textContent.toLowerCase();
  const identity = getElementIdentity($element);
  const tokenList = identity
    .split(/\s+/)
    .map(normalizeNameCandidate)
    .filter(Boolean);
  const isGenericIdentity = !tokenList.length
    || tokenList.every((token) => isGenericNameToken(token) || /(root|wrapper|container|layout|shell|inner|content)/.test(token));
  const activeAdapter = options.siteAdapter || null;

  return {
    identity,
    tagName: getElementTagName($element.get(0)),
    stats: resolvedStats,
    textContent,
    loweredText,
    compactText: normalizeCompactText(textContent),
    idCandidate: normalizeNameCandidate($element.attr('id') || options.descendantId || ''),
    activeAdapterId: activeAdapter?.id || '',
    siteAdapter: activeAdapter,
    hasTabs: typeof options.hasTabs === 'boolean' ? options.hasTabs : $element.find(TAB_SELECTOR).length >= 2,
    hasTable: typeof options.hasTable === 'boolean' ? options.hasTable : $element.find('table, [role="table"], .ant-table, .el-table').length > 0,
    looksLikeOverlay: typeof options.looksLikeOverlay === 'boolean' ? options.looksLikeOverlay : looksLikeOverlay($element),
    looksLikeDetailContent: /(richtextcontent|prod-?detail|detail-content|detailcontent|图文详情|商品详情|规格参数|主要参数)/.test(`${identity} ${loweredText}`),
    isGenericIdentity,
    hasStableIdentity: matchesStableIdentityHint(identity, activeAdapter)
  };
}

function findStableDescendantDescriptor($element, siteAdapter = null) {
  const descendants = $element.find('[id], [data-testid], [aria-label]');
  const maxChecks = Math.min(descendants.length, 120);

  for (let index = 0; index < maxChecks; index += 1) {
    const $descendant = descendants.eq(index);
    const identity = getElementIdentity($descendant);

    if (matchesStableIdentityHint(identity, siteAdapter)) {
      return {
        id: String($descendant.attr('id') || ''),
        dataTestId: String($descendant.attr('data-testid') || ''),
        ariaLabel: String($descendant.attr('aria-label') || ''),
        identity
      };
    }
  }

  for (let index = 0; index < maxChecks; index += 1) {
    const $descendant = descendants.eq(index);
    const normalizedId = normalizeNameCandidate($descendant.attr('id'));
    const identity = getElementIdentity($descendant);
    const dataTestId = normalizeNameCandidate($descendant.attr('data-testid'));
    const ariaLabel = normalizeNameCandidate($descendant.attr('aria-label'));

    if (
      (normalizedId && !isGenericNameToken(normalizedId) && !/^\d+$/.test(normalizedId))
      || (dataTestId && !isGenericNameToken(dataTestId))
      || (ariaLabel && !isGenericNameToken(ariaLabel))
      || matchesStableIdentityHint(identity, siteAdapter)
    ) {
      return {
        id: String($descendant.attr('id') || ''),
        dataTestId: String($descendant.attr('data-testid') || ''),
        ariaLabel: String($descendant.attr('aria-label') || ''),
        identity
      };
    }
  }

  return null;
}

function inferSectionKind($element, siteAdapter = null) {
  return inferSectionKindFromSignals(buildElementRuleSignals($element, null, { siteAdapter }));
}

function looksLikeGenericWrapper($, $element, siteAdapter = null) {
  const identity = getElementIdentity($element);
  const tagName = getElementTagName($element.get(0));
  const stats = getElementStats($, $element);
  const tokenList = identity
    .split(/\s+/)
    .map(normalizeNameCandidate)
    .filter(Boolean);
  const allGeneric = !tokenList.length
    || tokenList.every((token) => isGenericNameToken(token) || /(root|wrapper|container|layout|shell|inner|content)/.test(token));

  return tagName === 'div'
    && stats.childCount >= 1
    && stats.htmlLength >= 1200
    && allGeneric
    && !STRONG_SECTION_KINDS.has(inferSectionKind($element, siteAdapter));
}

function looksLikeLayoutShellContainer($, $element) {
  const tagName = getElementTagName($element.get(0));
  if (!['div', 'section', 'main'].includes(tagName)) {
    return false;
  }

  const identity = getElementIdentity($element);
  const inlineStyle = getInlineStyle($element);
  const directChildren = collectMeaningfulChildren($, $element);
  if (directChildren.length < 2) {
    return false;
  }

  const hasLayoutDisplay = /display\s*:\s*(flex|grid)/.test(inlineStyle)
    || directChildren.some((child) => {
      const $child = $(child);
      return /^(flex|grid)$/.test(String($child.attr('data-restore-layout-parent-display') || '').toLowerCase());
    });
  const hasLayoutIdentity = /(layout|drawer|shell|sider|sidebar|workspace|app)/i.test(identity);

  if (!hasLayoutDisplay && !hasLayoutIdentity) {
    return false;
  }

  const childRoles = directChildren.map((child) => {
    const $child = $(child);
    const childIdentity = getElementIdentity($child);
    const childTagName = getElementTagName(child);
    const hasNavRole = childTagName === 'nav'
      || childTagName === 'aside'
      || /(nav|navigation|drawer|sider|sidebar|side-bar|menu)/i.test(childIdentity)
      || $child.find('nav, aside, [role="navigation"], [role="menu"]').length > 0;
    const hasContentRole = childTagName === 'main'
      || /(content|main|page|body|workspace)/i.test(childIdentity)
      || $child.find('main, [role="main"], table, [role="table"]').length > 0;

    return {
      hasNavRole,
      hasContentRole,
      htmlLength: getElementStats($, $child).htmlLength
    };
  });

  const hasNavChild = childRoles.some((role) => role.hasNavRole && role.htmlLength >= 300);
  const hasContentChild = childRoles.some((role) => role.hasContentRole && role.htmlLength >= 600);

  return hasNavChild && hasContentChild;
}

function isStrongBoundaryCandidate($, $element, siblingCount = 1, siteAdapter = null) {
  const kind = inferSectionKind($element, siteAdapter);
  const stats = getElementStats($, $element);
  const tagName = getElementTagName($element.get(0));

  if (kind === 'floating-layer') {
    return true;
  }

  if (STRONG_SECTION_KINDS.has(kind)) {
    return true;
  }

  if (['header', 'footer', 'main', 'section', 'article', 'aside', 'nav'].includes(tagName) && stats.htmlLength >= 180) {
    return true;
  }

  if (stats.headingCount >= 1 && stats.imageCount >= 1 && stats.htmlLength >= 600) {
    return true;
  }

  if (siblingCount >= 3 && stats.htmlLength >= 1200) {
    return true;
  }

  return false;
}

function dedupeElements(elements = []) {
  const seen = new Set();
  return elements.filter((element) => {
    if (!element || seen.has(element)) {
      return false;
    }

    seen.add(element);
    return true;
  });
}

function collectPromotedChildren($, $element, depth = 0, siteAdapter = null) {
  const directChildren = collectMeaningfulChildren($, $element);
  if (!directChildren.length) {
    return [];
  }

  const elementKind = inferSectionKind($element, siteAdapter);
  const tagName = getElementTagName($element.get(0));
  if (
    elementKind === 'floating-layer'
    || looksLikeOverlay($element)
    || (
      tagName && !['body', 'main'].includes(tagName)
      && /(cookie|modal|dialog|drawer|offcanvas|customizer|style-switcher|popover|tooltip|toast|popup|float|floating)/i.test(getElementIdentity($element))
    )
  ) {
    return [];
  }

  if (
    elementKind === 'top-bar'
    || (
      ['header', 'nav'].includes(tagName)
      && /(top|app|bar|header|navbar|toolbar|banner|navigation)/i.test(getElementIdentity($element))
    )
  ) {
    return [];
  }

  if (looksLikeLayoutShellContainer($, $element)) {
    return [];
  }

  const strongDirectChildren = directChildren.filter((child) => isStrongBoundaryCandidate($, $(child), directChildren.length, siteAdapter));
  if (strongDirectChildren.length >= 2) {
    return strongDirectChildren;
  }

  const nestedStrongChildren = [];
  directChildren.forEach((child) => {
    const $child = $(child);
    if (!looksLikeGenericWrapper($, $child, siteAdapter) && depth > 0) {
      return;
    }

    const grandChildren = collectMeaningfulChildren($, $child);
    const strongGrandChildren = grandChildren.filter((grandChild) => isStrongBoundaryCandidate($, $(grandChild), grandChildren.length, siteAdapter));
    if (strongGrandChildren.length >= 2) {
      nestedStrongChildren.push(...strongGrandChildren);
    }
  });

  if (nestedStrongChildren.length >= 2) {
    return nestedStrongChildren;
  }

  if (looksLikeGenericWrapper($, $element, siteAdapter) && directChildren.length >= 2) {
    return directChildren.filter((child) => getElementStats($, $(child)).htmlLength >= 600);
  }

  return [];
}

function collectSectionElements($, siteAdapter = null) {
  let candidates = collectMeaningfulChildren($, $('body'));

  if (!candidates.length) {
    return [];
  }

  for (let depth = 0; depth < 4; depth += 1) {
    const nextCandidates = [];
    let changed = false;

    candidates.forEach((element) => {
      const $element = $(element);
      if (isFrameworkStructuralRoot($, $element)) {
        const frameworkChildren = collectMeaningfulChildren($, $element);
        if (frameworkChildren.length) {
          nextCandidates.push(...frameworkChildren);
          changed = true;
          return;
        }
      }

      const promotedChildren = collectPromotedChildren($, $element, depth, siteAdapter);

      if (promotedChildren.length >= 2 && (looksLikeGenericWrapper($, $element, siteAdapter) || candidates.length <= 3 || getElementStats($, $element).htmlLength >= 6000)) {
        nextCandidates.push(...promotedChildren);
        changed = true;
        return;
      }

      nextCandidates.push(element);
    });

    candidates = dedupeElements(nextCandidates);
    if (!changed) {
      break;
    }
  }

  return candidates.filter((element) => isMeaningfulElement($, element) && !isFrameworkStructuralRoot($, $(element)));
}

function pickSectionBaseName($element, sectionKind) {
  const rawCandidates = [
    $element.attr('id'),
    $element.attr('data-testid'),
    $element.attr('aria-label'),
    ...String($element.attr('class') || '')
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 8),
    $element.find('h1, h2, h3, h4, [role="heading"]').first().text()
  ];

  const normalizedCandidate = rawCandidates
    .map((value) => normalizeNameCandidate(value))
    .find((value) => value && !isGenericNameToken(value));

  if (normalizedCandidate) {
    if (/-root$/.test(normalizedCandidate) && !/(navigation|cookie|footer|sidebar)/.test(normalizedCandidate)) {
      return sectionKind || normalizedCandidate;
    }

    return normalizedCandidate;
  }

  return sectionKind || 'section';
}

function collectTopLevelMatches($, rootSelector, matchSelector) {
  return $(rootSelector)
    .find(matchSelector)
    .toArray()
    .filter((element) => $(element).parents(matchSelector).length === 0);
}

function collectAnchorTabItems($, $container, siteAdapter = null) {
  const seenLabels = new Set();

  return $container
    .find('div, span, a, button, [role="button"], [tabindex]')
    .toArray()
    .filter((element) => {
      const $element = $(element);
      const label = normalizeCompactText($element.text() || '');
      if (!matchesAnchorTabLabel(label, siteAdapter) || seenLabels.has(label)) {
        return false;
      }

      const nestedMatchCount = $element
        .find('div, span, a, button, [role="button"], [tabindex]')
        .toArray()
        .filter((child) => matchesAnchorTabLabel(normalizeCompactText($(child).text() || ''), siteAdapter))
        .length;
      if (nestedMatchCount > 0) {
        return false;
      }

      seenLabels.add(label);
      return true;
    })
    .slice(0, 5);
}

function collectTabDescriptors($, $root, sectionId, getUniqueInteractionId, siteAdapter = null) {
  const descriptors = [];
  const tabContainers = collectTopLevelMatches($, '#__protorec-interaction-root', TAB_CONTAINER_SELECTOR);

  tabContainers.forEach((containerElement) => {
    const $container = $(containerElement);
    const tabs = $container.find(TAB_SELECTOR)
      .toArray()
      .filter((element) => {
        const $element = $(element);
        if (!$element.text().trim()) {
          return false;
        }

        if ($element.attr('role') === 'tab') {
          const wrapper = $element.closest('.ant-tabs-tab, .el-tabs__item, .hammer-tabs-tab');
          if (wrapper.length && wrapper[0] !== element) {
            return false;
          }
        }

        return true;
      });
    const panels = $container.find(PANEL_SELECTOR)
      .toArray()
      .filter((element) => $(element).parents(PANEL_SELECTOR).length === 0);

    if (tabs.length < 2 || !panels.length) {
      return;
    }

    const interactionId = getUniqueInteractionId(`${sectionId}-tabs`, 'tabs');
    const defaultIndex = Math.max(0, tabs.findIndex((element, index) => {
      const $element = $(element);
      const panel = panels[index];
      const panelStyle = panel ? String($(panel).attr('style') || '') : '';

      return $element.attr('aria-selected') === 'true'
        || /active|selected|current|is-active/.test(String($element.attr('class') || ''))
        || /display\s*:\s*none/.test(panelStyle) === false;
    }));

    $container.attr('data-protorec-interaction-id', interactionId);
    $container.attr('data-protorec-interaction-kind', 'tabs');
    decorateInteractionScopeRoot($container, interactionId, 'local');
    tabs.forEach((element, index) => {
      $(element).attr('data-protorec-tab-index', String(index));
      $(element).attr('data-protorec-interaction-id', interactionId);
      if (index === defaultIndex) {
        $(element).attr('data-protorec-tab-active', 'true');
      }
    });
    panels.forEach((element, index) => {
      $(element).attr('data-protorec-panel-index', String(index));
      $(element).attr('data-protorec-interaction-id', interactionId);
      if (index === defaultIndex) {
        $(element).attr('data-protorec-panel-active', 'true');
      }
    });

    descriptors.push(withDescriptorScopeRoot({
      id: interactionId,
      kind: 'tabs',
      sectionId,
      label: `Tabs (${tabs.length})`,
      confidence: 0.78,
      itemCount: tabs.length,
      defaultIndex
    }, interactionId, 'local'));
  });

  const anchorCandidates = $('#__protorec-interaction-root')
    .find('div, nav, section')
    .toArray()
    .filter((element) => {
      const $container = $(element);
      const compactText = normalizeCompactText($container.text() || '');
      if (!/详情.*参数.*评价/.test(compactText) || compactText.length > 80) {
        return false;
      }

      const items = collectAnchorTabItems($, $container, siteAdapter);
      return items.length >= 2;
    });
  const anchorContainers = anchorCandidates.filter((element) => {
    return !anchorCandidates.some((other) => other !== element && $(element).find(other).length > 0);
  });

  anchorContainers.forEach((containerElement) => {
    const $container = $(containerElement);
    const tabs = collectAnchorTabItems($, $container, siteAdapter);
    if (tabs.length < 2) {
      return;
    }

    const interactionId = getUniqueInteractionId(`${sectionId}-tabs`, 'tabs');
    const defaultIndex = Math.max(0, tabs.findIndex((element) => {
      const $element = $(element);
      return $element.attr('aria-selected') === 'true'
        || /active|selected|current|is-active/.test(String($element.attr('class') || ''));
    }));

    $container.attr('data-protorec-interaction-id', interactionId);
    $container.attr('data-protorec-interaction-kind', 'tabs');
    decorateInteractionScopeRoot($container, interactionId, 'local');
    tabs.forEach((element, index) => {
      $(element).attr('data-protorec-tab-index', String(index));
      $(element).attr('data-protorec-interaction-id', interactionId);
      if (index === defaultIndex) {
        $(element).attr('data-protorec-tab-active', 'true');
      }
    });

    descriptors.push(withDescriptorScopeRoot({
      id: interactionId,
      kind: 'tabs',
      sectionId,
      label: `Tabs (${tabs.length})`,
      confidence: 0.66,
      itemCount: tabs.length,
      defaultIndex
    }, interactionId, 'local'));
  });

  return descriptors;
}

function looksLikeCloseButton($element) {
  const identity = getElementIdentity($element);
  const textContent = normalizeTextSnippet($element.text() || '', 30).toLowerCase();

  return /(close|dismiss|cancel|icon-close|btn-close|modal-close)/.test(identity)
    || ['x', '×'].includes(textContent)
    || !textContent;
}

function normalizeInteractionDescriptorContext(sectionIdOrContext) {
  if (typeof sectionIdOrContext === 'string') {
    return {
      sectionId: sectionIdOrContext,
      interactionIdBase: sectionIdOrContext,
      ownerBlockId: null
    };
  }

  return {
    sectionId: String(sectionIdOrContext?.sectionId || '').trim(),
    interactionIdBase: String(sectionIdOrContext?.interactionIdBase || sectionIdOrContext?.sectionId || '').trim(),
    ownerBlockId: String(sectionIdOrContext?.ownerBlockId || '').trim() || null
  };
}

function withDescriptorOwnership(descriptor, ownerBlockId = null) {
  if (!ownerBlockId) {
    return descriptor;
  }

  return {
    ...descriptor,
    ownerBlockId
  };
}

function withDescriptorProtocolLevel(descriptor, protocolLevel = 'full') {
  if (!protocolLevel || protocolLevel === 'full') {
    return descriptor;
  }

  return {
    ...descriptor,
    protocolLevel
  };
}

function decorateInteractionScopeRoot($scopeRoot, interactionId, interactionMode = 'local') {
  if (!$scopeRoot?.length || !interactionId) {
    return;
  }

  $scopeRoot.attr('data-protorec-interaction-scope-root', interactionId);
  $scopeRoot.attr('data-protorec-interaction-mode', interactionMode);
}

function withDescriptorScopeRoot(descriptor, interactionId, interactionMode = 'local') {
  if (!interactionId) {
    return descriptor;
  }

  return {
    ...descriptor,
    scopeRootId: interactionId,
    scopeRootSelector: `[data-protorec-interaction-scope-root="${interactionId}"]`,
    interactionMode
  };
}

function splitDescriptorsByBlockOwnership(descriptors = [], blocks = []) {
  const blockIds = new Set(
    (Array.isArray(blocks) ? blocks : [])
      .map((block) => String(block?.id || '').trim())
      .filter(Boolean)
  );

  return (Array.isArray(descriptors) ? descriptors : []).reduce((result, descriptor) => {
    const ownerBlockId = String(descriptor?.ownerBlockId || '').trim();
    if (ownerBlockId && blockIds.has(ownerBlockId)) {
      result.blockOwnedDescriptors.push(descriptor);
      return result;
    }

    result.sectionOwnedDescriptors.push(descriptor);
    return result;
  }, {
    sectionOwnedDescriptors: [],
    blockOwnedDescriptors: []
  });
}

function removeDisplayNoneInlineStyle($element) {
  const styleText = String($element.attr('style') || '');
  if (!styleText.trim()) {
    return;
  }

  const cleanedStyleText = styleText
    .split(';')
    .map((entry) => entry.trim())
    .filter(Boolean)
    .filter((declaration) => !/^display\s*:\s*none$/i.test(declaration))
    .join('; ');

  if (cleanedStyleText) {
    $element.attr('style', cleanedStyleText);
    return;
  }

  $element.removeAttr('style');
}

function collectDismissibleDescriptors($, sectionIdOrContext, getUniqueInteractionId) {
  const descriptors = [];
  const descriptorContext = normalizeInteractionDescriptorContext(sectionIdOrContext);
  const layers = collectTopLevelMatches($, '#__protorec-interaction-root', DISMISSIBLE_LAYER_SELECTOR);

  layers.forEach((element) => {
    const $layer = $(element);
    const buttons = $layer.find(DISMISS_BUTTON_SELECTOR)
      .toArray()
      .filter((button) => looksLikeCloseButton($(button)));

    if (!buttons.length) {
      return;
    }

    const interactionId = getUniqueInteractionId(`${descriptorContext.interactionIdBase}-dismiss`, 'dismiss');
    $layer.attr('data-protorec-interaction-id', interactionId);
    $layer.attr('data-protorec-interaction-kind', 'dismissible');
    decorateInteractionScopeRoot($layer, interactionId, 'disabled');
    buttons.slice(0, 4).forEach((button) => {
      $(button).attr('data-protorec-dismiss-trigger', interactionId);
    });

    descriptors.push(withDescriptorOwnership(withDescriptorScopeRoot({
      id: interactionId,
      kind: 'dismissible',
      sectionId: descriptorContext.sectionId,
      label: 'Dismissible Layer',
      confidence: 0.68,
      itemCount: buttons.length
    }, interactionId, 'disabled'), descriptorContext.ownerBlockId));
  });

  return descriptors;
}

function collectCarouselDescriptors($, sectionIdOrContext, getUniqueInteractionId) {
  const descriptors = [];
  const descriptorContext = normalizeInteractionDescriptorContext(sectionIdOrContext);
  const groups = collectTopLevelMatches($, '#__protorec-interaction-root', CAROUSEL_CONTAINER_SELECTOR);

  groups.forEach((element) => {
    const $group = $(element);
    const useSearchPurFeedCanonicalSlides = ENABLE_HISTORICAL_PAGE_REFINEMENTS
      && String(descriptorContext.sectionId || '').trim() === SEARCH_PUR_XY_ROOT_SECTION_ID
      && ($group.is('.hammer-carousel-vertical, .slick-vertical') || $group.find('.hammer-carousel-vertical, .slick-vertical').length > 0);
    const slides = useSearchPurFeedCanonicalSlides
      ? collectSearchPurCanonicalCarouselSlides($, $group)
      : $group.find(CAROUSEL_SLIDE_SELECTOR)
          .toArray()
          .filter((slide) => isMeaningfulElement($, slide));

    if (slides.length < 2) {
      return;
    }

    const interactionId = getUniqueInteractionId(`${descriptorContext.interactionIdBase}-carousel`, 'carousel');
    $group.attr('data-protorec-interaction-id', interactionId);
    $group.attr('data-protorec-interaction-kind', 'carousel');
    decorateInteractionScopeRoot($group, interactionId, 'local');

    slides.forEach((slide, index) => {
      $(slide).attr('data-protorec-slide-index', String(index));
      $(slide).attr('data-protorec-interaction-id', interactionId);
      if (index === 0) {
        $(slide).attr('data-protorec-slide-active', 'true');
      }
    });

    const controls = $group.find(CAROUSEL_CONTROL_SELECTOR).toArray();
    controls.forEach((control, index) => {
      const $control = $(control);
      const identity = getElementIdentity($control);
      $control.attr('data-protorec-interaction-id', interactionId);

      if (/prev|left/.test(identity)) {
        $control.attr('data-protorec-carousel-prev', 'true');
        return;
      }

      if (/next|right/.test(identity)) {
        $control.attr('data-protorec-carousel-next', 'true');
        return;
      }

      $control.attr('data-protorec-slide-target', String(index % slides.length));
    });

    descriptors.push(withDescriptorOwnership(withDescriptorScopeRoot({
      id: interactionId,
      kind: 'carousel',
      sectionId: descriptorContext.sectionId,
      label: `Carousel (${slides.length})`,
      confidence: 0.72,
      itemCount: slides.length
    }, interactionId, 'local'), descriptorContext.ownerBlockId));
  });

  return descriptors;
}

function collectDropdownDescriptors($, sectionIdOrContext, getUniqueInteractionId) {
  const descriptors = [];
  const descriptorContext = normalizeInteractionDescriptorContext(sectionIdOrContext);
  const groups = collectTopLevelMatches($, '#__protorec-interaction-root', DROPDOWN_GROUP_SELECTOR);

  groups.forEach((element) => {
    const $group = $(element);
    const isBasicDownloadCenter = $group.hasClass('hammer-basic-download-center');
    const trigger = isBasicDownloadCenter
      ? $group.find('.hammer-basic-download-center-title').first()
      : ($group.is('[aria-haspopup="true"]')
        ? $group
        : $group.find('button, a, [role="button"], [aria-haspopup="true"]').first());
    const menu = isBasicDownloadCenter
      ? $group.children('div').filter((_, menuElement) => {
        const $menuElement = $(menuElement);
        const styleText = String($menuElement.attr('style') || '');
        return /display\s*:\s*none/i.test(styleText)
          && $menuElement.find('.hammer-basic-download-center-task-table-wrap, .hammer-table-wrapper').length > 0;
      }).first()
      : $group.find(DROPDOWN_MENU_SELECTOR).first();

    if (!trigger.length || !menu.length) {
      return;
    }

    removeDisplayNoneInlineStyle(menu);
    menu.attr('hidden', '');

    const interactionId = getUniqueInteractionId(`${descriptorContext.interactionIdBase}-dropdown`, 'dropdown');
    $group.attr('data-protorec-interaction-id', interactionId);
    $group.attr('data-protorec-interaction-kind', 'dropdown');
    decorateInteractionScopeRoot($group, interactionId, 'local');
    trigger.attr('data-protorec-dropdown-trigger', interactionId);
    menu.attr('data-protorec-dropdown-menu', interactionId);

    descriptors.push(withDescriptorOwnership(withDescriptorScopeRoot({
      id: interactionId,
      kind: 'dropdown',
      sectionId: descriptorContext.sectionId,
      label: isBasicDownloadCenter ? 'Download Center' : 'Dropdown',
      confidence: 0.64,
      itemCount: menu.children().length || 1
    }, interactionId, 'local'), descriptorContext.ownerBlockId));
  });

  return descriptors;
}

function collectBasicDownloadCenterDropdownDescriptors($, sectionIdOrContext, getUniqueInteractionId) {
  const descriptors = [];
  const descriptorContext = normalizeInteractionDescriptorContext(sectionIdOrContext);
  const groups = collectTopLevelMatches($, '#__protorec-interaction-root', '.hammer-basic-download-center');

  groups.forEach((element) => {
    const $group = $(element);
    if (String($group.attr('data-protorec-interaction-kind') || '').trim() === 'dropdown') {
      return;
    }

    const trigger = $group.find('.hammer-basic-download-center-title').first();
    const menu = $group.children('div').filter((_, menuElement) => {
      const $menuElement = $(menuElement);
      const styleText = String($menuElement.attr('style') || '');
      return /display\s*:\s*none/i.test(styleText)
        && $menuElement.find('.hammer-basic-download-center-task-table-wrap, .hammer-table-wrapper').length > 0;
    }).first();

    if (!trigger.length || !menu.length) {
      return;
    }

    removeDisplayNoneInlineStyle(menu);
    menu.attr('hidden', '');

    const interactionId = getUniqueInteractionId(`${descriptorContext.interactionIdBase}-download-center`, 'dropdown');
    $group.attr('data-protorec-interaction-id', interactionId);
    $group.attr('data-protorec-interaction-kind', 'dropdown');
    decorateInteractionScopeRoot($group, interactionId, 'local');
    trigger.attr('data-protorec-dropdown-trigger', interactionId);
    menu.attr('data-protorec-dropdown-menu', interactionId);

    descriptors.push(withDescriptorOwnership(withDescriptorScopeRoot({
      id: interactionId,
      kind: 'dropdown',
      sectionId: descriptorContext.sectionId,
      label: 'Download Center',
      confidence: 0.68,
      itemCount: menu.children().length || 1
    }, interactionId, 'local'), descriptorContext.ownerBlockId));
  });

  return descriptors;
}

function collectSyntheticSelectDropdownDescriptors($, sectionIdOrContext, getUniqueInteractionId) {
  const descriptors = [];
  const descriptorContext = normalizeInteractionDescriptorContext(sectionIdOrContext);
  const groups = $('#__protorec-interaction-root')
    .find('.hammer-select')
    .toArray()
    .filter((element) => $(element).parents('.hammer-select').length === 0);

  groups.forEach((element) => {
    const $group = $(element);
    if (String($group.attr('data-protorec-interaction-kind') || '').trim() === 'dropdown') {
      return;
    }

    const hasRealMenu = $group.find(DROPDOWN_MENU_SELECTOR).length > 0;
    if (hasRealMenu) {
      return;
    }

    const isDisabled = /hammer-select-disabled/.test(String($group.attr('class') || ''))
      || $group.find('input[disabled], button[disabled], [aria-disabled="true"]').length > 0;
    if (isDisabled) {
      return;
    }

    const trigger = $group.find('.hammer-select-selector').first();
    if (!trigger.length) {
      return;
    }

    const labelCandidates = [
      normalizeTextSnippet($group.find('.hammer-select-selection-item').first().text() || '', 80),
      normalizeTextSnippet($group.find('.hammer-select-selection-placeholder').first().text() || '', 80),
      String($group.find('input').first().attr('value') || '').trim(),
      String($group.find('input').first().attr('placeholder') || '').trim()
    ].filter(Boolean);

    if (!labelCandidates.length) {
      return;
    }

    const interactionId = getUniqueInteractionId(`${descriptorContext.interactionIdBase}-synthetic-select`, 'dropdown');
    const syntheticMenu = $('<div class="protorec-synthetic-dropdown-menu" hidden="hidden"></div>');
    labelCandidates.slice(0, 1).forEach((label) => {
      syntheticMenu.append(`<div class="protorec-synthetic-dropdown-item">${escapeHtml(label)}</div>`);
    });

    $group.attr('data-protorec-interaction-id', interactionId);
    $group.attr('data-protorec-interaction-kind', 'dropdown');
    decorateInteractionScopeRoot($group, interactionId, 'local');
    trigger.attr('data-protorec-dropdown-trigger', interactionId);
    syntheticMenu.attr('data-protorec-dropdown-menu', interactionId);
    $group.append(syntheticMenu);

    descriptors.push(withDescriptorProtocolLevel(withDescriptorOwnership(withDescriptorScopeRoot({
      id: interactionId,
      kind: 'dropdown',
      sectionId: descriptorContext.sectionId,
      label: `Select (${labelCandidates[0]})`,
      confidence: 0.52,
      itemCount: 1
    }, interactionId, 'local'), descriptorContext.ownerBlockId), 'fallback'));
  });

  return descriptors;
}

function annotateSectionMarkup(markup, sectionIdOrContext, getUniqueInteractionId, siteAdapter = null) {
  const descriptorContext = normalizeInteractionDescriptorContext(sectionIdOrContext);
  const $ = cheerio.load(`<div id="__protorec-interaction-root">${markup}</div>`, { decodeEntities: false });
  const descriptors = [
    ...collectTabDescriptors($, $('#__protorec-interaction-root'), descriptorContext.interactionIdBase, getUniqueInteractionId, siteAdapter)
      .map((descriptor) => ({
        ...descriptor,
        sectionId: descriptorContext.sectionId,
        ...(descriptorContext.ownerBlockId ? { ownerBlockId: descriptorContext.ownerBlockId } : {})
      })),
    ...collectCarouselDescriptors($, descriptorContext, getUniqueInteractionId),
    ...collectDismissibleDescriptors($, descriptorContext, getUniqueInteractionId),
    ...collectDropdownDescriptors($, descriptorContext, getUniqueInteractionId),
    ...collectBasicDownloadCenterDropdownDescriptors($, descriptorContext, getUniqueInteractionId),
    ...collectSyntheticSelectDropdownDescriptors($, descriptorContext, getUniqueInteractionId)
  ];

  return {
    markup: $('#__protorec-interaction-root').html() || markup,
    descriptors
  };
}

function getSectionShellTag(sectionKind) {
  switch (sectionKind) {
    case 'top-bar':
      return 'header';
    case 'footer':
      return 'footer';
    case 'sidebar':
      return 'aside';
    default:
      return 'section';
  }
}

function resolveSectionRenderMode(sectionKind, stats, interactionCount, blockCount = 0, options = {}) {
  const blockInteractionCount = Number(options.blockInteractionCount || 0);
  if (blockCount >= 2) {
    return 'component-blocks';
  }

  if (stats.htmlLength >= 180000) {
    return 'fallback-body-fragment';
  }

  if (STRONG_SECTION_KINDS.has(sectionKind) || interactionCount > 0 || blockInteractionCount > 0) {
    return 'component-fragment';
  }

  if (sectionKind === 'main-content' && stats.htmlLength >= 80000) {
    return 'fallback-body-fragment';
  }

  return 'component-fragment';
}

function resolveSectionConfidence(sectionKind, stats, interactionCount, blockCount = 0, options = {}) {
  const blockInteractionCount = Number(options.blockInteractionCount || 0);
  const baseline = {
    'top-bar': 0.8,
    sidebar: 0.76,
    footer: 0.82,
    hero: 0.78,
    tabs: 0.78,
    form: 0.74,
    table: 0.74,
    'detail-panel': 0.74,
    notice: 0.78,
    'review-feed': 0.72,
    'product-grid': 0.72,
    'feature-list': 0.72,
    gallery: 0.7,
    'promo-strip': 0.68,
    'content-grid': 0.66,
    'floating-layer': 0.64,
    'main-content': 0.62
  }[sectionKind] || 0.6;

  const headingBoost = stats.headingCount ? 0.03 : 0;
  const interactionBoost = interactionCount ? 0.04 : 0;
  const blockInteractionBoost = !interactionCount && blockInteractionCount > 0 ? 0.04 : 0;
  const blockBoost = blockCount >= 2 ? Math.min(0.08, 0.04 + (blockCount * 0.004)) : 0;
  const oversizePenalty = stats.htmlLength >= 120000 ? 0.1 : stats.htmlLength >= 60000 ? 0.05 : 0;

  return Number(Math.max(0.42, Math.min(0.92, baseline + headingBoost + interactionBoost + blockInteractionBoost + blockBoost - oversizePenalty)).toFixed(2));
}

function buildSectionSummary($element, sectionKind, stats) {
  const headingText = normalizeTextSnippet($element.find('h1, h2, h3, h4, [role="heading"]').first().text() || '', 80);
  const summary = headingText || stats.textSnippet || getSectionTitle(sectionKind);
  return summary || getSectionTitle(sectionKind);
}

function getBlockTitle(blockKind) {
  return {
    'top-bar': 'Top Bar',
    'hero-media': 'Hero Media',
    'product-detail-hero': 'Product Detail Hero',
    'promo-banner': 'Promo Banner',
    'icon-grid': 'Icon Grid',
    'featured-shelf': 'Featured Shelf',
    'product-shelf': 'Product Shelf',
    'recommend-shelf': 'Recommend Shelf',
    'detail-anchor-bar': 'Detail Anchor Bar',
    'detail-content': 'Detail Content',
    'spec-list': 'Spec List',
    'legal-notice': 'Legal Notice',
    'review-feed': 'Review Feed',
    'service-strip': 'Service Strip',
    footer: 'Footer',
    'floating-layer': 'Floating Layer',
    'media-cluster': 'Media Cluster',
    'content-block': 'Content Block'
  }[blockKind] || 'Content Block';
}

function hasStableBlockIdentity($element, siteAdapter = null) {
  const descendant = findStableDescendantDescriptor($element, siteAdapter);
  const id = normalizeNameCandidate($element.attr('id') || descendant?.id);
  const identity = [getElementIdentity($element), descendant?.identity || ''].join(' ').trim();

  if (id && !isGenericNameToken(id)) {
    return true;
  }

  if (matchesStableIdentityHint(identity, siteAdapter)) {
    return true;
  }

  return inferBlockKindFromSignals(buildElementRuleSignals($element, null, {
    descendantId: descendant?.id,
    siteAdapter
  })) !== 'content-block';
}

function inferBlockKind($element, siteAdapter = null) {
  const descendant = findStableDescendantDescriptor($element, siteAdapter);
  const stats = {
    childCount: $element.children().length,
    imageCount: $element.find('img, picture, svg, canvas, video').length,
    inputCount: $element.find('input, select, textarea, [role="textbox"], [contenteditable="true"]').length,
    htmlLength: String($element.toString?.() || '').trim().length
  };
  return inferBlockKindFromSignals(buildElementRuleSignals($element, stats, {
    descendantId: descendant?.id,
    siteAdapter
  }));
}

function isStrongBlockCandidate($, $element, siblingCount = 1, siteAdapter = null) {
  const blockKind = inferBlockKind($element, siteAdapter);
  const stats = getElementStats($, $element);

  const looksLikeRepeatedVisualCell = (
    blockKind === 'content-block'
    && !hasStableBlockIdentity($element, siteAdapter)
    && Number(stats.textLength || 0) === 0
    && Number(stats.headingCount || 0) === 0
    && Number(stats.inputCount || 0) === 0
    && Number(stats.childCount || 0) <= 1
    && Number(stats.imageCount || 0) >= 2
    && Number(stats.htmlLength || 0) < 2200
  );

  if (looksLikeRepeatedVisualCell) {
    return false;
  }

  if (['top-bar', 'hero-media', 'product-detail-hero', 'promo-banner', 'icon-grid', 'featured-shelf', 'product-shelf', 'recommend-shelf', 'detail-anchor-bar', 'detail-content', 'spec-list', 'legal-notice', 'review-feed', 'service-strip', 'footer', 'floating-layer'].includes(blockKind)) {
    return true;
  }

  if (hasStableBlockIdentity($element, siteAdapter) && stats.htmlLength >= 900) {
    return true;
  }

  if (stats.imageCount >= 2 && stats.htmlLength >= 1400) {
    return true;
  }

  if (siblingCount >= 4 && stats.htmlLength >= 1800) {
    return true;
  }

  return false;
}

function pickDominantChild($, children = []) {
  return children.reduce((largest, child) => {
    if (!largest) {
      return child;
    }

    const childLength = getElementStats($, $(child)).htmlLength;
    const currentLargestLength = getElementStats($, $(largest)).htmlLength;
    return childLength > currentLargestLength ? child : largest;
  }, null);
}

function descendToBlockContainer($, $root, siteAdapter = null) {
  let $current = $root;

  for (let depth = 0; depth < 8; depth += 1) {
    const currentStats = getElementStats($, $current);
    const directChildren = collectMeaningfulChildren($, $current);

    if (!directChildren.length) {
      break;
    }

    const strongDirectChildren = directChildren.filter((child) => isStrongBlockCandidate($, $(child), directChildren.length, siteAdapter));
    if (strongDirectChildren.length >= 2) {
      return {
        $container: $current,
        candidateChildren: strongDirectChildren
      };
    }

    if (directChildren.length === 1 && (looksLikeGenericWrapper($, $current, siteAdapter) || isFrameworkStructuralRoot($, $current) || currentStats.htmlLength >= 3000)) {
      $current = $(directChildren[0]);
      continue;
    }

    const dominantChild = pickDominantChild($, directChildren);
    if (dominantChild && (looksLikeGenericWrapper($, $current, siteAdapter) || isFrameworkStructuralRoot($, $current))) {
      const dominantStats = getElementStats($, $(dominantChild));
      const dominantRatio = dominantStats.htmlLength / Math.max(currentStats.htmlLength, 1);
      if (dominantRatio >= 0.82) {
        $current = $(dominantChild);
        continue;
      }
    }

    return {
      $container: $current,
      candidateChildren: directChildren
    };
  }

  return {
    $container: $current,
    candidateChildren: collectMeaningfulChildren($, $current)
  };
}

function shouldExtractSectionBlocks(sectionKind, stats) {
  if (['top-bar', 'header', 'sidebar'].includes(String(sectionKind || '').trim())) {
    return false;
  }

  return stats.htmlLength >= 18000
    || (BLOCKABLE_SECTION_KINDS.has(sectionKind) && stats.htmlLength >= 12000)
    || (stats.childCount >= 8 && stats.htmlLength >= 8000);
}

function pickBlockBaseName($element, blockKind, siteAdapter = null) {
  const descendant = findStableDescendantDescriptor($element, siteAdapter);
  const normalizedId = normalizeNameCandidate($element.attr('id') || descendant?.id);
  const rawCandidates = [
    descendant?.dataTestId,
    descendant?.ariaLabel,
    $element.attr('data-testid'),
    $element.attr('aria-label'),
    ...String($element.attr('class') || '')
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 6),
    $element.find('h1, h2, h3, h4, [role="heading"]').first().text()
  ];

  if (/^navigation-layout/.test(normalizedId) || /^navigationlayout/.test(normalizedId)) {
    return 'top-bar';
  }

  if (/^icon-grid-\d+/.test(normalizedId) || /^icongrid-\d+/.test(normalizedId)) {
    return 'icon-grid';
  }

  if (/^picture-whole-\d+/.test(normalizedId) || /^prod-\d+/.test(normalizedId)) {
    return blockKind;
  }

  if (normalizedId && !isGenericNameToken(normalizedId) && !/\d{5,}/.test(normalizedId)) {
    return normalizedId;
  }

  const normalizedCandidate = rawCandidates
    .map((value) => normalizeNameCandidate(value))
    .find((value) => value
      && !isGenericNameToken(value)
      && !/\d{5,}/.test(value)
      && !/^(css|r)-[a-z0-9-]+$/.test(value));

  return normalizedCandidate || blockKind || 'content-block';
}

function buildBlockSummary($element, blockKind, stats) {
  const headingText = normalizeTextSnippet($element.find('h1, h2, h3, h4, [role="heading"]').first().text() || '', 80);
  return headingText || stats.textSnippet || getBlockTitle(blockKind);
}

function resolveBlockConfidence(blockKind, stats, interactionCount) {
  const baseline = {
    'top-bar': 0.84,
    'hero-media': 0.8,
    'product-detail-hero': 0.82,
    'promo-banner': 0.76,
    'icon-grid': 0.8,
    'featured-shelf': 0.8,
    'product-shelf': 0.78,
    'recommend-shelf': 0.8,
    'detail-anchor-bar': 0.74,
    'detail-content': 0.76,
    'spec-list': 0.78,
    'legal-notice': 0.8,
    'review-feed': 0.76,
    'service-strip': 0.78,
    footer: 0.82,
    'floating-layer': 0.72,
    'media-cluster': 0.72,
    'content-block': 0.68
  }[blockKind] || 0.66;

  const interactionBoost = interactionCount ? 0.04 : 0;
  const oversizePenalty = stats.htmlLength >= 90000 ? 0.08 : stats.htmlLength >= 50000 ? 0.04 : 0;

  return Number(Math.max(0.48, Math.min(0.94, baseline + interactionBoost - oversizePenalty)).toFixed(2));
}

function resolvePromotedSectionKind(blockKind = 'content-block') {
  return {
    'top-bar': 'top-bar',
    'hero-media': 'hero',
    'product-detail-hero': 'detail-panel',
    'promo-banner': 'promo-strip',
    'icon-grid': 'feature-list',
    'featured-shelf': 'product-grid',
    'product-shelf': 'product-grid',
    'recommend-shelf': 'product-grid',
    'detail-anchor-bar': 'tabs',
    'detail-content': 'detail-panel',
    'spec-list': 'detail-panel',
    'legal-notice': 'notice',
    'review-feed': 'review-feed',
    'service-strip': 'feature-list',
    footer: 'footer',
    'floating-layer': 'floating-layer',
    'media-cluster': 'gallery',
    'content-block': 'main-content'
  }[blockKind] || 'main-content';
}

function shouldPromoteBlocksToSections(sectionKind, stats, blocks = []) {
  if (!Array.isArray(blocks) || blocks.length < 4) {
    return false;
  }

  const promotableBlocks = blocks.filter((block) => BLOCK_SECTION_PROMOTION_KINDS.has(block.kind));
  const distinctKinds = new Set(promotableBlocks.map((block) => block.kind));
  const hasMixedStructuralKinds = distinctKinds.has('top-bar')
    || distinctKinds.has('footer')
    || distinctKinds.has('hero-media')
    || distinctKinds.has('promo-banner')
    || distinctKinds.has('product-detail-hero')
    || distinctKinds.has('detail-anchor-bar')
    || distinctKinds.has('review-feed');

  if (Number(stats?.htmlLength || 0) >= 160000 && promotableBlocks.length >= 4) {
    return true;
  }

  return ['main-content', 'product-grid', 'content-grid'].includes(sectionKind)
    && promotableBlocks.length >= 4
    && distinctKinds.size >= 3
    && hasMixedStructuralKinds;
}

function isPromotedBlockSection(section = {}) {
  return section?.diagnostics?.extraction?.reason === 'promoted-from-section-block';
}

function getBlockSourceIdentityText(block = {}) {
  const selectorHint = String(block?.diagnostics?.source?.selectorHint || '').trim().toLowerCase();
  const className = String(block?.diagnostics?.source?.className || '').trim().toLowerCase();
  return [selectorHint, className].filter(Boolean).join(' ');
}

function isSupplierEntryLikeHammerLayoutBlock(block = {}) {
  const markup = String(block?.markup || '').trim();
  if (!markup || Number(block?.stats?.htmlLength || 0) < 50000) {
    return false;
  }

  const sourceText = getBlockSourceIdentityText(block);
  if (!/hammer-pro-layout-sub|hammer-layout/.test(sourceText)) {
    return false;
  }

  const $layout = cheerio.load(`<div id="__protorec-hammer-layout-root">${markup}</div>`, { decodeEntities: false });
  let $layoutRoot = $layout('#__protorec-hammer-layout-root').children().first();
  if (!$layoutRoot.length) {
    $layoutRoot = $layout('#__protorec-hammer-layout-root');
  }

  const parts = collectSupplierEntryHammerLayoutParts($layout, $layoutRoot);
  if (!parts) {
    return false;
  }

  const coverage = collectSupplierEntryCoverageMetrics({
    menuMarkup: parts.menuMarkup,
    queryMarkup: parts.queryMarkup,
    tableMarkup: parts.tableMarkup,
    paginationMarkup: parts.paginationMarkup,
    originalMarkup: markup
  });

  return coverage.htmlCoverage >= 0.9 && coverage.meaningfulCoverage >= 0.85;
}

function shouldRejectTabsLikeGenericBlockSplit(sectionKind, containerStats = {}, blocks = []) {
  if (!['tabs', 'form'].includes(String(sectionKind || '').trim())) {
    return false;
  }

  if (!Array.isArray(blocks) || blocks.length < 2) {
    return false;
  }

  if (blocks.some((block) => isSupplierEntryLikeHammerLayoutBlock(block))) {
    return false;
  }

  const totalHtmlLength = Math.max(Number(containerStats?.htmlLength || 0), 1);
  const genericBlocks = blocks.filter((block) => String(block?.kind || '').trim() === 'content-block');
  if (!genericBlocks.length) {
    return false;
  }

  const structuredBlocks = blocks.filter((block) => String(block?.kind || '').trim() !== 'content-block');
  const genericCoverage = genericBlocks.reduce((sum, block) => (
    sum + Number(block?.stats?.htmlLength || 0)
  ), 0) / totalHtmlLength;
  const dominantGenericRatio = genericBlocks.reduce((maxRatio, block) => {
    const ratio = Number(block?.stats?.htmlLength || 0) / totalHtmlLength;
    return ratio > maxRatio ? ratio : maxRatio;
  }, 0);
  const interactiveGenericBlockCount = genericBlocks.filter((block) => (
    Array.isArray(block?.interactionIds) && block.interactionIds.length > 0
  )).length;

  if (genericBlocks.length >= 8 && structuredBlocks.length <= 1) {
    return true;
  }

  return blocks.length <= 3
    && genericBlocks.length >= blocks.length - 1
    && interactiveGenericBlockCount >= 1
    && Number(containerStats?.htmlLength || 0) >= 60000
    && dominantGenericRatio >= 0.62
    && genericCoverage >= 0.68;
}

function createPromotedSectionsFromBlocks({
  section,
  blocks,
  siteAdapter = null,
  explicitLocalMap,
  explicitPreviewMap,
  byFileName,
  getUniqueSectionId
}) {
  return blocks.map((block) => {
    const promotedKind = resolvePromotedSectionKind(block.kind);
    const sectionBaseName = block.id || promotedKind || 'section';
    const sectionId = getUniqueSectionId(sectionBaseName, promotedKind || 'section');
    const componentName = `${getSectionComponentName(sectionId)}Section`;
    const $fragment = cheerio.load(`<div id="__protorec-promoted-root">${block.markup}</div>`, { decodeEntities: false });
    let $element = $fragment('#__protorec-promoted-root').children().first();

    if (!$element.length) {
      $element = $fragment('#__protorec-promoted-root');
    }

    const stats = getElementStats($fragment, $element);
    const interactionCount = Array.isArray(block.interactionIds) ? block.interactionIds.length : 0;
    const confidence = resolveSectionConfidence(promotedKind, stats, interactionCount, 0);
    const renderMode = resolveSectionRenderMode(promotedKind, stats, interactionCount, 0);
    const extraction = {
      eligible: true,
      attempted: true,
      status: 'promoted',
      reason: 'promoted-from-section-block',
      parentSectionId: section.id,
      parentSectionKind: section.kind,
      parentComponentName: section.componentName,
      sourceBlockId: block.id,
      sourceBlockKind: block.kind,
      sourceBlockConfidence: Number(block.confidence || 0),
      sourceSelectorHint: block?.diagnostics?.source?.selectorHint || '',
      sourceMatchedRules: block?.diagnostics?.classification?.matchedRules || [],
      sourceHtmlLength: Number(block?.stats?.htmlLength || 0)
    };

    return {
      id: sectionId,
      title: block.title,
      kind: promotedKind,
      confidence,
      summary: block.summary,
      renderMode,
      shellTag: getSectionShellTag(promotedKind),
      markup: stripProtoAttributes(rewriteMarkupAssets(block.markup, explicitLocalMap, byFileName)),
      previewMarkup: stripProtoAttributes(rewriteMarkupAssets(block.previewMarkup || block.markup, explicitPreviewMap, byFileName)),
      blocks: [],
      componentName,
      fileName: `${componentName}.tsx`,
      interactionIds: Array.isArray(block.interactionIds) ? block.interactionIds : [],
      contextWrappers: Array.isArray(block.contextWrappers) ? block.contextWrappers : [],
      diagnostics: createSectionDiagnostics({
        $element,
        sectionId,
        sectionBaseName,
        sectionKind: promotedKind,
        stats,
        renderMode,
        confidence,
        interactionCount,
        blockCount: 0,
        componentName,
        siteAdapter,
        extraction,
        contextWrappers: Array.isArray(block.contextWrappers) ? block.contextWrappers : []
      }),
      stats: {
        htmlLength: stats.htmlLength,
        childCount: stats.childCount,
        imageCount: stats.imageCount,
        blockCount: 0
      }
    };
  });
}

function isAcceptedBlockCandidate($, child, siblingCount = 1, siteAdapter = null) {
  const $child = $(child);
  const childStats = getElementStats($, $child);

  if (isLikelySpacer($, $child, childStats)) {
    return false;
  }

  return isStrongBlockCandidate($, $child, siblingCount, siteAdapter)
    || hasStableBlockIdentity($child, siteAdapter)
    || (
      childStats.htmlLength >= 4200
      && (
        childStats.headingCount >= 1
        || childStats.imageCount >= 2
        || childStats.childCount >= 4
      )
    );
}

function filterAcceptedBlockCandidates($, candidateChildren = [], siteAdapter = null) {
  return dedupeElements(candidateChildren.filter((child) => {
    return isAcceptedBlockCandidate($, child, candidateChildren.length, siteAdapter);
  }));
}

function findNestedBlockContainer($, $root, minAcceptedCount = 2, siteAdapter = null) {
  const rootStats = getElementStats($, $root);
  let bestMatch = null;

  $root.find('div, section, article, nav, main, aside').each((_, element) => {
    const $candidate = $(element);
    const candidateStats = getElementStats($, $candidate);
    if (candidateStats.htmlLength < 2400 || candidateStats.htmlLength >= rootStats.htmlLength * 0.995) {
      return;
    }

    const candidateChildren = collectMeaningfulChildren($, $candidate);
    if (candidateChildren.length < minAcceptedCount) {
      return;
    }

    const acceptedCandidates = filterAcceptedBlockCandidates($, candidateChildren, siteAdapter);
    if (acceptedCandidates.length < minAcceptedCount) {
      return;
    }

    const totalAcceptedHtml = acceptedCandidates.reduce((total, child) => {
      return total + getElementStats($, $(child)).htmlLength;
    }, 0);
    const htmlCoverage = totalAcceptedHtml / Math.max(candidateStats.htmlLength, 1);
    if (acceptedCandidates.length < 3 && htmlCoverage < 0.35) {
      return;
    }

    const stableIdentityCount = acceptedCandidates.filter((child) => {
      const $child = $(child);
      return hasStableBlockIdentity($child, siteAdapter) || normalizeNameCandidate($child.attr('id'));
    }).length;
    const distinctKinds = new Set(acceptedCandidates.map((child) => inferBlockKind($(child), siteAdapter))).size;
    const averageChildHtml = totalAcceptedHtml / Math.max(acceptedCandidates.length, 1);
    if (acceptedCandidates.length >= 8 && averageChildHtml < 2500 && distinctKinds <= 2) {
      return;
    }
    if (acceptedCandidates.length >= 8 && averageChildHtml < 2500 && stableIdentityCount < 2) {
      return;
    }

    const score = (acceptedCandidates.length * 100)
      + (stableIdentityCount * 160)
      + (distinctKinds * 15)
      + Math.round(htmlCoverage * 20)
      + (candidateChildren.length >= 4 ? 10 : 0)
      + Math.round(Math.min(80, averageChildHtml / 1200));

    if (!bestMatch || score > bestMatch.score || (score === bestMatch.score && candidateStats.htmlLength > bestMatch.containerStats.htmlLength)) {
      bestMatch = {
        $container: $candidate,
        candidateChildren,
        acceptedCandidates,
        containerStats: candidateStats,
        htmlCoverage: Number(htmlCoverage.toFixed(4)),
        score
      };
    }
  });

  return bestMatch;
}

function analyzeAcceptedBlockCandidates($, blockElements = [], containerStats = {}, siteAdapter = null) {
  const stableIdentityCount = blockElements.filter((child) => hasStableBlockIdentity($(child), siteAdapter)).length;
  const structuredKindCount = blockElements.filter((child) => inferBlockKind($(child), siteAdapter) !== 'content-block').length;
  const largestBlockHtml = blockElements.reduce((largest, child) => {
    return Math.max(largest, getElementStats($, $(child)).htmlLength);
  }, 0);
  const dominantBlockRatio = largestBlockHtml / Math.max(Number(containerStats?.htmlLength) || 1, 1);

  return {
    stableIdentityCount,
    structuredKindCount,
    largestBlockHtml,
    dominantBlockRatio
  };
}

function shouldRetryNestedBlockSearch(blockSummary = {}, containerStats = {}) {
  return Number(containerStats?.htmlLength || 0) >= 45000
    && Number(blockSummary?.dominantBlockRatio || 0) >= 0.82
    && Number(blockSummary?.structuredKindCount || 0) < 2
    && Number(blockSummary?.stableIdentityCount || 0) < 2;
}

function shouldUseNestedBlockContainer(currentSummary = {}, nestedSummary = {}, currentBlocks = [], nestedBlocks = [], nestedCoverage = 0) {
  if (!nestedBlocks.length) {
    return false;
  }

  if (nestedBlocks.length > currentBlocks.length) {
    return true;
  }

  if (nestedBlocks.length >= 3 && Number(nestedCoverage || 0) >= 0.55) {
    return true;
  }

  if (Number(nestedSummary?.structuredKindCount || 0) > Number(currentSummary?.structuredKindCount || 0)) {
    return true;
  }

  return Number(nestedSummary?.stableIdentityCount || 0) > Number(currentSummary?.stableIdentityCount || 0)
    && Number(nestedCoverage || 0) >= 0.55;
}

function collectHammerWorkbenchShellMetrics($, $container, containerStats = null) {
  if (!$container?.length) {
    return null;
  }

  const directChildren = $container.children().toArray();
  if (directChildren.length < 2) {
    return null;
  }

  let $header = null;
  let $subLayout = null;

  directChildren.forEach((child) => {
    const $child = $(child);
    const className = String($child.attr('class') || '');

    if (!$header && /\bhammer-pro-layout-header\b/.test(className)) {
      $header = $child;
    }

    if (!$subLayout && /\bhammer-pro-layout-sub\b/.test(className)) {
      $subLayout = $child;
    }
  });

  let $aside = null;
  let $main = null;
  let shellLevel = '';

  if ($header?.length && $subLayout?.length) {
    $aside = $subLayout.children('aside.hammer-pro-layout-sider').first();
    $main = $subLayout.children('main.hammer-layout-content, main.hammer-pro-layout-main').first();
    shellLevel = 'header-sub-layout';
  } else {
    $aside = $container.children('aside.hammer-pro-layout-sider').first();
    $main = $container.children('main.hammer-layout-content, main.hammer-pro-layout-main').first();
    shellLevel = 'aside-main-layout';
  }

  if (!$aside?.length || !$main?.length) {
    return null;
  }

  const resolvedContainerStats = containerStats || getElementStats($, $container);
  const containerHtmlLength = Math.max(Number(resolvedContainerStats?.htmlLength || 0), 1);
  const headerHtmlLength = Number($header?.length ? getElementStats($, $header).htmlLength : 0);
  const asideHtmlLength = Number(getElementStats($, $aside).htmlLength || 0);
  const mainHtmlLength = Number(getElementStats($, $main).htmlLength || 0);
  const chromeHtmlLength = headerHtmlLength + asideHtmlLength;

  return {
    shellLevel,
    containerHtmlLength,
    chromeHtmlLength,
    chromeHtmlCoverage: Number((chromeHtmlLength / containerHtmlLength).toFixed(4)),
    headerHtmlLength,
    asideHtmlLength,
    mainHtmlLength
  };
}

function collectHammerWorkbenchShellMetricsFromRoot($, $root, maxDepth = 6) {
  let $current = $root;

  for (let depth = 0; depth < maxDepth && $current?.length; depth += 1) {
    const shellMetrics = collectHammerWorkbenchShellMetrics($, $current);
    if (shellMetrics) {
      return shellMetrics;
    }

    const directChildren = $current.children().toArray();
    if (directChildren.length !== 1) {
      break;
    }

    $current = $(directChildren[0]);
  }

  return null;
}

function shouldPreferCurrentHammerWorkbenchShell({
  $,
  $root,
  $currentContainer,
  currentContainerStats = null,
  currentBlocks = [],
  nestedContainer = null,
  sectionStats = null,
  siteAdapter = null
}) {
  if (!$currentContainer?.length || !nestedContainer?.$container?.length) {
    return false;
  }

  const currentShellMetrics = collectHammerWorkbenchShellMetrics($, $currentContainer, currentContainerStats);
  if (!currentShellMetrics) {
    return false;
  }

  if (Number(sectionStats?.htmlLength || 0) > 160000) {
    return false;
  }

  if (Number(currentShellMetrics.chromeHtmlCoverage || 0) < 0.18) {
    return false;
  }

  if (!Array.isArray(currentBlocks) || currentBlocks.length < 2) {
    return false;
  }

  const currentBlockKinds = currentBlocks.map((child) => inferBlockKind($(child), siteAdapter));
  if (!currentBlockKinds.includes('top-bar')) {
    return false;
  }

  const nestedShellMetrics = collectHammerWorkbenchShellMetrics($, nestedContainer.$container, nestedContainer.containerStats);
  if (nestedShellMetrics) {
    return false;
  }

  const nestedCoverage = collectNestedContainerCoverageMetrics($, $root, nestedContainer.$container, sectionStats);
  return Number(nestedCoverage.rootHtmlCoverage || 0) < 0.78
    && Number(nestedCoverage.meaningfulCoverage || 0) < 0.82;
}

function shouldExpandDominantBlockCandidate({
  blockElements = [],
  combinedCandidates = [],
  currentSummary = {},
  combinedCoverage = 0,
  currentCoverage = 0,
  currentDistinctKinds = 0,
  combinedDistinctKinds = 0
}) {
  if (!combinedCandidates.length) {
    return false;
  }

  if (combinedCandidates.length > blockElements.length) {
    if (Number(combinedCoverage || 0) < 0.7) {
      return false;
    }

    if (Number(currentCoverage || 0) > 0 && Number(combinedCoverage || 0) < (Number(currentCoverage || 0) - 0.2)) {
      return false;
    }

    return true;
  }

  if (combinedCandidates.length < 3 || Number(combinedCoverage || 0) < 0.55) {
    return false;
  }

  if (combinedDistinctKinds > currentDistinctKinds) {
    return true;
  }

  return Number(currentSummary?.dominantBlockRatio || 0) >= 0.88;
}

function buildMarkupFromNodes($, nodes = []) {
  return nodes
    .map((node) => $.html($(node)) || '')
    .filter((value) => String(value || '').trim())
    .join('');
}

function countMeaningfulDescendants($, $root) {
  let count = 0;
  $root.find('*').each((_, element) => {
    if (isMeaningfulElement($, element) && !isLikelySpacer($, $(element))) {
      count += 1;
    }
  });
  return count;
}

function countMeaningfulDescendantsForMarkup(markup = '') {
  const $ = cheerio.load(`<div id="__protorec-meaningful-root">${markup}</div>`, { decodeEntities: false });
  const $root = $('#__protorec-meaningful-root');
  return countMeaningfulDescendants($, $root);
}

function collectNestedContainerCoverageMetrics($, $root, $container, sectionStats = {}) {
  if (!$container?.length) {
    return {
      rootHtmlCoverage: 0,
      meaningfulCoverage: 0
    };
  }

  const sectionHtmlLength = Math.max(Number(sectionStats?.htmlLength || 0), 1);
  const containerStats = getElementStats($, $container);
  const rootMeaningfulCount = Math.max(countMeaningfulDescendants($, $root), 1);
  const containerMeaningfulCount = countMeaningfulDescendants($, $container);

  return {
    rootHtmlCoverage: Number((Number(containerStats?.htmlLength || 0) / sectionHtmlLength).toFixed(4)),
    meaningfulCoverage: Number((containerMeaningfulCount / rootMeaningfulCount).toFixed(4))
  };
}

function shouldRejectNestedContainerForUndercoverage(coverage = {}, options = {}) {
  const rootHtmlCoverage = Number(coverage?.rootHtmlCoverage || 0);
  const meaningfulCoverage = Number(coverage?.meaningfulCoverage || 0);
  const acceptedCandidateCount = Number(options?.acceptedCandidateCount || 0);
  const sectionKind = String(options?.sectionKind || '').trim();

  if (rootHtmlCoverage < 0.25 && meaningfulCoverage < 0.4) {
    return true;
  }

  if (
    ['tabs', 'form'].includes(sectionKind)
    && acceptedCandidateCount >= 8
    && meaningfulCoverage < 0.45
  ) {
    return true;
  }

  return acceptedCandidateCount >= 12 && meaningfulCoverage < 0.3;
}

function isSearchPurProfileSplitCandidate(sectionId, block) {
  return String(sectionId || '').trim() === 'root-supplier-sources-web'
    && String(block?.id || '').trim() === 'profile'
    && Array.isArray(block?.interactionIds)
    && block.interactionIds.length === 2
    && Number(block?.stats?.htmlLength || 0) >= 180000;
}

function collectProfileSplitParts($, $profileRoot) {
  const $leftColumn = $profileRoot.children().first();
  const $rightColumn = $profileRoot.children().eq(1);
  if (!$leftColumn.length || !$rightColumn.length) {
    return null;
  }

  const $leftContent = $leftColumn.children().first().length ? $leftColumn.children().first() : $leftColumn;
  const leftChildren = $leftContent.children().toArray();
  if (leftChildren.length < 4) {
    return null;
  }

  const headerMarkup = buildMarkupFromNodes($, leftChildren.slice(0, 2));
  const resultsMarkup = buildMarkupFromNodes($, leftChildren.slice(2));
  const carouselShellMarkup = $.html($rightColumn) || '';

  if (!headerMarkup.trim() || !resultsMarkup.trim() || !carouselShellMarkup.trim()) {
    return null;
  }

  const rightHasVerticalCarousel = $rightColumn.find('.hammer-carousel-vertical, .slick-vertical').length > 0;
  const rightHasHorizontalCarousel = $rightColumn.find('.hammer-carousel').length > 0 && $rightColumn.find('.hammer-carousel-vertical').length < $rightColumn.find('.hammer-carousel').length;
  if (!rightHasVerticalCarousel || !rightHasHorizontalCarousel) {
    return null;
  }

  return {
    headerMarkup,
    resultsMarkup,
    carouselShellMarkup,
    hints: {
      rightColumnClassName: String($rightColumn.attr('class') || ''),
      rightHasVerticalCarousel,
      rightHasHorizontalCarousel
    }
  };
}

function buildDerivedBlock({
  $ctx,
  $element,
  sectionId,
  blockId,
  markup,
  previewMarkup,
  blockKind = 'content-block',
  interactionDescriptors = [],
  siteAdapter = null,
  derivedFromBlockId = '',
  componentName,
  fileName,
  extractionSource = 'second-pass-refinement',
  extractionStrategy = 'generic-second-pass-split'
}) {
  const blockStats = getElementStats($ctx, $element);
  const confidence = resolveBlockConfidence(blockKind, blockStats, interactionDescriptors.length);
  const diagnostics = createBlockDiagnostics({
    $element,
    sectionId,
    blockId,
    blockKind,
    componentName,
    fileName,
    blockStats,
    confidence,
    interactionCount: interactionDescriptors.length,
    siteAdapter,
    extraction: {
      status: 'success',
      source: extractionSource,
      strategy: extractionStrategy,
      derivedFromBlockId
    },
    contextWrappers: []
  });

  diagnostics.derivedFromBlockId = derivedFromBlockId;
  diagnostics.extraction = {
    ...(diagnostics.extraction || {}),
    source: extractionSource,
    strategy: extractionStrategy,
    derivedFromBlockId
  };

  return {
    id: blockId,
    sectionId,
    title: getBlockTitle(blockKind),
    kind: blockKind,
    summary: buildBlockSummary($element, blockKind, blockStats),
    confidence,
    renderMode: 'component-fragment',
    componentName,
    fileName,
    markup: stripProtoAttributes(markup),
    previewMarkup: stripProtoAttributes(previewMarkup || markup),
    interactionIds: interactionDescriptors.map((descriptor) => descriptor.id),
    contextWrappers: [],
    stats: {
      htmlLength: blockStats.htmlLength,
      childCount: blockStats.childCount,
      imageCount: blockStats.imageCount
    },
    diagnostics,
    derivedFromBlockId
  };
}

const SEARCH_PUR_XY_ROOT_SECTION_ID = 'root-supplier-sources-web';
const SEARCH_PUR_RESULTS_MOUNT_SELECTOR = 'tbody[data-protorec-results-body-root]';
const SEARCH_PUR_CAROUSEL_SHELL_MOUNT_SELECTOR = '[data-protorec-carousel-shell-root]';
const SEARCH_PUR_CAROUSEL_FEED_MOUNT_SELECTOR = '[data-protorec-carousel-feed-root]';
const SEARCH_PUR_FEED_GROUP_SIZE = 32;
const SEARCH_PUR_SUBTREE_STATUSES = new Set(['complete', 'fallback', 'failed']);
const SEARCH_PUR_FALLBACK_REASONS = new Set([
  'none',
  'missing-required-block',
  'duplicate-singleton-block',
  'missing-mount-selector',
  'multiple-mount-selectors',
  'missing-composition',
  'missing-rendered-html',
  'invalid-composition-html',
  'import-error',
  'mount-validation-failed',
  'refinement-reverted'
]);
const SEARCH_PUR_BIAS_SKIPPED_REASONS = new Set([
  'none',
  'subtree-not-complete',
  'root-still-owns-interactions',
  'legacy-profile-results-present',
  'legacy-carousel-shell-semantics-present',
  'owner-block-missing',
  'owner-interaction-mismatch',
  'root-prebias-still-high-structural',
  'root-prebias-not-high'
]);

function normalizeSearchPurSubtreeStatus(status = 'failed') {
  return SEARCH_PUR_SUBTREE_STATUSES.has(status) ? status : 'failed';
}

function normalizeSearchPurFallbackReason(reason = 'none') {
  return SEARCH_PUR_FALLBACK_REASONS.has(reason) ? reason : 'missing-required-block';
}

function normalizeSearchPurBiasSkippedReason(reason = 'none') {
  return SEARCH_PUR_BIAS_SKIPPED_REASONS.has(reason) ? reason : 'root-prebias-still-high-structural';
}

function collectSearchPurCanonicalCarouselSlides($, $group) {
  const $track = $group.find('.slick-track').first();
  const sourceNodes = $track.length
    ? $track.children().toArray()
    : $group.find(CAROUSEL_SLIDE_SELECTOR).toArray();

  return sourceNodes.filter((node) => {
    const $node = $(node);
    const className = String($node.attr('class') || '');
    const dataIndex = Number($node.attr('data-index'));
    const hiddenAttr = $node.attr('hidden') !== undefined;
    const styleText = String($node.attr('style') || '').toLowerCase();

    if (!className.includes('slick-slide')) {
      return false;
    }

    if (className.includes('slick-cloned')) {
      return false;
    }

    if (!Number.isFinite(dataIndex) || dataIndex < 0) {
      return false;
    }

    if (hiddenAttr) {
      return false;
    }

    if (/display\s*:\s*none/.test(styleText) || /visibility\s*:\s*hidden/.test(styleText)) {
      return false;
    }

    return true;
  });
}

function buildSearchPurRefinementDiagnostics(overrides = {}) {
  const resultsSubtreeStatus = normalizeSearchPurSubtreeStatus(overrides.resultsSubtreeStatus || 'failed');
  const carouselSubtreeStatus = normalizeSearchPurSubtreeStatus(overrides.carouselSubtreeStatus || 'failed');
  const resultsFallbackReason = resultsSubtreeStatus === 'complete'
    ? 'none'
    : normalizeSearchPurFallbackReason(overrides.resultsFallbackReason || 'missing-required-block');
  const carouselFallbackReason = carouselSubtreeStatus === 'complete'
    ? 'none'
    : normalizeSearchPurFallbackReason(overrides.carouselFallbackReason || 'missing-required-block');

  return {
    strategy: 'supplier-sources-shell-subtree-refinement',
    applied: Boolean(overrides.applied),
    derivedFromBlockId: 'profile',
    resultsSubtreeStatus,
    carouselSubtreeStatus,
    resultsFallbackReason,
    carouselFallbackReason,
    profileBlockId: 'profile',
    ...overrides,
    resultsSubtreeStatus,
    carouselSubtreeStatus,
    resultsFallbackReason,
    carouselFallbackReason
  };
}

function loadMarkupRoot(markup = '', shellId = '__protorec-markup-root') {
  const $ = cheerio.load(`<div id="${shellId}">${markup}</div>`, { decodeEntities: false });
  const $shellRoot = $(`#${shellId}`);
  const $root = $shellRoot.children().length === 1
    ? $shellRoot.children().first()
    : $shellRoot;

  return {
    $,
    $shellRoot,
    $root
  };
}

function splitMarkupByMarker(markup = '', marker = '') {
  const markerIndex = String(markup || '').indexOf(marker);
  if (markerIndex < 0) {
    return null;
  }

  return {
    beforeChildrenHtml: String(markup || '').slice(0, markerIndex),
    afterChildrenHtml: String(markup || '').slice(markerIndex + marker.length)
  };
}

function buildShellComposition({
  $,
  $root,
  mountSelector,
  mountAttrName,
  childMountSelector,
  completenessKey,
  mountMode = 'descendant'
}) {
  const marker = '__PROTOREC_CHILDREN_MARKER__';
  const $clone = $root.clone();
  let $mount = null;

  if (mountMode === 'self') {
    $clone.attr(mountAttrName, '');
    $mount = $clone;
  } else {
    const mounts = $clone.find(mountSelector).toArray();
    if (!mounts.length) {
      return {
        ok: false,
        fallbackReason: 'missing-mount-selector'
      };
    }
    if (mounts.length > 1) {
      return {
        ok: false,
        fallbackReason: 'multiple-mount-selectors'
      };
    }
    $mount = $clone.find(mountSelector).first();
    $mount.attr(mountAttrName, '');
  }

  $mount.html(marker);
  const shellMarkup = $.html($clone) || '';
  const splitResult = splitMarkupByMarker(shellMarkup, marker);
  if (!splitResult) {
    return {
      ok: false,
      fallbackReason: 'invalid-composition-html'
    };
  }

  const mountCount = cheerio
    .load(`<div id="__protorec-composition-root">${splitResult.beforeChildrenHtml}${splitResult.afterChildrenHtml}</div>`, { decodeEntities: false })
    ('#__protorec-composition-root')
    .find(childMountSelector)
    .length;

  if (mountCount !== 1) {
    return {
      ok: false,
      fallbackReason: mountCount === 0 ? 'missing-mount-selector' : 'multiple-mount-selectors'
    };
  }

  return {
    ok: true,
    shellMarkup: `${splitResult.beforeChildrenHtml}${splitResult.afterChildrenHtml}`,
    composition: {
      beforeChildrenHtml: splitResult.beforeChildrenHtml,
      afterChildrenHtml: splitResult.afterChildrenHtml,
      childMountSelector,
      completenessKey
    }
  };
}

function countInteractionMarkersInMarkup(markup = '', interactionId = '') {
  if (!String(markup || '').trim() || !String(interactionId || '').trim()) {
    return 0;
  }

  const { $, $shellRoot } = loadMarkupRoot(markup, '__protorec-marker-root');
  return $shellRoot.find(`[data-protorec-slide-index][data-protorec-interaction-id="${interactionId}"]`).length;
}

function stripInteractionMarkersFromMarkup(markup = '', removedInteractionIds = []) {
  if (!String(markup || '').trim()) {
    return '';
  }

  const removedIdSet = new Set(
    (Array.isArray(removedInteractionIds) ? removedInteractionIds : [])
      .map((value) => String(value || '').trim())
      .filter(Boolean)
  );
  if (!removedIdSet.size) {
    return String(markup || '');
  }

  const { $, $shellRoot } = loadMarkupRoot(markup, '__protorec-strip-root');
  $shellRoot.find('*').addBack().each((_, element) => {
    const $element = $(element);
    const attrs = { ...(element.attribs || {}) };
    const interactionId = String($element.attr('data-protorec-interaction-id') || '').trim();
    const removeAllProtoAttrs = interactionId && removedIdSet.has(interactionId);

    Object.entries(attrs).forEach(([name, value]) => {
      if (!/^data-protorec-/.test(name)) {
        return;
      }

      if (removeAllProtoAttrs || removedIdSet.has(String(value || '').trim())) {
        $element.removeAttr(name);
      }
    });
  });

  return $shellRoot.html() || '';
}

function createSearchPurDerivedBlock({
  sectionId,
  blockId,
  markup,
  previewMarkup,
  interactionDescriptors = [],
  siteAdapter = null,
  summary = '',
  diagnosticsPatch = null
}) {
  const componentName = `${getBlockComponentName(sectionId, blockId)}Block`;
  const fileName = `${componentName}.tsx`;
  const { $, $root } = loadMarkupRoot(markup, `__protorec-${blockId}-root`);
  const block = buildDerivedBlock({
    $ctx: $,
    $element: $root,
    sectionId,
    blockId,
    markup,
    previewMarkup,
    blockKind: 'content-block',
    interactionDescriptors,
    siteAdapter,
    derivedFromBlockId: 'profile',
    componentName,
    fileName,
    extractionSource: 'supplier-sources-shell-subtree-refinement',
    extractionStrategy: 'supplier-sources-shell-subtree-refinement'
  });

  if (summary) {
    block.summary = summary;
  }

  if (diagnosticsPatch && typeof diagnosticsPatch === 'object') {
    block.diagnostics = {
      ...(block.diagnostics || {}),
      ...diagnosticsPatch
    };
  }

  return block;
}

function buildSearchPurCarouselOwnerMap(sectionId = '') {
  return {
    [`${sectionId}-profile-carousel`]: 'profile-carousel-feed-shell',
    [`${sectionId}-profile-carousel-2`]: 'profile-carousel-banner'
  };
}

function collectSearchPurCarouselDescriptors(descriptors = [], sectionId = '') {
  const ownerMap = buildSearchPurCarouselOwnerMap(sectionId);
  const mappedDescriptors = descriptors
    .filter((descriptor) => descriptor?.kind === 'carousel' && ownerMap[String(descriptor?.id || '').trim()])
    .map((descriptor) => ({
      ...descriptor,
      sectionId,
      ownerBlockId: ownerMap[String(descriptor?.id || '').trim()]
    }))
    .sort((left, right) => String(left.id || '').localeCompare(String(right.id || '')));

  const expectedDescriptorIds = Object.keys(ownerMap).sort();
  const actualDescriptorIds = mappedDescriptors.map((descriptor) => String(descriptor.id || '')).sort();
  const isComplete = expectedDescriptorIds.length === actualDescriptorIds.length
    && expectedDescriptorIds.every((descriptorId, index) => descriptorId === actualDescriptorIds[index]);

  return {
    isComplete,
    ownerMap,
    mappedDescriptors,
    removedDescriptorIds: (Array.isArray(descriptors) ? descriptors : [])
      .map((descriptor) => String(descriptor?.id || '').trim())
      .filter((descriptorId) => descriptorId && !ownerMap[descriptorId])
  };
}

function filterSearchPurResultsRows($, $tbody) {
  return $tbody.children().toArray().filter((row) => {
    const $row = $(row);
    const className = String($row.attr('class') || '');
    const rowKey = String($row.attr('data-row-key') || '').trim();
    if (row.tagName !== 'tr') {
      return false;
    }
    if (!className.includes('hammer-table-row')) {
      return false;
    }
    if (!rowKey) {
      return false;
    }
    if (className.includes('measure-row')) {
      return false;
    }
    if (className.includes('placeholder')) {
      return false;
    }
    if (className.includes('expanded-row') || className.includes('expand-row')) {
      return false;
    }
    if (className.includes('summary')) {
      return false;
    }
    if (String($row.attr('aria-hidden') || '').trim() === 'true') {
      return false;
    }
    if (String($row.attr('hidden') || '').trim()) {
      return false;
    }
    return true;
  });
}

function chunkNodes(nodes = [], chunkSize = SEARCH_PUR_FEED_GROUP_SIZE) {
  const groups = [];
  const safeChunkSize = Math.max(1, Number(chunkSize) || SEARCH_PUR_FEED_GROUP_SIZE);

  for (let index = 0; index < nodes.length; index += safeChunkSize) {
    groups.push(nodes.slice(index, index + safeChunkSize));
  }

  return groups;
}

function collectSearchPurResultsSubtreeVariant(markup = '', removedDescriptorIds = []) {
  const { $, $root } = loadMarkupRoot(markup, '__protorec-search-pur-results-root');
  const $leftColumn = $root.children().first();
  if (!$leftColumn.length) {
    return {
      status: 'failed',
      fallbackReason: 'missing-required-block'
    };
  }

  const $leftInner = $leftColumn.children().first().length
    ? $leftColumn.children().first()
    : $leftColumn;
  const leftChildren = $leftInner.children().toArray();
  if (leftChildren.length < 4) {
    return {
      status: 'failed',
      fallbackReason: 'missing-required-block'
    };
  }

  const headerMarkup = stripInteractionMarkersFromMarkup(buildMarkupFromNodes($, leftChildren.slice(0, 2)), removedDescriptorIds);
  const $resultsRoot = $(leftChildren[2]);
  const $resultsContent = (
    $resultsRoot.children().length === 1
    && (
      $resultsRoot.children().first().find('tbody.hammer-table-tbody').length > 0
      || $resultsRoot.children().first().is('.hammer-pro-table')
    )
  )
    ? $resultsRoot.children().first()
    : $resultsRoot;
  const $paginationRoot = $(leftChildren[3]);
  const $toolbar = $resultsContent.children().first();
  const $tableShellRoot = $resultsContent.children().eq(1);
  if (!$toolbar.length || !$tableShellRoot.length || !$paginationRoot.length || !String(headerMarkup || '').trim()) {
    return {
      status: 'failed',
      fallbackReason: 'missing-required-block'
    };
  }

  const tbodyCandidates = $tableShellRoot.find('tbody.hammer-table-tbody').toArray();
  if (!tbodyCandidates.length) {
    return {
      status: 'failed',
      fallbackReason: 'missing-mount-selector'
    };
  }
  if (tbodyCandidates.length > 1) {
    return {
      status: 'failed',
      fallbackReason: 'multiple-mount-selectors'
    };
  }

  const $tbody = $(tbodyCandidates[0]);
  const rowNodes = filterSearchPurResultsRows($, $tbody);
  if (!rowNodes.length) {
    return {
      status: 'failed',
      fallbackReason: 'missing-required-block'
    };
  }

  const tableShellComposition = buildShellComposition({
    $,
    $root: $tableShellRoot,
    mountSelector: 'tbody.hammer-table-tbody',
    mountAttrName: 'data-protorec-results-body-root',
    childMountSelector: SEARCH_PUR_RESULTS_MOUNT_SELECTOR,
    completenessKey: `profile-results-table-shell|tbody|rows:${rowNodes.length}`
  });
  if (!tableShellComposition.ok) {
    return {
      status: 'failed',
      fallbackReason: tableShellComposition.fallbackReason || 'invalid-composition-html'
    };
  }

  return {
    status: 'complete',
    fallbackReason: 'none',
    parts: {
      headerMarkup,
      toolbarMarkup: stripInteractionMarkersFromMarkup($.html($toolbar) || '', removedDescriptorIds),
      tableShellMarkup: stripInteractionMarkersFromMarkup(tableShellComposition.shellMarkup || '', removedDescriptorIds),
      tableShellComposition: tableShellComposition.composition,
      rowMarkups: rowNodes.map((row) => stripInteractionMarkersFromMarkup($.html($(row)) || '', removedDescriptorIds)),
      paginationMarkup: stripInteractionMarkersFromMarkup($.html($paginationRoot) || '', removedDescriptorIds)
    }
  };
}

function collectSearchPurCarouselSubtreeVariant(markup = '', options = {}) {
  const removedDescriptorIds = Array.isArray(options.removedDescriptorIds) ? options.removedDescriptorIds : [];
  const feedDescriptor = options.feedDescriptor || null;
  const bannerDescriptor = options.bannerDescriptor || null;
  const { $, $root } = loadMarkupRoot(markup, '__protorec-search-pur-carousel-root');
  const $rightColumn = $root.children().eq(1);
  if (!$rightColumn.length) {
    return {
      status: 'failed',
      fallbackReason: 'missing-required-block'
    };
  }

  const rightChildren = $rightColumn.children().toArray();
  if (rightChildren.length < 2) {
    return {
      status: 'failed',
      fallbackReason: 'missing-required-block'
    };
  }

  const $feedShellRoot = $(rightChildren[0]);
  const $bannerRoot = $(rightChildren[1]);
  if (!$feedShellRoot.length || !$bannerRoot.length) {
    return {
      status: 'failed',
      fallbackReason: 'missing-required-block'
    };
  }

  const carouselShellComposition = buildShellComposition({
    $,
    $root: $rightColumn,
    mountSelector: '',
    mountAttrName: 'data-protorec-carousel-shell-root',
    childMountSelector: SEARCH_PUR_CAROUSEL_SHELL_MOUNT_SELECTOR,
    completenessKey: 'profile-carousel-shell|outer-root',
    mountMode: 'self'
  });
  if (!carouselShellComposition.ok) {
    return {
      status: 'failed',
      fallbackReason: carouselShellComposition.fallbackReason || 'invalid-composition-html'
    };
  }

  const trackCandidates = $feedShellRoot.find('.slick-track').toArray();
  if (!trackCandidates.length) {
    return {
      status: 'failed',
      fallbackReason: 'missing-mount-selector'
    };
  }
  if (trackCandidates.length > 1) {
    return {
      status: 'failed',
      fallbackReason: 'multiple-mount-selectors'
    };
  }

  const slideNodes = collectSearchPurCanonicalCarouselSlides($, $feedShellRoot);
  if (!slideNodes.length) {
    return {
      status: 'failed',
      fallbackReason: 'missing-required-block'
    };
  }

  const feedShellComposition = buildShellComposition({
    $,
    $root: $feedShellRoot,
    mountSelector: '.slick-track',
    mountAttrName: 'data-protorec-carousel-feed-root',
    childMountSelector: SEARCH_PUR_CAROUSEL_FEED_MOUNT_SELECTOR,
    completenessKey: `profile-carousel-feed-shell|slick-track|slides:${slideNodes.length}`
  });
  if (!feedShellComposition.ok) {
    return {
      status: 'failed',
      fallbackReason: feedShellComposition.fallbackReason || 'invalid-composition-html'
    };
  }

  const feedGroupMarkups = chunkNodes(slideNodes, SEARCH_PUR_FEED_GROUP_SIZE)
    .map((groupNodes) => stripInteractionMarkersFromMarkup(buildMarkupFromNodes($, groupNodes), removedDescriptorIds))
    .filter((value) => String(value || '').trim());
  if (!feedGroupMarkups.length) {
    return {
      status: 'failed',
      fallbackReason: 'missing-rendered-html'
    };
  }

  const feedShellMarkerCount = countInteractionMarkersInMarkup(feedShellComposition.shellMarkup, String(feedDescriptor?.id || ''));
  const feedGroupMarkerCount = feedGroupMarkups.reduce((total, groupMarkup) => {
    return total + countInteractionMarkersInMarkup(groupMarkup, String(feedDescriptor?.id || ''));
  }, 0);
  const bannerMarkerCount = countInteractionMarkersInMarkup($.html($bannerRoot) || '', String(bannerDescriptor?.id || ''));

  if (
    feedDescriptor
    && Number(feedDescriptor.itemCount || 0) > 0
    && (feedShellMarkerCount !== 0 || feedGroupMarkerCount !== Number(feedDescriptor.itemCount || 0))
  ) {
    return {
      status: 'failed',
      fallbackReason: 'mount-validation-failed'
    };
  }

  if (
    bannerDescriptor
    && Number(bannerDescriptor.itemCount || 0) > 0
    && bannerMarkerCount !== Number(bannerDescriptor.itemCount || 0)
  ) {
    return {
      status: 'failed',
      fallbackReason: 'mount-validation-failed'
    };
  }

  return {
    status: 'complete',
    fallbackReason: 'none',
    parts: {
      carouselShellMarkup: stripInteractionMarkersFromMarkup(carouselShellComposition.shellMarkup || '', removedDescriptorIds),
      carouselShellComposition: carouselShellComposition.composition,
      feedShellMarkup: stripInteractionMarkersFromMarkup(feedShellComposition.shellMarkup || '', removedDescriptorIds),
      feedShellComposition: feedShellComposition.composition,
      feedGroupMarkups,
      bannerMarkup: stripInteractionMarkersFromMarkup($.html($bannerRoot) || '', removedDescriptorIds)
    }
  };
}

function buildSearchPurProfileRefinementResult({
  applied = false,
  blocks = [],
  descriptors = [],
  diagnostics = {}
}) {
  return {
    applied,
    blocks,
    descriptors,
    diagnostics: buildSearchPurRefinementDiagnostics({
      applied,
      ...diagnostics
    })
  };
}

function maybeRefineSearchPurProfileBlock({
  sectionId,
  blocks = [],
  descriptors = [],
  siteAdapter = null
}) {
  if (!ENABLE_HISTORICAL_PAGE_REFINEMENTS) {
    return null;
  }

  if (String(sectionId || '').trim() !== SEARCH_PUR_XY_ROOT_SECTION_ID) {
    return null;
  }

  const profileBlock = blocks.find((block) => String(block?.id || '').trim() === 'profile');
  if (!profileBlock) {
    return buildSearchPurProfileRefinementResult({
      applied: false,
      blocks,
      descriptors,
      diagnostics: {
        resultsSubtreeStatus: 'failed',
        carouselSubtreeStatus: 'failed',
        resultsFallbackReason: 'missing-required-block',
        carouselFallbackReason: 'missing-required-block'
      }
    });
  }

  const profileDescriptors = descriptors.filter((descriptor) => {
    return Array.isArray(profileBlock.interactionIds) && profileBlock.interactionIds.includes(descriptor.id);
  });
  const {
    isComplete: hasExpectedCarouselDescriptors,
    mappedDescriptors: refinedCarouselDescriptors,
    removedDescriptorIds
  } = collectSearchPurCarouselDescriptors(profileDescriptors, sectionId);
  if (!hasExpectedCarouselDescriptors) {
    return buildSearchPurProfileRefinementResult({
      applied: false,
      blocks,
      descriptors,
      diagnostics: {
        resultsSubtreeStatus: 'failed',
        carouselSubtreeStatus: 'failed',
        resultsFallbackReason: 'missing-required-block',
        carouselFallbackReason: 'missing-required-block'
      }
    });
  }

  const feedDescriptor = refinedCarouselDescriptors.find((descriptor) => descriptor.ownerBlockId === 'profile-carousel-feed-shell') || null;
  const bannerDescriptor = refinedCarouselDescriptors.find((descriptor) => descriptor.ownerBlockId === 'profile-carousel-banner') || null;
  const localResults = collectSearchPurResultsSubtreeVariant(profileBlock.markup, removedDescriptorIds);
  const localCarousel = collectSearchPurCarouselSubtreeVariant(profileBlock.markup, {
    removedDescriptorIds,
    feedDescriptor,
    bannerDescriptor
  });
  const previewResults = collectSearchPurResultsSubtreeVariant(profileBlock.previewMarkup || profileBlock.markup, removedDescriptorIds);
  const previewCarousel = collectSearchPurCarouselSubtreeVariant(profileBlock.previewMarkup || profileBlock.markup, {
    removedDescriptorIds,
    feedDescriptor,
    bannerDescriptor
  });

  const resultsSubtreeStatus = (
    localResults.status === 'complete'
    && previewResults.status === 'complete'
  ) ? 'complete' : normalizeSearchPurSubtreeStatus(localResults.status || previewResults.status || 'failed');
  const carouselSubtreeStatus = (
    localCarousel.status === 'complete'
    && previewCarousel.status === 'complete'
  ) ? 'complete' : normalizeSearchPurSubtreeStatus(localCarousel.status || previewCarousel.status || 'failed');
  const resultsFallbackReason = resultsSubtreeStatus === 'complete'
    ? 'none'
    : normalizeSearchPurFallbackReason(localResults.fallbackReason || previewResults.fallbackReason || 'refinement-reverted');
  const carouselFallbackReason = carouselSubtreeStatus === 'complete'
    ? 'none'
    : normalizeSearchPurFallbackReason(localCarousel.fallbackReason || previewCarousel.fallbackReason || 'refinement-reverted');

  if (resultsSubtreeStatus !== 'complete' || carouselSubtreeStatus !== 'complete') {
    return buildSearchPurProfileRefinementResult({
      applied: false,
      blocks,
      descriptors,
      diagnostics: {
        resultsSubtreeStatus: resultsSubtreeStatus === 'complete' ? 'fallback' : resultsSubtreeStatus,
        carouselSubtreeStatus: carouselSubtreeStatus === 'complete' ? 'fallback' : carouselSubtreeStatus,
        resultsFallbackReason: resultsSubtreeStatus === 'complete' ? 'refinement-reverted' : resultsFallbackReason,
        carouselFallbackReason: carouselSubtreeStatus === 'complete' ? 'refinement-reverted' : carouselFallbackReason
      }
    });
  }

  if (
    localResults.parts.rowMarkups.length !== previewResults.parts.rowMarkups.length
    || localCarousel.parts.feedGroupMarkups.length !== previewCarousel.parts.feedGroupMarkups.length
  ) {
    return buildSearchPurProfileRefinementResult({
      applied: false,
      blocks,
      descriptors,
      diagnostics: {
        resultsSubtreeStatus: 'failed',
        carouselSubtreeStatus: 'failed',
        resultsFallbackReason: 'mount-validation-failed',
        carouselFallbackReason: 'mount-validation-failed'
      }
    });
  }

  const profileIndex = blocks.findIndex((block) => block.id === profileBlock.id);
  const beforeBlocks = blocks.slice(0, profileIndex);
  const afterBlocks = blocks.slice(profileIndex + 1);
  const refinedBlocks = [
    ...beforeBlocks,
    createSearchPurDerivedBlock({
      sectionId,
      blockId: 'profile-header',
      markup: localResults.parts.headerMarkup,
      previewMarkup: previewResults.parts.headerMarkup,
      siteAdapter,
      summary: 'Profile Header'
    }),
    createSearchPurDerivedBlock({
      sectionId,
      blockId: 'profile-results-toolbar',
      markup: localResults.parts.toolbarMarkup,
      previewMarkup: previewResults.parts.toolbarMarkup,
      siteAdapter,
      summary: 'Results Toolbar'
    }),
    createSearchPurDerivedBlock({
      sectionId,
      blockId: 'profile-results-table-shell',
      markup: localResults.parts.tableShellMarkup,
      previewMarkup: previewResults.parts.tableShellMarkup,
      siteAdapter,
      summary: 'Results Table Shell',
      diagnosticsPatch: {
        composition: localResults.parts.tableShellComposition,
        subtreeStatus: 'complete',
        fallbackReason: 'none'
      }
    }),
    ...localResults.parts.rowMarkups.map((rowMarkup, rowIndex) => (
      createSearchPurDerivedBlock({
        sectionId,
        blockId: `profile-results-row-${rowIndex + 1}`,
        markup: rowMarkup,
        previewMarkup: previewResults.parts.rowMarkups[rowIndex],
        siteAdapter,
        summary: `Results Row ${rowIndex + 1}`
      })
    )),
    createSearchPurDerivedBlock({
      sectionId,
      blockId: 'profile-results-pagination',
      markup: localResults.parts.paginationMarkup,
      previewMarkup: previewResults.parts.paginationMarkup,
      siteAdapter,
      summary: 'Results Pagination'
    }),
    createSearchPurDerivedBlock({
      sectionId,
      blockId: 'profile-carousel-shell',
      markup: localCarousel.parts.carouselShellMarkup,
      previewMarkup: previewCarousel.parts.carouselShellMarkup,
      siteAdapter,
      summary: 'Carousel Shell',
      diagnosticsPatch: {
        composition: localCarousel.parts.carouselShellComposition,
        subtreeStatus: 'complete',
        fallbackReason: 'none'
      }
    }),
    createSearchPurDerivedBlock({
      sectionId,
      blockId: 'profile-carousel-feed-shell',
      markup: localCarousel.parts.feedShellMarkup,
      previewMarkup: previewCarousel.parts.feedShellMarkup,
      interactionDescriptors: feedDescriptor ? [feedDescriptor] : [],
      siteAdapter,
      summary: 'Carousel Feed Shell',
      diagnosticsPatch: {
        composition: localCarousel.parts.feedShellComposition
      }
    }),
    ...localCarousel.parts.feedGroupMarkups.map((groupMarkup, groupIndex) => (
      createSearchPurDerivedBlock({
        sectionId,
        blockId: `profile-carousel-feed-group-${groupIndex + 1}`,
        markup: groupMarkup,
        previewMarkup: previewCarousel.parts.feedGroupMarkups[groupIndex],
        siteAdapter,
        summary: `Carousel Feed Group ${groupIndex + 1}`
      })
    )),
    createSearchPurDerivedBlock({
      sectionId,
      blockId: 'profile-carousel-banner',
      markup: localCarousel.parts.bannerMarkup,
      previewMarkup: previewCarousel.parts.bannerMarkup,
      interactionDescriptors: bannerDescriptor ? [bannerDescriptor] : [],
      siteAdapter,
      summary: 'Carousel Banner'
    }),
    ...afterBlocks
  ];

  const remainingDescriptors = descriptors.filter((descriptor) => {
    return !Array.isArray(profileBlock.interactionIds) || !profileBlock.interactionIds.includes(descriptor.id);
  });

  return buildSearchPurProfileRefinementResult({
    applied: true,
    blocks: refinedBlocks,
    descriptors: remainingDescriptors.concat(refinedCarouselDescriptors),
    diagnostics: {
      resultsSubtreeStatus: 'complete',
      carouselSubtreeStatus: 'complete',
      resultsFallbackReason: 'none',
      carouselFallbackReason: 'none',
      rowCount: localResults.parts.rowMarkups.length,
      feedGroupCount: localCarousel.parts.feedGroupMarkups.length
    }
  });
}

function isSupplierEntryHammerLayoutSplitCandidate(_pageSlug, _sectionId, block) {
  if (!ENABLE_HISTORICAL_PAGE_REFINEMENTS) {
    return false;
  }

  return isSupplierEntryLikeHammerLayoutBlock(block);
}

function collectSupplierEntryHammerLayoutParts($, $layoutRoot) {
  const $aside = $layoutRoot.children('aside.hammer-pro-layout-sider').first();
  const $main = $layoutRoot.children('main.hammer-layout-content').first();
  if (!$aside.length || !$main.length) {
    return null;
  }

  const $breadcrumb = $main.children('nav.hammer-breadcrumb').first();
  const $contentMain = $main.children('main.hammer-pro-layout-content').first();
  if (!$contentMain.length) {
    return null;
  }

  const forms = $contentMain.find('form').toArray().filter((element) => $(element).closest('main.hammer-pro-layout-content').first().get(0) === $contentMain.get(0));
  const tables = $contentMain.find('div.hammer-table-wrapper').toArray().filter((element) => $(element).closest('main.hammer-pro-layout-content').first().get(0) === $contentMain.get(0));
  const paginations = $contentMain.find('ul.hammer-pagination').toArray().filter((element) => $(element).closest('main.hammer-pro-layout-content').first().get(0) === $contentMain.get(0));

  if (forms.length !== 1 || tables.length !== 1 || paginations.length !== 1) {
    return null;
  }

  const $form = $(forms[0]);
  const $table = $(tables[0]);
  const $pagination = $(paginations[0]);

  const menuMarkup = $.html($aside) || '';
  const queryMarkup = [$.html($breadcrumb) || '', $.html($form) || '']
    .filter((value) => String(value || '').trim())
    .join('');
  const tableMarkup = $.html($table) || '';
  const paginationMarkup = $.html($pagination) || '';

  if (![menuMarkup, queryMarkup, tableMarkup, paginationMarkup].every((markup) => String(markup || '').trim())) {
    return null;
  }

  return {
    menuMarkup,
    queryMarkup,
    tableMarkup,
    paginationMarkup,
    uniqueCounts: {
      forms: forms.length,
      tables: tables.length,
      paginations: paginations.length
    }
  };
}

function collectSupplierEntryCoverageMetrics({
  menuMarkup,
  queryMarkup,
  tableMarkup,
  paginationMarkup,
  originalMarkup
}) {
  const parts = [menuMarkup, queryMarkup, tableMarkup, paginationMarkup];
  const htmlCoverage = parts.reduce((total, markup) => total + String(markup || '').length, 0) / Math.max(String(originalMarkup || '').length, 1);
  const meaningfulCoverage = parts.reduce((total, markup) => total + countMeaningfulDescendantsForMarkup(markup), 0) / Math.max(countMeaningfulDescendantsForMarkup(originalMarkup), 1);

  return {
    htmlCoverage: Number(htmlCoverage.toFixed(4)),
    meaningfulCoverage: Number(meaningfulCoverage.toFixed(4))
  };
}

function buildSupplierEntryDerivedBlock({
  $ctx,
  $element,
  sectionId,
  blockId,
  markup,
  siteAdapter = null
}) {
  const componentName = `${getBlockComponentName(sectionId, blockId)}Block`;
  const fileName = `${componentName}.tsx`;
  const derivedBlock = buildDerivedBlock({
    $ctx,
    $element,
    sectionId,
    blockId,
    markup,
    previewMarkup: markup,
    blockKind: 'content-block',
    interactionDescriptors: [],
    siteAdapter,
    derivedFromBlockId: 'hammer-layout',
    componentName,
    fileName,
    extractionSource: 'second-pass-supplier-entry-layout-refinement',
    extractionStrategy: 'supplier-entry-hammer-layout-split'
  });

  derivedBlock.summary = {
    'menu-sider': 'Menu Sider',
    'query-panel': 'Query Panel',
    'results-table': 'Results Table',
    'pagination-shell': 'Pagination Shell'
  }[blockId] || derivedBlock.summary;

  return derivedBlock;
}

function maybeRefineSupplierEntryHammerLayoutBlock({
  pageSlug = '',
  sectionId,
  blocks = [],
  descriptors = [],
  siteAdapter = null
}) {
  const targetBlock = blocks.find((block) => isSupplierEntryHammerLayoutSplitCandidate(pageSlug, sectionId, block));
  if (!targetBlock) {
    return null;
  }

  const $layout = cheerio.load(`<div id="__protorec-hammer-layout-root">${targetBlock.markup}</div>`, { decodeEntities: false });
  let $layoutRoot = $layout('#__protorec-hammer-layout-root').children().first();
  if (!$layoutRoot.length) {
    $layoutRoot = $layout('#__protorec-hammer-layout-root');
  }

  const parts = collectSupplierEntryHammerLayoutParts($layout, $layoutRoot);
  if (!parts) {
    return null;
  }

  const coverage = collectSupplierEntryCoverageMetrics({
    menuMarkup: parts.menuMarkup,
    queryMarkup: parts.queryMarkup,
    tableMarkup: parts.tableMarkup,
    paginationMarkup: parts.paginationMarkup,
    originalMarkup: targetBlock.markup
  });
  if (coverage.htmlCoverage < 0.9 || coverage.meaningfulCoverage < 0.85) {
    return null;
  }

  const blockIndex = blocks.findIndex((block) => block.id === targetBlock.id);
  const beforeBlocks = blocks.slice(0, blockIndex);
  const afterBlocks = blocks.slice(blockIndex + 1);

  const $menu = cheerio.load(`<aside id="__protorec-menu-sider-root">${parts.menuMarkup}</aside>`, { decodeEntities: false });
  const $menuRoot = $menu('#__protorec-menu-sider-root');
  const $query = cheerio.load(`<div id="__protorec-query-panel-root">${parts.queryMarkup}</div>`, { decodeEntities: false });
  const $queryRoot = $query('#__protorec-query-panel-root');
  const $table = cheerio.load(`<div id="__protorec-results-table-root">${parts.tableMarkup}</div>`, { decodeEntities: false });
  const $tableRoot = $table('#__protorec-results-table-root');
  const $pagination = cheerio.load(`<div id="__protorec-pagination-shell-root">${parts.paginationMarkup}</div>`, { decodeEntities: false });
  const $paginationRoot = $pagination('#__protorec-pagination-shell-root');

  const refinedBlocks = [
    ...beforeBlocks,
    buildSupplierEntryDerivedBlock({
      $ctx: $menu,
      $element: $menuRoot,
      sectionId,
      blockId: 'menu-sider',
      markup: parts.menuMarkup,
      siteAdapter
    }),
    buildSupplierEntryDerivedBlock({
      $ctx: $query,
      $element: $queryRoot,
      sectionId,
      blockId: 'query-panel',
      markup: parts.queryMarkup,
      siteAdapter
    }),
    buildSupplierEntryDerivedBlock({
      $ctx: $table,
      $element: $tableRoot,
      sectionId,
      blockId: 'results-table',
      markup: parts.tableMarkup,
      siteAdapter
    }),
    buildSupplierEntryDerivedBlock({
      $ctx: $pagination,
      $element: $paginationRoot,
      sectionId,
      blockId: 'pagination-shell',
      markup: parts.paginationMarkup,
      siteAdapter
    }),
    ...afterBlocks
  ];

  return {
    blocks: refinedBlocks,
    descriptors,
    diagnostics: {
      strategy: 'supplier-entry-hammer-layout-split',
      htmlCoverage: coverage.htmlCoverage,
      meaningfulCoverage: coverage.meaningfulCoverage,
      derivedFromBlockId: 'hammer-layout',
      uniqueCounts: parts.uniqueCounts
    }
  };
}

function extractSectionBlocks({
  sectionId,
  sectionKind,
  rawMarkup,
  stats,
  siteAdapter = null,
  explicitLocalMap,
  explicitPreviewMap,
  byFileName,
  getUniqueInteractionId
}) {
  const eligibleForExtraction = shouldExtractSectionBlocks(sectionKind, stats);
  if (!eligibleForExtraction) {
    return {
      blocks: [],
      descriptors: [],
      contextWrappers: [],
      diagnostics: {
        eligible: false,
        attempted: false,
        status: 'skipped',
        reason: 'section-not-eligible-for-block-extraction',
        sectionHtmlLength: Number(stats?.htmlLength || 0),
        sectionChildCount: Number(stats?.childCount || 0),
        container: null,
        containerHtmlLength: 0,
        candidateChildCount: 0,
        acceptedCandidateCount: 0,
        htmlCoverage: 0
      }
    };
  }

  const $ = cheerio.load(`<div id="__protorec-section-root">${rawMarkup}</div>`, { decodeEntities: false });
  let $root = $('#__protorec-section-root').children().first();

  if (!$root.length) {
    $root = $('#__protorec-section-root');
  }

  let { $container, candidateChildren } = descendToBlockContainer($, $root, siteAdapter);
  let containerStats = getElementStats($, $container);
  let blockElements = filterAcceptedBlockCandidates($, candidateChildren, siteAdapter);
  let nestedContainer = null;
  let usedNestedContainer = false;
  let dominantNestedContainer = null;
  let nestedSearchGuard = null;
  let blockSummary = analyzeAcceptedBlockCandidates($, blockElements, containerStats, siteAdapter);

  if (blockElements.length < 2 || shouldRetryNestedBlockSearch(blockSummary, containerStats)) {
    nestedContainer = findNestedBlockContainer($, $root, 2, siteAdapter);
    const nestedSummary = nestedContainer
      ? analyzeAcceptedBlockCandidates($, nestedContainer.acceptedCandidates, nestedContainer.containerStats, siteAdapter)
      : null;
    if (
      nestedContainer
      && !shouldPreferCurrentHammerWorkbenchShell({
        $,
        $root,
        $currentContainer: $container,
        currentContainerStats: containerStats,
        currentBlocks: blockElements,
        nestedContainer,
        sectionStats: stats,
        siteAdapter
      })
      && shouldUseNestedBlockContainer(
        blockSummary,
        nestedSummary,
        blockElements,
        nestedContainer.acceptedCandidates,
        nestedContainer.htmlCoverage
      )
    ) {
      $container = nestedContainer.$container;
      candidateChildren = nestedContainer.candidateChildren;
      containerStats = nestedContainer.containerStats;
      blockElements = nestedContainer.acceptedCandidates;
      usedNestedContainer = true;
      blockSummary = analyzeAcceptedBlockCandidates($, blockElements, containerStats, siteAdapter);
    } else if (nestedContainer) {
      const guardCoverage = collectNestedContainerCoverageMetrics($, $root, nestedContainer.$container, stats);
      const currentShellMetrics = collectHammerWorkbenchShellMetrics($, $container, containerStats);
      if (currentShellMetrics) {
        nestedSearchGuard = {
          strategy: 'preserve-hammer-workbench-shell',
          candidateScore: nestedContainer.score,
          ...(guardCoverage || {}),
          currentShellMetrics
        };
      }
    }
  }

  for (let iteration = 0; iteration < 3; iteration += 1) {
    if (!(blockElements.length >= 2 && Number(blockSummary.dominantBlockRatio || 0) >= 0.82)) {
      break;
    }

    const dominantChild = pickDominantChild($, blockElements);
    const auxiliaryChildren = dominantChild
      ? blockElements.filter((child) => child !== dominantChild)
      : [];

    if (!dominantChild || !auxiliaryChildren.length) {
      break;
    }

    const nestedInDominant = findNestedBlockContainer($, $(dominantChild), 2, siteAdapter);
    if (!nestedInDominant?.acceptedCandidates?.length) {
      break;
    }

    const combinedCandidates = dedupeElements(auxiliaryChildren.concat(nestedInDominant.acceptedCandidates));
    const currentCoverage = blockElements.reduce((total, child) => {
      return total + getElementStats($, $(child)).htmlLength;
    }, 0) / Math.max(Number(containerStats?.htmlLength) || 1, 1);
    const combinedCoverage = combinedCandidates.reduce((total, child) => {
      return total + getElementStats($, $(child)).htmlLength;
    }, 0) / Math.max(Number(containerStats?.htmlLength) || 1, 1);
    const currentDistinctKinds = new Set(blockElements.map((child) => inferBlockKind($(child), siteAdapter))).size;
    const combinedDistinctKinds = new Set(combinedCandidates.map((child) => inferBlockKind($(child), siteAdapter))).size;

    if (!shouldExpandDominantBlockCandidate({
      blockElements,
      combinedCandidates,
      currentSummary: blockSummary,
      combinedCoverage,
      currentCoverage,
      currentDistinctKinds,
      combinedDistinctKinds
    })) {
      break;
    }

    blockElements = combinedCandidates;
    dominantNestedContainer = {
      ...nestedInDominant,
      combinedCoverage: Number(combinedCoverage.toFixed(4))
    };
    blockSummary = analyzeAcceptedBlockCandidates($, blockElements, containerStats, siteAdapter);
  }

  const extractionBaseDiagnostics = {
    eligible: true,
    attempted: true,
    status: 'failed',
    reason: 'insufficient-block-candidates',
    sectionHtmlLength: Number(stats?.htmlLength || 0),
    sectionChildCount: Number(stats?.childCount || 0),
    container: summarizeElementSource($container, containerStats),
    containerHtmlLength: Number(containerStats?.htmlLength || 0),
    candidateChildCount: candidateChildren.length,
    acceptedCandidateCount: 0,
    htmlCoverage: 0
  };
  const nestedCoverageMetrics = usedNestedContainer
    ? collectNestedContainerCoverageMetrics($, $root, $container, stats)
    : null;
  const sharedContextWrappers = collectContextBridgeWrappers($, $root, $container);
  const stableIdentityCount = blockSummary.stableIdentityCount;
  const structuredKindCount = blockSummary.structuredKindCount;
  const dominantBlockRatio = blockSummary.dominantBlockRatio;

  if (blockElements.length < 2) {
    return {
      blocks: [],
      descriptors: [],
      contextWrappers: [],
      diagnostics: extractionBaseDiagnostics
    };
  }

  if (
    containerStats.htmlLength >= 45000
    && blockElements.length <= 2
    && dominantBlockRatio >= 0.88
    && structuredKindCount < 1
    && stableIdentityCount < 2
  ) {
    return {
      blocks: [],
      descriptors: [],
      contextWrappers: [],
      diagnostics: {
        ...extractionBaseDiagnostics,
        reason: 'dominant-block-candidate',
        acceptedCandidateCount: blockElements.length,
        htmlCoverage: Number(dominantBlockRatio.toFixed(4))
      }
    };
  }

  if (
    blockElements.length >= 10
    && structuredKindCount < Math.ceil(blockElements.length * 0.3)
    && stableIdentityCount < 3
  ) {
    return {
      blocks: [],
      descriptors: [],
      contextWrappers: [],
      diagnostics: {
        ...extractionBaseDiagnostics,
        reason: 'overfragmented-generic-blocks',
        acceptedCandidateCount: blockElements.length,
        htmlCoverage: Number(dominantBlockRatio.toFixed(4))
      }
    };
  }

  const htmlCoverage = blockElements.reduce((total, child) => {
    return total + getElementStats($, $(child)).htmlLength;
  }, 0) / Math.max(containerStats.htmlLength, 1);
  const roundedHtmlCoverage = Number(htmlCoverage.toFixed(4));

  if (blockElements.length < 3 && htmlCoverage < 0.55) {
    return {
      blocks: [],
      descriptors: [],
      contextWrappers: [],
      diagnostics: {
        ...extractionBaseDiagnostics,
        reason: 'insufficient-html-coverage',
        acceptedCandidateCount: blockElements.length,
        htmlCoverage: roundedHtmlCoverage
      }
    };
  }

  if (usedNestedContainer && shouldRejectNestedContainerForUndercoverage(nestedCoverageMetrics, {
    acceptedCandidateCount: blockElements.length,
    sectionKind
  })) {
    return {
      blocks: [],
      descriptors: [],
      contextWrappers: [],
      diagnostics: {
        ...extractionBaseDiagnostics,
        reason: 'nested-container-undercoverage',
        acceptedCandidateCount: blockElements.length,
        htmlCoverage: roundedHtmlCoverage,
        nestedSearch: {
          strategy: 'descendant-container-search',
          score: nestedContainer.score,
          rootHtmlCoverage: nestedCoverageMetrics.rootHtmlCoverage,
          meaningfulCoverage: nestedCoverageMetrics.meaningfulCoverage
        }
      }
    };
  }

  const rootShellMetrics = usedNestedContainer
    ? collectHammerWorkbenchShellMetricsFromRoot($, $root)
    : null;

  if (
    usedNestedContainer
    && rootShellMetrics
    && Number(rootShellMetrics.chromeHtmlCoverage || 0) >= 0.18
    && Number(nestedCoverageMetrics?.rootHtmlCoverage || 0) < 0.78
    && Number(nestedCoverageMetrics?.meaningfulCoverage || 0) < 0.82
  ) {
    return {
      blocks: [],
      descriptors: [],
      contextWrappers: [],
      diagnostics: {
        ...extractionBaseDiagnostics,
        reason: 'preserve-hammer-workbench-shell',
        acceptedCandidateCount: blockElements.length,
        htmlCoverage: roundedHtmlCoverage,
        nestedSearch: {
          strategy: 'preserve-hammer-workbench-shell',
          score: nestedContainer.score,
          ...(nestedCoverageMetrics || {}),
          currentShellMetrics: rootShellMetrics
        }
      }
    };
  }

  const getUniqueBlockId = createUniqueNameFactory();
  const descriptors = [];
  const blocks = blockElements
    .map((child, childIndex) => {
      const $child = $(child);
      const childMarkup = stripProtoAttributes($.html($child) || '');
      if (!childMarkup.trim()) {
        return null;
      }

      const blockStats = getElementStats($, $child);
      const blockKind = inferBlockKind($child, siteAdapter);
      const blockId = getUniqueBlockId(pickBlockBaseName($child, blockKind, siteAdapter), blockKind || 'content-block');
      const componentName = `${getBlockComponentName(sectionId, blockId)}Block`;
      const fileName = `${componentName}.tsx`;
      const annotatedMarkup = annotateSectionMarkup(childMarkup, {
        sectionId,
        interactionIdBase: `${sectionId}-${blockId}`,
        ownerBlockId: blockId
      }, getUniqueInteractionId, siteAdapter);
      const interactionCount = annotatedMarkup.descriptors.length;
      const confidence = resolveBlockConfidence(blockKind, blockStats, interactionCount);

      descriptors.push(...annotatedMarkup.descriptors);

      return {
        id: blockId,
        sectionId,
        title: getBlockTitle(blockKind),
        kind: blockKind,
        summary: buildBlockSummary($child, blockKind, blockStats),
        confidence,
        renderMode: 'component-fragment',
        componentName,
        fileName,
        markup: stripProtoAttributes(rewriteMarkupAssets(annotatedMarkup.markup, explicitLocalMap, byFileName)),
        previewMarkup: stripProtoAttributes(rewriteMarkupAssets(annotatedMarkup.markup, explicitPreviewMap, byFileName)),
        interactionIds: annotatedMarkup.descriptors.map((descriptor) => descriptor.id),
        contextWrappers: sharedContextWrappers,
        stats: {
          htmlLength: blockStats.htmlLength,
          childCount: blockStats.childCount,
          imageCount: blockStats.imageCount
        },
        interactionDescriptors: annotatedMarkup.descriptors,
        diagnostics: createBlockDiagnostics({
          $element: $child,
          sectionId,
          blockId,
          blockKind,
          componentName,
          fileName,
          blockStats,
          confidence,
          interactionCount,
          siteAdapter,
          extraction: {
            status: 'success',
            source: 'section-block-extraction',
            containerSelector: extractionBaseDiagnostics.container.selectorHint,
            candidateIndex: childIndex,
            siblingCount: blockElements.length,
            htmlCoverage: roundedHtmlCoverage,
            containerHtmlLength: Number(containerStats?.htmlLength || 0)
          },
          contextWrappers: sharedContextWrappers
        })
      };
    })
    .filter(Boolean);

  if (blocks.length < 2) {
    return {
      blocks: [],
      descriptors: [],
      contextWrappers: [],
      diagnostics: {
        ...extractionBaseDiagnostics,
        reason: 'insufficient-renderable-blocks',
        acceptedCandidateCount: blocks.length,
        htmlCoverage: roundedHtmlCoverage
      }
    };
  }

  if (shouldRejectTabsLikeGenericBlockSplit(sectionKind, containerStats, blocks)) {
    return {
      blocks: [],
      descriptors: [],
      contextWrappers: [],
      diagnostics: {
        ...extractionBaseDiagnostics,
        reason: 'tabs-like-generic-block-split',
        acceptedCandidateCount: blocks.length,
        htmlCoverage: roundedHtmlCoverage
      }
    };
  }

  return {
    blocks,
    descriptors,
    contextWrappers: sharedContextWrappers,
    diagnostics: {
      ...extractionBaseDiagnostics,
      status: 'success',
      reason: usedNestedContainer ? 'nested-container-extracted-blocks' : 'extracted-multiple-blocks',
      nestedSearch: usedNestedContainer
        ? {
          strategy: 'descendant-container-search',
          score: nestedContainer.score,
          ...(nestedCoverageMetrics || {})
        }
        : nestedSearchGuard
          ? nestedSearchGuard
        : dominantNestedContainer
          ? {
            strategy: 'dominant-child-container-search',
            score: dominantNestedContainer.score,
            combinedCoverage: dominantNestedContainer.combinedCoverage
          }
        : null,
      acceptedCandidateCount: blocks.length,
      htmlCoverage: roundedHtmlCoverage
    }
  };
}

function buildSections({ $, explicitLocalMap, explicitPreviewMap, byFileName, siteAdapter = null, pageSlug = '' }) {
  const sectionElements = collectSectionElements($, siteAdapter);
  const getUniqueSectionId = createUniqueNameFactory();
  const getUniqueInteractionId = createUniqueNameFactory();
  const interactions = [];
  const sections = [];

  sectionElements.forEach((element) => {
    const $element = $(element);
    const rawMarkup = $.html($element) || '';
    if (!rawMarkup || !rawMarkup.trim()) {
      return;
    }

    const sectionKind = inferSectionKind($element, siteAdapter);
    const stats = getElementStats($, $element);
    const sectionBaseName = pickSectionBaseName($element, sectionKind);
    const sectionId = getUniqueSectionId(sectionBaseName, sectionKind || 'section');
    const baseMarkup = stripProtoAttributes(rawMarkup);
    const ancestorContextWrappers = collectAncestorContextWrappers($, $element);
    const extractedBlocks = extractSectionBlocks({
      sectionId,
      sectionKind,
      rawMarkup: baseMarkup,
      stats,
      siteAdapter,
      explicitLocalMap,
      explicitPreviewMap,
      byFileName,
      getUniqueInteractionId
    });
    const refinedBlocks = maybeRefineSearchPurProfileBlock({
      pageSlug,
      sectionId,
      blocks: extractedBlocks.blocks,
      descriptors: extractedBlocks.descriptors,
      siteAdapter
    });
    const supplierEntryRefinedBlocks = refinedBlocks
      ? null
      : maybeRefineSupplierEntryHammerLayoutBlock({
        pageSlug,
        sectionId,
        blocks: extractedBlocks.blocks,
        descriptors: extractedBlocks.descriptors,
        siteAdapter
      });
    const activeRefinement = refinedBlocks || supplierEntryRefinedBlocks;
    const finalExtractedBlocks = activeRefinement
      ? {
        ...extractedBlocks,
        blocks: activeRefinement.blocks,
        descriptors: activeRefinement.descriptors,
        diagnostics: {
          ...(extractedBlocks.diagnostics || {}),
          secondPassRefinement: activeRefinement.diagnostics || null
        }
      }
      : extractedBlocks;

    if (shouldPromoteBlocksToSections(sectionKind, stats, finalExtractedBlocks.blocks)) {
      const promotedSections = createPromotedSectionsFromBlocks({
        section: {
          id: sectionId,
          kind: sectionKind,
          componentName: `${getSectionComponentName(sectionId)}Section`
        },
        blocks: finalExtractedBlocks.blocks,
        siteAdapter,
        explicitLocalMap,
        explicitPreviewMap,
        byFileName,
        getUniqueSectionId
      });

      finalExtractedBlocks.descriptors.forEach((descriptor) => {
        interactions.push(descriptor);
      });

      sections.push(...promotedSections);
      return;
    }

    let rewrittenMarkup = rewriteMarkupAssets(baseMarkup, explicitLocalMap, byFileName);
    let previewMarkup = rewriteMarkupAssets(baseMarkup, explicitPreviewMap, byFileName);
    let sectionDescriptors = finalExtractedBlocks.descriptors;
    let sectionOwnedDescriptors = finalExtractedBlocks.descriptors;
    let blockInteractionCount = 0;
    let blocks = finalExtractedBlocks.blocks;
    let contextWrappers = ancestorContextWrappers;

    if (!blocks.length) {
      const annotatedMarkup = annotateSectionMarkup(baseMarkup, {
        sectionId,
        interactionIdBase: sectionId
      }, getUniqueInteractionId, siteAdapter);
      rewrittenMarkup = rewriteMarkupAssets(annotatedMarkup.markup, explicitLocalMap, byFileName);
      previewMarkup = rewriteMarkupAssets(annotatedMarkup.markup, explicitPreviewMap, byFileName);
      sectionDescriptors = annotatedMarkup.descriptors;
      sectionOwnedDescriptors = annotatedMarkup.descriptors;
    } else {
      const descriptorOwnership = splitDescriptorsByBlockOwnership(sectionDescriptors, blocks);
      sectionOwnedDescriptors = descriptorOwnership.sectionOwnedDescriptors;
      blockInteractionCount = Math.max(0, sectionDescriptors.length - sectionOwnedDescriptors.length);
      contextWrappers = dedupeContextWrappers(
        ancestorContextWrappers.concat(
          Array.isArray(finalExtractedBlocks.contextWrappers) ? finalExtractedBlocks.contextWrappers : []
        )
      );
    }

    const confidence = resolveSectionConfidence(sectionKind, stats, sectionOwnedDescriptors.length, blocks.length, {
      blockInteractionCount
    });
    const renderMode = resolveSectionRenderMode(sectionKind, stats, sectionOwnedDescriptors.length, blocks.length, {
      blockInteractionCount
    });
    const componentName = `${getSectionComponentName(sectionId)}Section`;
    const diagnostics = createSectionDiagnostics({
      $element,
      sectionId,
      sectionBaseName,
      sectionKind,
      stats,
      renderMode,
      confidence,
      interactionCount: sectionOwnedDescriptors.length,
      blockInteractionCount,
      blockCount: blocks.length,
      componentName,
      siteAdapter,
      extraction: finalExtractedBlocks.diagnostics,
      contextWrappers
    });

    sectionDescriptors.forEach((descriptor) => {
      interactions.push(descriptor);
    });

    sections.push({
      id: sectionId,
      title: getSectionTitle(sectionKind),
      kind: sectionKind,
      confidence,
      summary: buildSectionSummary($element, sectionKind, stats),
      renderMode,
      shellTag: getSectionShellTag(sectionKind),
      markup: stripProtoAttributes(rewrittenMarkup),
      previewMarkup: stripProtoAttributes(previewMarkup),
      blocks,
      componentName,
      fileName: `${componentName}.tsx`,
      interactionIds: sectionOwnedDescriptors.map((descriptor) => descriptor.id),
      contextWrappers,
      diagnostics,
      stats: {
        htmlLength: stats.htmlLength,
        childCount: stats.childCount,
        imageCount: stats.imageCount,
        blockCount: blocks.length
      }
    });
  });

  if (!sections.length) {
    const fallbackMarkup = $('body').html() || '';
    if (fallbackMarkup.trim()) {
      const $body = $('body');
      const fallbackStats = getElementStats($, $body);
      const annotatedFallbackMarkup = annotateSectionMarkup(stripProtoAttributes(fallbackMarkup), 'main-content', getUniqueInteractionId, siteAdapter);
      const componentName = 'MainContentSection';
      const confidence = 0.46;
      const renderMode = 'fallback-body-fragment';
      sections.push({
        id: 'main-content',
        title: 'Main Content',
        kind: 'main-content',
        confidence,
        summary: 'Fallback body content',
        renderMode,
        shellTag: 'section',
        markup: stripProtoAttributes(rewriteMarkupAssets(annotatedFallbackMarkup.markup, explicitLocalMap, byFileName)),
        previewMarkup: stripProtoAttributes(rewriteMarkupAssets(annotatedFallbackMarkup.markup, explicitPreviewMap, byFileName)),
        componentName,
        fileName: 'MainContentSection.tsx',
        interactionIds: annotatedFallbackMarkup.descriptors.map((descriptor) => descriptor.id),
        contextWrappers: [],
        diagnostics: createSectionDiagnostics({
          $element: $body,
          sectionId: 'main-content',
          sectionBaseName: 'main-content',
          sectionKind: 'main-content',
          stats: fallbackStats,
          renderMode,
          confidence,
          interactionCount: annotatedFallbackMarkup.descriptors.length,
          blockCount: 0,
          componentName,
          siteAdapter,
          contextWrappers: [],
          extraction: {
            eligible: false,
            attempted: false,
            status: 'fallback',
            reason: 'no-stable-sections-detected',
            sectionHtmlLength: Number(fallbackStats?.htmlLength || 0),
            sectionChildCount: Number(fallbackStats?.childCount || 0),
            container: summarizeElementSource($body, fallbackStats),
            containerHtmlLength: Number(fallbackStats?.htmlLength || 0),
            candidateChildCount: $body.children().length,
            acceptedCandidateCount: 0,
            htmlCoverage: 0
          }
        }),
        stats: {
          htmlLength: fallbackMarkup.length,
          childCount: $('body').children().length,
          imageCount: $('body').find('img, picture, svg, canvas, video').length
        }
      });
      interactions.push(...annotatedFallbackMarkup.descriptors);
    }
  }

  return {
    sections,
    interactions
  };
}

function createViewDefinition({ relativePageDir, pageSlug, pageTitle, metadata = {}, captureVariant = null }) {
  const routeSegments = String(relativePageDir || '').split('/').filter(Boolean);
  const subviewsIndex = routeSegments.indexOf('subviews');
  const baseRouteId = subviewsIndex >= 0
    ? routeSegments.slice(0, subviewsIndex).join('/')
    : relativePageDir;

  if (metadata?.multiTabCapture || captureVariant || subviewsIndex >= 0) {
    const inferredTabNumber = Number.isFinite(Number(captureVariant?.index))
      ? Number(captureVariant.index) + 1
      : Number((routeSegments[subviewsIndex + 1] || '').replace(/[^\d]/g, '')) || 1;

    return {
      baseRouteId: baseRouteId || pageSlug,
      assetSlug: sanitizeSegment((baseRouteId || pageSlug).replace(/[\\/]+/g, '-')) || pageSlug,
      currentRouteId: relativePageDir,
      viewId: `tab-${inferredTabNumber}`,
      viewKind: inferredTabNumber === 1 ? 'root-tab' : 'tab',
      viewLabel: captureVariant?.label || metadata?.activeTab?.label || `Tab ${inferredTabNumber}`,
      viewOrder: inferredTabNumber,
      isSubview: inferredTabNumber > 1,
      defaultViewId: 'tab-1'
    };
  }

  return {
    baseRouteId: relativePageDir,
    assetSlug: sanitizeSegment((relativePageDir || pageSlug).replace(/[\\/]+/g, '-')) || pageSlug,
    currentRouteId: relativePageDir,
    viewId: 'default',
    viewKind: 'page',
    viewLabel: pageTitle || 'Default View',
    viewOrder: 1,
    isSubview: false,
    defaultViewId: 'default'
  };
}

function resolveStyleConfidence(captureQuality = {}, metadata = {}, sourceCssText = '') {
  const captureScore = toNumericScore(captureQuality?.scoreBreakdown?.runtimeStyleScore, 0.52);
  const cssLength = String(sourceCssText || '').trim().length;
  const runtimeStyleTexts = Array.isArray(metadata?.runtimeStyleTexts)
    ? metadata.runtimeStyleTexts.filter((value) => String(value || '').trim())
    : [];
  const runtimeStyleTextLength = runtimeStyleTexts.reduce((total, value) => total + String(value || '').length, 0);
  const stylesheetCoverageScore = cssLength >= 20000
    ? 0.58
    : cssLength >= 12000
      ? 0.54
      : cssLength >= 6000
        ? 0.46
        : 0;
  const runtimeTextCoverageScore = runtimeStyleTextLength >= 6000
    ? 0.56
    : runtimeStyleTextLength >= 2000
      ? 0.5
      : runtimeStyleTextLength >= 500
        ? 0.44
        : 0;

  return Number(Math.max(captureScore, stylesheetCoverageScore, runtimeTextCoverageScore).toFixed(4));
}

function createConfidenceBreakdown(captureQuality = {}, metadata = {}, sections = [], interactions = [], sourceCssText = '') {
  const layout = toNumericScore(captureQuality?.scoreBreakdown?.layoutSnapshotScore, 0.62);
  const styles = resolveStyleConfidence(captureQuality, metadata, sourceCssText);
  const assets = toNumericScore(captureQuality?.scoreBreakdown?.assetScore, 0.7);
  const structuredSectionCount = sections.filter((section) => ['component-fragment', 'component-blocks'].includes(section.renderMode)).length;
  const content = Math.max(0.45, Math.min(0.92, 0.4 + (sections.length * 0.05) + (structuredSectionCount * 0.04)));
  const tabSignal = metadata?.activeTab ? 0.12 : 0;
  const scrollSignal = Array.isArray(metadata?.scrollContainerSnapshots) && metadata.scrollContainerSnapshots.length ? 0.1 : 0;
  const layoutSignal = Array.isArray(metadata?.layoutNodeSnapshots) && metadata.layoutNodeSnapshots.length ? 0.12 : 0;
  const interactionSignal = Math.min(0.18, interactions.length * 0.04);
  const interactionScore = Math.max(0.42, Math.min(0.86, 0.4 + scrollSignal + tabSignal + layoutSignal + interactionSignal));
  const page = Number((
    (layout * 0.28)
    + (styles * 0.2)
    + (assets * 0.18)
    + (content * 0.18)
    + (interactionScore * 0.16)
  ).toFixed(4));

  return {
    page,
    layout,
    styles,
    assets,
    interactions: interactionScore,
    content
  };
}

function clampPercent(value) {
  return Math.max(0, Math.min(100, Number(value || 0)));
}

function toPercentRatio(numerator, denominator, fallback = 0) {
  if (!denominator) {
    return fallback;
  }

  return clampPercent((numerator / denominator) * 100);
}

function looksMaintainableName(value) {
  const normalized = normalizeNameCandidate(value);
  if (!normalized) {
    return false;
  }

  if (isGenericNameToken(normalized)) {
    return false;
  }

  if (/^(css|r)-[a-z0-9-]+$/.test(normalized)) {
    return false;
  }

  if (/^(section|content-block|block|item)(-\d+)?$/.test(normalized)) {
    return false;
  }

  return !/^\d+$/.test(normalized);
}

function summarizeElementSource($element, stats = null) {
  const resolvedStats = stats || {
    textSnippet: normalizeTextSnippet($element.text() || '', 120)
  };
  const tagName = getElementTagName($element.get(0)) || 'div';
  const id = String($element.attr('id') || '').trim();
  const className = String($element.attr('class') || '')
    .trim()
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 6)
    .join(' ');
  const dataTestId = String($element.attr('data-testid') || '').trim();
  const ariaLabel = String($element.attr('aria-label') || '').trim();

  const selectorHint = [
    tagName,
    id ? `#${id}` : '',
    className ? `.${className.split(/\s+/).join('.')}` : ''
  ].filter(Boolean).join('');

  return {
    tagName,
    id,
    className,
    dataTestId,
    ariaLabel,
    selectorHint,
    textSnippet: resolvedStats.textSnippet || ''
  };
}

function pickContextAttributes(attributes = {}) {
  return Object.entries(attributes || {}).reduce((result, [rawName, rawValue]) => {
    const name = String(rawName || '').trim().toLowerCase();
    if (!name || name.startsWith('on') || name.startsWith('data-protorec-')) {
      return result;
    }

    if (
      !CONTEXT_ATTRIBUTE_ALLOWLIST.has(name)
      && !name.startsWith('data-')
      && !name.startsWith('aria-')
    ) {
      return result;
    }

    const value = rawValue === '' ? '' : String(rawValue ?? '');
    if (name === 'class' && !value.trim()) {
      return result;
    }

    result[name] = value;
    return result;
  }, {});
}

function shouldPreserveContextElement($, $element, options = {}) {
  const { force = false } = options;
  const tagName = getElementTagName($element?.get?.(0));
  if (!tagName || ['html', 'body'].includes(tagName)) {
    return false;
  }

  const attrs = pickContextAttributes($element.get(0)?.attribs || {});
  const attrNames = Object.keys(attrs);
  if (!attrNames.length) {
    return false;
  }

  if (force) {
    return true;
  }

  if (attrs.id || attrs.style) {
    return true;
  }

  const classTokens = String(attrs.class || '')
    .split(/\s+/)
    .map(normalizeNameCandidate)
    .filter(Boolean);
  const hasNonGenericClass = classTokens.some((token) => !isGenericNameToken(token));
  if (hasNonGenericClass) {
    return true;
  }

  return attrNames.some((name) => (
    name === 'role'
    || name === 'dir'
    || name === 'lang'
    || name === 'title'
    || name === 'tabindex'
    || name === 'hidden'
    || name.startsWith('data-')
    || name.startsWith('aria-')
  ));
}

function createContextWrapperDescriptor($, $element, options = {}) {
  const { force = false, reason = 'ancestor' } = options;
  if (!shouldPreserveContextElement($, $element, { force })) {
    return null;
  }

  return {
    tagName: getElementTagName($element.get(0)) || 'div',
    attrs: pickContextAttributes($element.get(0)?.attribs || {}),
    selectorHint: summarizeElementSource($element).selectorHint,
    reason
  };
}

function dedupeContextWrappers(wrappers = []) {
  const seen = new Set();
  return wrappers.filter((wrapper) => {
    if (!wrapper) {
      return false;
    }

    const key = `${wrapper.tagName}|${JSON.stringify(wrapper.attrs || {})}`;
    if (seen.has(key)) {
      return false;
    }

    seen.add(key);
    return true;
  });
}

function areContextWrappersEquivalent(left, right) {
  if (!left || !right) {
    return false;
  }

  return String(left.tagName || '') === String(right.tagName || '')
    && JSON.stringify(left.attrs || {}) === JSON.stringify(right.attrs || {});
}

function countMatchingContextWrapperPrefix(left = [], right = []) {
  const maxLength = Math.min(left.length, right.length);
  let matchedLength = 0;

  while (matchedLength < maxLength && areContextWrappersEquivalent(left[matchedLength], right[matchedLength])) {
    matchedLength += 1;
  }

  return matchedLength;
}

function stripContextWrapperPrefix(wrappers = [], prefix = []) {
  if (!Array.isArray(wrappers) || !wrappers.length || !Array.isArray(prefix) || !prefix.length) {
    return Array.isArray(wrappers) ? wrappers : [];
  }

  return wrappers.slice(countMatchingContextWrapperPrefix(wrappers, prefix));
}

function buildContextWrapperPrefixKey(wrappers = []) {
  return JSON.stringify(
    wrappers.map((wrapper) => ({
      tagName: String(wrapper?.tagName || ''),
      attrs: wrapper?.attrs || {}
    }))
  );
}

function collectSharedContextWrapperPrefix(sections = []) {
  const wrapperLists = sections
    .map((section) => (Array.isArray(section?.contextWrappers) ? section.contextWrappers : []))
    .filter((wrappers) => wrappers.length);

  if (wrapperLists.length < 2) {
    return [];
  }

  const minimumSharedSectionCount = wrapperLists.length >= 5
    ? Math.ceil(wrapperLists.length / 2)
    : 2;
  const prefixCandidates = new Map();

  wrapperLists.forEach((wrappers, wrapperListIndex) => {
    for (let prefixLength = 1; prefixLength <= wrappers.length; prefixLength += 1) {
      const prefix = wrappers.slice(0, prefixLength);
      const prefixKey = buildContextWrapperPrefixKey(prefix);
      const existingCandidate = prefixCandidates.get(prefixKey);
      if (existingCandidate) {
        if (!existingCandidate.wrapperListIndexes.has(wrapperListIndex)) {
          existingCandidate.wrapperListIndexes.add(wrapperListIndex);
          existingCandidate.count += 1;
        }
        continue;
      }

      prefixCandidates.set(prefixKey, {
        prefix,
        count: 1,
        depth: prefixLength,
        wrapperListIndexes: new Set([wrapperListIndex])
      });
    }
  });

  let bestCandidate = null;
  prefixCandidates.forEach((candidate) => {
    if (candidate.count < minimumSharedSectionCount) {
      return;
    }

    const score = candidate.depth * candidate.count;
    if (
      !bestCandidate
      || score > bestCandidate.score
      || (score === bestCandidate.score && candidate.depth > bestCandidate.depth)
      || (score === bestCandidate.score && candidate.depth === bestCandidate.depth && candidate.count > bestCandidate.count)
    ) {
      bestCandidate = {
        prefix: candidate.prefix,
        score,
        depth: candidate.depth,
        count: candidate.count
      };
    }
  });

  return bestCandidate?.prefix || [];
}

function optimizeSharedPageContextWrappers(sections = []) {
  const pageContextWrappers = collectSharedContextWrapperPrefix(sections);
  if (!pageContextWrappers.length) {
    return {
      pageContextWrappers: [],
      sections
    };
  }

  return {
    pageContextWrappers,
    sections: sections.map((section) => ({
      ...section,
      contextWrappers: Array.isArray(section.contextWrappers)
        ? stripContextWrapperPrefix(section.contextWrappers, pageContextWrappers)
        : []
    }))
  };
}

function collectAncestorContextWrappers($, $element, maxDepth = 8) {
  const wrappers = [];
  let current = $element.parent();
  let depth = 0;

  while (current?.length && depth < maxDepth) {
    const tagName = getElementTagName(current.get(0));
    if (!tagName || ['html', 'body'].includes(tagName)) {
      break;
    }

    const wrapper = createContextWrapperDescriptor($, current, {
      reason: 'section-ancestor'
    });
    if (wrapper) {
      wrappers.unshift(wrapper);
    }

    current = current.parent();
    depth += 1;
  }

  return dedupeContextWrappers(wrappers);
}

function collectContextBridgeWrappers($, $ancestor, $descendant) {
  if (!$ancestor?.length || !$descendant?.length) {
    return [];
  }

  const ancestorNode = $ancestor.get(0);
  const chain = [];
  let current = $descendant.get(0);
  let depth = 0;

  while (current && depth < 24) {
    chain.push($(current));
    if (current === ancestorNode) {
      break;
    }
    current = current.parent;
    depth += 1;
  }

  if (!chain.length || chain[chain.length - 1]?.get?.(0) !== ancestorNode) {
    return [];
  }

  return dedupeContextWrappers(
    chain
      .reverse()
      .map(($node, index, nodes) => createContextWrapperDescriptor($, $node, {
        force: index === 0 || index === nodes.length - 1,
        reason: index === 0
          ? 'section-root'
          : (index === nodes.length - 1 ? 'block-container' : 'context-bridge')
      }))
      .filter(Boolean)
  );
}

function buildContextDiagnostics(contextWrappers = [], strategy = 'none') {
  return {
    strategy,
    wrapperCount: Array.isArray(contextWrappers) ? contextWrappers.length : 0,
    wrappers: Array.isArray(contextWrappers) ? contextWrappers : []
  };
}

function collectSectionRuleMatches($element, stats, siteAdapter = null) {
  return collectSectionRuleMatchesFromSignals(buildElementRuleSignals($element, stats, { siteAdapter }));
}

function collectBlockRuleMatches($element, stats, blockKind, siteAdapter = null) {
  return collectBlockRuleMatchesFromSignals({
    ...buildElementRuleSignals($element, stats, { siteAdapter }),
    blockKind,
    hasStableIdentity: hasStableBlockIdentity($element, siteAdapter)
  });
}

function explainSectionRenderMode(sectionKind, stats, interactionCount, blockCount = 0, extraction = {}, options = {}) {
  const blockInteractionCount = Number(options.blockInteractionCount || 0);
  const reasons = [];

  if (extraction?.reason === 'promoted-from-section-block') {
    reasons.push('来自超大混合 section 的稳定 block，已提升为独立 section 输出');
  }

  if (blockCount >= 2) {
    reasons.push('已成功拆分出多个 block，优先输出 component-blocks');
    return reasons;
  }

  if (stats.htmlLength >= 180000) {
    reasons.push('HTML 体量过大，降级为 fallback-body-fragment');
    return reasons;
  }

  if (STRONG_SECTION_KINDS.has(sectionKind)) {
    reasons.push('命中强语义 section 类型，输出 component-fragment');
  }

  if (interactionCount > 0) {
    reasons.push(`检测到 ${interactionCount} 个基础交互信号，保持组件化输出`);
  } else if (blockInteractionCount > 0) {
    reasons.push(`子 block 保留 ${blockInteractionCount} 个交互信号，保持组件化输出`);
  }

  if (sectionKind === 'main-content' && stats.htmlLength >= 80000) {
    reasons.push('main-content 体量过大，降级为 fallback-body-fragment');
    return reasons;
  }

  if (!reasons.length) {
    reasons.push('默认使用 component-fragment 保持结构化输出');
  }

  return reasons;
}

function explainSectionConfidence(sectionKind, stats, interactionCount, blockCount = 0, extraction = {}, options = {}) {
  const blockInteractionCount = Number(options.blockInteractionCount || 0);
  const reasons = [];

  if (extraction?.reason === 'promoted-from-section-block') {
    reasons.push('由稳定 block 提升为 section，边界更明确');
  }

  if (stats.headingCount) {
    reasons.push('存在标题语义，提升可识别性');
  }
  if (interactionCount > 0) {
    reasons.push(`提取到 ${interactionCount} 个交互信号`);
  } else if (blockInteractionCount > 0) {
    reasons.push(`子 block 保留 ${blockInteractionCount} 个交互信号`);
  }
  if (blockCount >= 2) {
    reasons.push(`成功拆分为 ${blockCount} 个 block`);
  }
  if (stats.htmlLength >= 120000) {
    reasons.push('区块体量极大，置信度受惩罚');
  } else if (stats.htmlLength >= 60000) {
    reasons.push('区块体量偏大，置信度轻微受惩罚');
  }
  if (!reasons.length) {
    reasons.push(`${sectionKind} 类型使用基础置信度`);
  }

  return reasons;
}

function explainBlockConfidence(blockKind, stats, interactionCount = 0) {
  const reasons = [];

  if (interactionCount > 0) {
    reasons.push(`block 内检测到 ${interactionCount} 个交互信号`);
  }
  if (stats.htmlLength >= 90000) {
    reasons.push('block 体量过大，置信度受惩罚');
  } else if (stats.htmlLength >= 50000) {
    reasons.push('block 体量偏大，置信度轻微受惩罚');
  }
  if (['product-shelf', 'featured-shelf', 'promo-banner', 'service-strip', 'hero-media', 'product-detail-hero', 'recommend-shelf', 'detail-content', 'spec-list', 'legal-notice', 'review-feed'].includes(blockKind)) {
    reasons.push('命中稳定业务块类型');
  }
  if (!reasons.length) {
    reasons.push(`${blockKind} 类型使用基础置信度`);
  }

  return reasons;
}

function assessVibecodingTarget({
  targetType,
  kind,
  renderMode = 'component-fragment',
  confidence = 0,
  interactionCount = 0,
  htmlLength = 0,
  namingQuality = 'generic'
}) {
  let suitabilityScore = Math.round((Number(confidence) || 0) * 100);
  const reasons = [];

  if (renderMode === 'fallback-body-fragment') {
    suitabilityScore -= 30;
    reasons.push('仍是 fallback fragment，直接修改风险高');
  } else {
    suitabilityScore += 6;
    reasons.push('已是结构化组件输出');
  }

  if (interactionCount > 0) {
    suitabilityScore -= 12;
    reasons.push('包含基础交互，改动时需要保留行为');
  }

  if (htmlLength >= 50000) {
    suitabilityScore -= 14;
    reasons.push('结构体量较大，改动面偏广');
  } else if (htmlLength >= 24000) {
    suitabilityScore -= 8;
    reasons.push('结构体量中等，建议局部修改');
  } else {
    suitabilityScore += 4;
    reasons.push('结构体量适中，适合先做局部调整');
  }

  if (namingQuality === 'maintainable') {
    suitabilityScore += 5;
    reasons.push('命名可读性较好，AI 更容易定位');
  } else {
    suitabilityScore -= 6;
    reasons.push('命名偏通用，AI 定位成本偏高');
  }

  if (['promo-banner', 'service-strip', 'featured-shelf', 'product-shelf', 'hero-media', 'product-detail-hero', 'recommend-shelf', 'detail-content', 'spec-list', 'legal-notice', 'detail-panel', 'notice', 'icon-grid'].includes(kind)) {
    suitabilityScore += 10;
    reasons.push('属于相对独立的业务块，适合先做二次 vibecoding');
  }

  if (['top-bar', 'footer', 'floating-layer', 'tabs', 'form', 'detail-anchor-bar'].includes(kind)) {
    suitabilityScore -= 16;
    reasons.push('属于全局或行为敏感区块，建议谨慎编辑');
  }

  if (
    targetType === 'block'
    && kind === 'content-block'
    && interactionCount > 0
    && htmlLength < 42000
    && confidence >= 0.72
  ) {
    suitabilityScore += 8;
    reasons.push('交互规模可控，仍可作为局部结构优化起点');
  }

  if (targetType === 'section' && kind === 'main-content') {
    suitabilityScore -= 8;
    reasons.push('section 粒度较粗，建议优先改 block 而不是整段 section');
  }

  const normalizedScore = clampPercent(suitabilityScore);
  let changeRisk = 'medium';
  if (normalizedScore >= 78) {
    changeRisk = 'low';
  } else if (normalizedScore < 58) {
    changeRisk = 'high';
  }

  return {
    suitabilityScore: normalizedScore,
    changeRisk,
    reasons: Array.from(new Set(reasons))
  };
}

function createSectionIssues({ renderMode, confidence, stats, interactionCount, blockCount, extraction = {} }) {
  const issues = [];

  if (renderMode === 'fallback-body-fragment') {
    issues.push('section 仍使用 fallback-body-fragment');
  }
  if (Number(confidence || 0) < 0.6) {
    issues.push('section 置信度偏低');
  }
  if (Number(stats?.htmlLength || 0) >= 50000 && blockCount < 2 && extraction?.reason !== 'promoted-from-section-block') {
    issues.push('section 体量较大但尚未成功拆分为 block');
  }
  if (interactionCount > 0) {
    issues.push('section 内含基础交互，改动时需保留行为');
  }
  if (extraction?.sourceBlockKind === 'review-feed' && Number(stats?.htmlLength || 0) >= 80000) {
    issues.push('review 区内容量较大，建议优先调整筛选条或单卡模板');
  }

  return issues;
}

function createBlockIssues({ kind, confidence, stats, interactionCount }) {
  const issues = [];

  if (Number(confidence || 0) < 0.66) {
    issues.push('block 置信度偏低');
  }
  if (Number(stats?.htmlLength || 0) >= 35000) {
    issues.push('block 体量偏大，建议继续局部抽象');
  }
  if (interactionCount > 0) {
    issues.push('block 内含基础交互');
  }
  if (['top-bar', 'footer', 'floating-layer'].includes(kind)) {
    issues.push('block 属于全局敏感区块');
  }

  return issues;
}

function createSectionDiagnostics({
  $element,
  sectionId,
  sectionBaseName,
  sectionKind,
  stats,
  renderMode,
  confidence,
  interactionCount,
  blockInteractionCount = 0,
  blockCount,
  componentName,
  siteAdapter = null,
  extraction = {},
  contextWrappers = []
}) {
  const source = summarizeElementSource($element, stats);
  const namingQuality = looksMaintainableName(sectionId) ? 'maintainable' : 'generic';
  const vibecoding = assessVibecodingTarget({
    targetType: 'section',
    kind: sectionKind,
    renderMode,
    confidence,
    interactionCount,
    htmlLength: stats.htmlLength,
    namingQuality
  });

  return {
    source,
    naming: {
      baseName: sectionBaseName,
      finalId: sectionId,
      componentName,
      quality: namingQuality
    },
    classification: {
      kind: sectionKind,
      matchedRules: collectSectionRuleMatches($element, stats, siteAdapter)
    },
    structure: {
      htmlLength: stats.htmlLength,
      childCount: stats.childCount,
      imageCount: stats.imageCount,
      interactionCount,
      blockCount
    },
    context: buildContextDiagnostics(
      contextWrappers,
      Array.isArray(contextWrappers) && contextWrappers.length
        ? (blockCount > 0 ? 'ancestor+section-root+block-container' : 'ancestor-only')
        : 'none'
    ),
    extraction,
    renderDecision: {
      mode: renderMode,
      reasons: explainSectionRenderMode(sectionKind, stats, interactionCount, blockCount, extraction, {
        blockInteractionCount
      })
    },
    confidenceDecision: {
      score: confidence,
      reasons: explainSectionConfidence(sectionKind, stats, interactionCount, blockCount, extraction, {
        blockInteractionCount
      })
    },
    issues: createSectionIssues({ renderMode, confidence, stats, interactionCount, blockCount, extraction }),
    vibecoding
  };
}

function createBlockDiagnostics({
  $element,
  sectionId,
  blockId,
  blockKind,
  componentName,
  fileName,
  blockStats,
  confidence,
  interactionCount,
  siteAdapter = null,
  extraction = {},
  contextWrappers = []
}) {
  const source = summarizeElementSource($element, blockStats);
  const namingQuality = looksMaintainableName(blockId) ? 'maintainable' : 'generic';
  const vibecoding = assessVibecodingTarget({
    targetType: 'block',
    kind: blockKind,
    renderMode: 'component-fragment',
    confidence,
    interactionCount,
    htmlLength: blockStats.htmlLength,
    namingQuality
  });

  return {
    source,
    parentSectionId: sectionId,
    naming: {
      finalId: blockId,
      componentName,
      fileName,
      quality: namingQuality
    },
    classification: {
      kind: blockKind,
      matchedRules: collectBlockRuleMatches($element, blockStats, blockKind, siteAdapter)
    },
    structure: {
      htmlLength: blockStats.htmlLength,
      childCount: blockStats.childCount,
      imageCount: blockStats.imageCount,
      interactionCount
    },
    context: buildContextDiagnostics(
      contextWrappers,
      Array.isArray(contextWrappers) && contextWrappers.length
        ? 'shared-section-context'
        : 'none'
    ),
    extraction,
    confidenceDecision: {
      score: confidence,
      reasons: explainBlockConfidence(blockKind, blockStats, interactionCount)
    },
    issues: createBlockIssues({
      kind: blockKind,
      confidence,
      stats: blockStats,
      interactionCount
    }),
    vibecoding
  };
}

function buildEditabilityTarget(section, block = null, options = {}) {
  const isBlock = Boolean(block);
  const view = options.view || {};
  const isSubview = Boolean(view?.isSubview);
  const diagnostics = isBlock ? (block?.diagnostics || {}) : (section?.diagnostics || {});
  const structure = diagnostics?.structure || {};
  const source = diagnostics?.source || {};
  const matchedRules = diagnostics?.classification?.matchedRules || [];
  const interactionIds = Array.isArray(isBlock ? block?.interactionIds : section?.interactionIds)
    ? (isBlock ? block.interactionIds : section.interactionIds)
    : [];
  const targetComponentName = isBlock
    ? (block?.componentName || diagnostics?.naming?.componentName || section.componentName)
    : section.componentName;
  const namingQuality = diagnostics?.naming?.quality || (looksMaintainableName(isBlock ? block?.id : section?.id) ? 'maintainable' : 'generic');
  const rawInteractionCount = Number(structure.interactionCount || interactionIds.length || 0);
  const rawHtmlLength = Number(structure.htmlLength || (isBlock ? block?.stats?.htmlLength : section?.stats?.htmlLength) || 0);
  const isInheritedSubviewShellTarget = isSubview && (
    ['top-bar', 'tabs', 'footer', 'floating-layer'].includes(isBlock ? block.kind : section.kind)
  );
  const interactionCount = (
    isSubview
    && isBlock
    && section?.kind === 'tabs'
    && block?.kind === 'content-block'
    && rawInteractionCount <= 1
  )
    ? 0
    : rawInteractionCount;
  const htmlLength = (
    isSubview
    && isBlock
    && section?.kind === 'tabs'
    && block?.kind === 'content-block'
    && rawHtmlLength >= 50000
  )
    ? Math.min(rawHtmlLength, 36000)
    : rawHtmlLength;
  const vibecoding = assessVibecodingTarget({
    targetType: isBlock ? 'block' : 'section',
    kind: isBlock ? block.kind : section.kind,
    renderMode: isBlock ? block.renderMode : section.renderMode,
    confidence: Number(isBlock ? block.confidence : section.confidence || 0),
    interactionCount,
    htmlLength,
    namingQuality
  });
  if (
    isSubview
    && isBlock
    && section?.kind === 'tabs'
    && block?.kind === 'content-block'
  ) {
    vibecoding.suitabilityScore = clampPercent(Number(vibecoding.suitabilityScore || 0) + 6);
    vibecoding.reasons = Array.from(new Set((vibecoding.reasons || []).concat('当前为独立子视图，适合作为本 tab 的局部改造起点')));
    if (vibecoding.suitabilityScore >= 78) {
      vibecoding.changeRisk = 'low';
    } else if (vibecoding.suitabilityScore < 58) {
      vibecoding.changeRisk = 'high';
    } else {
      vibecoding.changeRisk = 'medium';
    }
  }
  const target = {
    targetType: isBlock ? 'block' : 'section',
    sectionId: section.id,
    sectionTitle: section.title,
    sectionKind: section.kind,
    componentName: targetComponentName,
    sectionComponentName: section.componentName,
    targetId: isBlock ? block.id : section.id,
    title: isBlock ? block.title : section.title,
    kind: isBlock ? block.kind : section.kind,
    summary: isBlock ? block.summary : section.summary,
    renderMode: isBlock ? block.renderMode : section.renderMode,
    confidence: Number(isBlock ? block.confidence : section.confidence || 0),
    interactionIds,
    interactionCount,
    htmlLength,
    changeRisk: vibecoding.changeRisk || 'medium',
    suitabilityScore: Number(vibecoding.suitabilityScore || 0),
    reasons: Array.from(new Set(vibecoding.reasons || [])),
    issues: Array.isArray(diagnostics?.issues) ? diagnostics.issues : [],
    isInheritedSubviewShellTarget,
    location: {
      sectionId: section.id,
      blockId: isBlock ? block.id : null,
      componentName: targetComponentName,
      selectorHint: source.selectorHint || '',
      matchedRules,
      renderMode: isBlock ? block.renderMode : section.renderMode,
      targetKind: isBlock ? block.kind : section.kind,
      interactionIds
    }
  };

  let recommendedAction = '可作为局部 AI vibecoding 起点，优先做文案、图片与间距层修改';
  if (target.renderMode === 'fallback-body-fragment') {
    recommendedAction = '先补结构化拆分与命名，再做二次原型编辑';
  } else if (target.changeRisk === 'high') {
    recommendedAction = '暂缓直接修改，先确认交互与边界，再决定是否拆分';
  } else if (target.interactionCount > 0) {
    recommendedAction = '可编辑，但要优先保留现有交互节点与状态容器';
  } else if (target.htmlLength >= 28000) {
    recommendedAction = '适合先做局部调整，避免一次性重写整个区块';
  }

  let severity = 'low';
  if (target.renderMode === 'fallback-body-fragment' || target.changeRisk === 'high') {
    severity = 'high';
  } else if (target.issues.length >= 2 || target.confidence < 0.66) {
    severity = 'medium';
  }

  return {
    ...target,
    severity,
    recommendedAction
  };
}

function applySupplierEntryTargetBias(targets = [], options = {}) {
  if (!ENABLE_HISTORICAL_PAGE_REFINEMENTS) {
    return targets;
  }

  // Inactive by default: historical single-page adapter for old supplier-entry-list captures.
  if (String(options.pageSlug || '').trim() !== 'supplier-entry-list') {
    return targets;
  }

  return targets
    .filter((target) => !(target.sectionId === 'root-master' && target.targetId === 'menu-sider'))
    .map((target) => {
      if (!(target.sectionId === 'root-master' && target.targetId === 'query-panel')) {
        return target;
      }

      return {
        ...target,
        changeRisk: 'low',
        suitabilityScore: clampPercent(Number(target.suitabilityScore || 0) + 18),
        reasons: Array.from(new Set((target.reasons || []).concat('当前为 supplier-entry-list 的页面级优先推荐入口')))
      };
    });
}

function applyServiceNodeEditRootTabBias(targets = [], options = {}) {
  if (!ENABLE_HISTORICAL_PAGE_REFINEMENTS) {
    return targets;
  }

  // Inactive by default: historical single-page adapter for old serviceNode-edit captures.
  const pageSlug = String(options.pageSlug || '').trim();
  const view = options.view || {};
  if (
    pageSlug !== 'servicenode-edit'
    || view?.isSubview
    || view?.viewKind !== 'root-tab'
    || String(view?.baseRouteId || '').trim() !== 'serviceNode-edit'
  ) {
    return targets;
  }

  return targets.map((target) => {
    if (!(target.sectionId === 'tabs' && target.targetId === 'gift' && target.kind === 'content-block')) {
      return target;
    }

    return {
      ...target,
      changeRisk: 'low',
      suitabilityScore: clampPercent(Math.max(Number(target.suitabilityScore || 0) + 9, 72)),
      reasons: Array.from(new Set((target.reasons || []).concat('当前为 serviceNode-edit 默认 tab 视图，适合作为页面级起改入口')))
      };
    });
}

function arraysEqualExact(left = [], right = []) {
  if (left.length !== right.length) {
    return false;
  }

  return left.every((value, index) => value === right[index]);
}

function isSearchPurLeafBlockId(blockId = '') {
  const normalizedBlockId = String(blockId || '').trim();
  return /^profile-results-row-\d+$/.test(normalizedBlockId)
    || /^profile-carousel-feed-group-\d+$/.test(normalizedBlockId);
}

function isSearchPurAssemblyShellBlockId(blockId = '') {
  return [
    'profile-results-table-shell',
    'profile-carousel-shell',
    'profile-carousel-feed-shell'
  ].includes(String(blockId || '').trim());
}

function getSearchPurRefinementContext(sections = []) {
  const rootSection = (Array.isArray(sections) ? sections : []).find((section) => section?.id === SEARCH_PUR_XY_ROOT_SECTION_ID) || null;
  const refinementDiagnostics = rootSection?.diagnostics?.extraction?.secondPassRefinement || {};
  const blockMap = new Map(
    (Array.isArray(rootSection?.blocks) ? rootSection.blocks : []).map((block) => [String(block?.id || '').trim(), block])
  );

  const resultsSubtreeStatus = normalizeSearchPurSubtreeStatus(refinementDiagnostics.resultsSubtreeStatus || 'failed');
  const carouselSubtreeStatus = normalizeSearchPurSubtreeStatus(refinementDiagnostics.carouselSubtreeStatus || 'failed');
  const resultsFallbackReason = resultsSubtreeStatus === 'complete'
    ? 'none'
    : normalizeSearchPurFallbackReason(refinementDiagnostics.resultsFallbackReason || 'missing-required-block');
  const carouselFallbackReason = carouselSubtreeStatus === 'complete'
    ? 'none'
    : normalizeSearchPurFallbackReason(refinementDiagnostics.carouselFallbackReason || 'missing-required-block');

  return {
    rootSection,
    blockMap,
    resultsSubtreeStatus,
    carouselSubtreeStatus,
    resultsFallbackReason,
    carouselFallbackReason
  };
}

function applySearchPurXyTargetRules(targets = [], options = {}) {
  if (!ENABLE_HISTORICAL_PAGE_REFINEMENTS) {
    return {
      targets,
      hotspots: Array.isArray(options.editableHotspots) ? options.editableHotspots : [],
      pageSpecificDebug: null
    };
  }

  const sections = Array.isArray(options.sections) ? options.sections : [];
  const hasRefinementRoot = sections.some((section) => {
    return String(section?.id || '').trim() === SEARCH_PUR_XY_ROOT_SECTION_ID;
  });
  if (!hasRefinementRoot) {
    return {
      targets,
      hotspots: options.editableHotspots || [],
      pageSpecificDebug: null
    };
  }

  const {
    rootSection,
    blockMap,
    resultsSubtreeStatus,
    carouselSubtreeStatus,
    resultsFallbackReason,
    carouselFallbackReason
  } = getSearchPurRefinementContext(options.sections);

  const normalizedTargets = (Array.isArray(targets) ? targets : []).map((target) => {
    const targetId = String(target?.targetId || '').trim();
    const isSuppressedLeafTarget = target.targetType === 'block' && isSearchPurLeafBlockId(targetId);
    const isSuppressedShellTarget = target.targetType === 'block' && isSearchPurAssemblyShellBlockId(targetId);

    return {
      ...target,
      excludeFromRecommendedFirstEdits: Boolean(
        target?.excludeFromRecommendedFirstEdits || isSuppressedLeafTarget || isSuppressedShellTarget
      ),
      excludeFromLowRiskTargets: Boolean(
        target?.excludeFromLowRiskTargets || isSuppressedLeafTarget || isSuppressedShellTarget
      )
    };
  });

  const rootTargetIndex = normalizedTargets.findIndex((target) => {
    return target?.targetType === 'section'
      && String(target?.targetId || '').trim() === SEARCH_PUR_XY_ROOT_SECTION_ID;
  });
  const rootTarget = rootTargetIndex >= 0 ? normalizedTargets[rootTargetIndex] : null;
  const tableShell = blockMap.get('profile-results-table-shell') || null;
  const carouselShell = blockMap.get('profile-carousel-shell') || null;
  const feedShell = blockMap.get('profile-carousel-feed-shell') || null;
  const bannerBlock = blockMap.get('profile-carousel-banner') || null;
  const rootOwnsInteractions = (
    (Array.isArray(rootSection?.interactionIds) && rootSection.interactionIds.length > 0)
    || Number(rootTarget?.interactionCount || 0) > 0
  );
  const shellSizeGuardSatisfied = [tableShell, carouselShell, feedShell].every((block) => {
    return block && Number(block?.stats?.htmlLength || 0) < 35000;
  });
  const carouselShellLegacySemanticsPresent = (
    !carouselShell
    || Number(carouselShell?.stats?.htmlLength || 0) >= 35000
    || (Array.isArray(carouselShell?.interactionIds) && carouselShell.interactionIds.length > 0)
  );
  const ownerBlocksPresent = Boolean(feedShell && bannerBlock);
  const ownerInteractionMatch = ownerBlocksPresent
    && arraysEqualExact(
      Array.isArray(feedShell?.interactionIds) ? feedShell.interactionIds : [],
      ['root-supplier-sources-web-profile-carousel']
    )
    && arraysEqualExact(
      Array.isArray(bannerBlock?.interactionIds) ? bannerBlock.interactionIds : [],
      ['root-supplier-sources-web-profile-carousel-2']
    )
    && arraysEqualExact(
      Array.isArray(tableShell?.interactionIds) ? tableShell.interactionIds : [],
      []
    )
    && arraysEqualExact(
      Array.isArray(carouselShell?.interactionIds) ? carouselShell.interactionIds : [],
      []
    );

  let biasApplied = false;
  let biasSkippedReason = 'none';
  let finalTargets = normalizedTargets;

  if (resultsSubtreeStatus !== 'complete' || carouselSubtreeStatus !== 'complete') {
    biasSkippedReason = 'subtree-not-complete';
  } else if (rootOwnsInteractions) {
    biasSkippedReason = 'root-still-owns-interactions';
  } else if (blockMap.has('profile-results')) {
    biasSkippedReason = 'legacy-profile-results-present';
  } else if (carouselShellLegacySemanticsPresent) {
    biasSkippedReason = 'legacy-carousel-shell-semantics-present';
  } else if (!ownerBlocksPresent) {
    biasSkippedReason = 'owner-block-missing';
  } else if (!ownerInteractionMatch) {
    biasSkippedReason = 'owner-interaction-mismatch';
  } else if (!shellSizeGuardSatisfied) {
    biasSkippedReason = 'root-prebias-still-high-structural';
  } else if (!rootTarget || rootTarget.renderMode === 'fallback-body-fragment' || Number(rootTarget.confidence || 0) < 0.66) {
    biasSkippedReason = 'root-prebias-still-high-structural';
  } else if (rootTarget.severity !== 'high') {
    biasSkippedReason = 'root-prebias-not-high';
  } else {
    biasApplied = true;
    finalTargets = normalizedTargets.map((target, targetIndex) => {
      if (targetIndex !== rootTargetIndex) {
        return target;
      }

      const existingIssues = Array.isArray(target.issues) ? target.issues : [];
      const retainedIssues = existingIssues.filter((issue) => !/基础交互/.test(String(issue || '')));
      const shellIssue = '当前为 layout shell 级根区块，建议仅在边界内调整';

      return {
        ...target,
        changeRisk: 'medium',
        severity: 'medium',
        suitabilityScore: 64,
        reasons: Array.from(new Set((target.reasons || []).concat('当前为 supplier-sources layout shell，交互 ownership 已下沉'))),
        issues: Array.from(new Set(retainedIssues.concat(shellIssue))),
        recommendedAction: '当前适合作为 layout shell 级边界整理目标，不建议直接整段重写'
      };
    });
  }

  const pageSpecificDebug = {
    resultsSubtreeStatus,
    carouselSubtreeStatus,
    resultsFallbackReason: resultsSubtreeStatus === 'complete' ? 'none' : resultsFallbackReason,
    carouselFallbackReason: carouselSubtreeStatus === 'complete' ? 'none' : carouselFallbackReason,
    biasApplied,
    biasSkippedReason: normalizeSearchPurBiasSkippedReason(biasApplied ? 'none' : biasSkippedReason)
  };

  return {
    targets: finalTargets,
    hotspots: Array.isArray(options.editableHotspots) ? options.editableHotspots : [],
    pageSpecificDebug
  };
}

function riskRank(changeRisk = 'medium') {
  return {
    low: 0,
    medium: 1,
    high: 2
  }[changeRisk] ?? 1;
}

function severityRank(severity = 'medium') {
  return {
    high: 0,
    medium: 1,
    low: 2
  }[severity] ?? 1;
}

function compareRecommendedTargets(left, right) {
  if (left.targetType !== right.targetType) {
    return left.targetType === 'block' ? -1 : 1;
  }
  if (left.changeRisk !== right.changeRisk) {
    return riskRank(left.changeRisk) - riskRank(right.changeRisk);
  }
  if (left.suitabilityScore !== right.suitabilityScore) {
    return right.suitabilityScore - left.suitabilityScore;
  }
  if (left.interactionCount !== right.interactionCount) {
    return left.interactionCount - right.interactionCount;
  }
  return left.htmlLength - right.htmlLength;
}

function compareProblemAreas(left, right) {
  if (left.severity !== right.severity) {
    return severityRank(left.severity) - severityRank(right.severity);
  }
  if (left.changeRisk !== right.changeRisk) {
    return riskRank(right.changeRisk) - riskRank(left.changeRisk);
  }
  if (left.issues.length !== right.issues.length) {
    return right.issues.length - left.issues.length;
  }
  return left.suitabilityScore - right.suitabilityScore;
}

function hasInteractiveSectionSurface(section = {}) {
  if (Array.isArray(section?.interactionIds) && section.interactionIds.length) {
    return true;
  }

  return Array.isArray(section?.blocks)
    && section.blocks.some((block) => Array.isArray(block?.interactionIds) && block.interactionIds.length);
}

function isStructurallyDecomposedSection(section = {}) {
  const blockCount = Array.isArray(section.blocks) ? section.blocks.length : 0;
  return blockCount >= 2 || isPromotedBlockSection(section);
}

function buildEditabilityScoreDrivers({
  totalSections,
  structuredSectionCount,
  blockSectionCount,
  promotedSectionCount,
  totalBlocks,
  fallbackSectionCount,
  oversizedUnsplitSectionCount,
  lowConfidenceSectionCount,
  interactions,
  stableInteractionCount = 0,
  fallbackInteractionCount = 0,
  blockNameQualityCount,
  blockList
}) {
  const positive = [];
  const negative = [];

  if (structuredSectionCount > 0) {
    positive.push({
      key: 'structured-sections',
      weight: structuredSectionCount === totalSections ? 'high' : 'medium',
      summary: `${structuredSectionCount}/${totalSections || 0} 个 section 已采用结构化组件输出`
    });
  }

  if (blockSectionCount > 0 || totalBlocks > 0 || promotedSectionCount > 0) {
    positive.push({
      key: 'block-decomposition',
      weight: totalBlocks >= 6 || promotedSectionCount >= 4 ? 'high' : 'medium',
      summary: promotedSectionCount > 0
        ? `${promotedSectionCount} 个稳定 block 已提升为独立 section，${blockSectionCount} 个 section 继续拆成 ${totalBlocks} 个 block`
        : `${blockSectionCount} 个 section 已继续拆成 ${totalBlocks} 个 block`
    });
  }

  if (stableInteractionCount > 0) {
    positive.push({
      key: 'interaction-protocol',
      weight: 'medium',
      summary: `已保留 ${stableInteractionCount} 个稳定基础交互协议`
    });
  }

  if (blockList.length > 0 && blockNameQualityCount >= Math.ceil(blockList.length * 0.75)) {
    positive.push({
      key: 'maintainable-naming',
      weight: 'medium',
      summary: '多数 block 命名具备业务语义，便于 AI 精准定位'
    });
  }

  if (oversizedUnsplitSectionCount > 0) {
    negative.push({
      key: 'oversized-unsplit-sections',
      weight: oversizedUnsplitSectionCount >= 2 ? 'high' : 'medium',
      summary: `仍有 ${oversizedUnsplitSectionCount} 个超大 section 未拆分`
    });
  }

  if (fallbackSectionCount > 0) {
    negative.push({
      key: 'fallback-sections',
      weight: fallbackSectionCount >= Math.max(2, Math.ceil(totalSections / 2)) ? 'high' : 'medium',
      summary: `仍有 ${fallbackSectionCount} 个 section 处于 fallback 输出`
    });
  }

  if (lowConfidenceSectionCount > 0) {
    negative.push({
      key: 'low-confidence-sections',
      weight: lowConfidenceSectionCount >= 2 ? 'high' : 'medium',
      summary: `仍有 ${lowConfidenceSectionCount} 个低置信度 section`
    });
  }

  if (!stableInteractionCount && fallbackInteractionCount > 0) {
    negative.push({
      key: 'fallback-interactions-only',
      weight: 'medium',
      summary: `当前仅提取到 ${fallbackInteractionCount} 个 fallback 级交互协议`
    });
  } else if (!interactions.length) {
    negative.push({
      key: 'missing-interactions',
      weight: 'medium',
      summary: '当前页面未提取到稳定基础交互协议'
    });
  }

  return {
    positive,
    negative
  };
}

function createEditabilityReport(sections = [], interactions = [], confidence = {}, options = {}) {
  const view = options.view || {};
  const isSubview = Boolean(view?.isSubview);
  const pageSlug = String(options.pageSlug || '').trim();
  const totalSections = sections.length;
  const totalBlocks = sections.reduce((sum, section) => sum + (Array.isArray(section.blocks) ? section.blocks.length : 0), 0);
  const structuredSectionCount = sections.filter((section) => section.renderMode !== 'fallback-body-fragment').length;
  const blockSectionCount = sections.filter((section) => Array.isArray(section.blocks) && section.blocks.length >= 2).length;
  const promotedSectionCount = sections.filter((section) => isPromotedBlockSection(section)).length;
  const fallbackSectionCount = sections.filter((section) => section.renderMode === 'fallback-body-fragment').length;
  const lowConfidenceSectionCount = sections.filter((section) => Number(section.confidence || 0) < 0.6).length;
  const oversizedSectionCount = sections.filter((section) => Number(section?.stats?.htmlLength || 0) >= 50000).length;
  const oversizedUnsplitSectionCount = sections.filter((section) => {
    const htmlLength = Number(section?.stats?.htmlLength || 0);
    return htmlLength >= 50000 && !isStructurallyDecomposedSection(section);
  }).length;
  const editableHotspots = sections.flatMap((section) => {
    if (Array.isArray(section.blocks) && section.blocks.length) {
      return section.blocks.map((block) => `${section.id}.${block.id}`);
    }

    if (section.renderMode !== 'fallback-body-fragment') {
      return [section.id];
    }

    return [];
  });
  const editableHotspotCount = editableHotspots.length;
  const interactiveSurfaceCount = sections.filter((section) => hasInteractiveSectionSurface(section)).length;
  const stableInteractionCount = Array.isArray(interactions)
    ? interactions.filter((interaction) => String(interaction?.protocolLevel || 'full') !== 'fallback').length
    : 0;
  const fallbackInteractionCount = Array.isArray(interactions)
    ? interactions.filter((interaction) => String(interaction?.protocolLevel || 'full') === 'fallback').length
    : 0;
  const sectionNameQualityCount = sections.filter((section) => looksMaintainableName(section.id)).length;
  const blockList = sections.flatMap((section) => Array.isArray(section.blocks) ? section.blocks : []);
  const blockNameQualityCount = blockList.filter((block) => looksMaintainableName(block.id)).length;
  const sectionTargets = sections.map((section) => buildEditabilityTarget(section, null, { view }));
  const blockTargets = sections.flatMap((section) => (
    Array.isArray(section.blocks)
      ? section.blocks.map((block) => buildEditabilityTarget(section, block, { view }))
      : []
  ));
  const allTargets = applySupplierEntryTargetBias(blockTargets.concat(sectionTargets), {
    pageSlug,
    view
  });
  const preBiasAdjustedTargets = applyServiceNodeEditRootTabBias(allTargets, {
    pageSlug,
    view
  });
  const searchPurTargetRules = applySearchPurXyTargetRules(preBiasAdjustedTargets, {
    pageSlug,
    sections,
    interactions,
    editableHotspots
  });
  const adjustedTargets = searchPurTargetRules.targets;
  const finalEditableHotspots = searchPurTargetRules.pageSpecificDebug
    ? searchPurTargetRules.hotspots
    : editableHotspots.slice(0, 12);

  const structureScore = clampPercent(
    (toPercentRatio(structuredSectionCount, totalSections, 0) * 0.65)
    + (toPercentRatio(blockSectionCount + promotedSectionCount, totalSections, totalSections ? 0 : 0) * 0.25)
    + (fallbackSectionCount === 0 && totalSections ? 10 : 0)
  );

  const decomposedOversizedCount = oversizedSectionCount - oversizedUnsplitSectionCount;
  const decompositionScore = clampPercent(
    (toPercentRatio(decomposedOversizedCount, oversizedSectionCount, 75) * 0.65)
    + (clampPercent((Math.min(totalBlocks, 18) / 18) * 100) * 0.35)
  );

  const maintainabilityScore = clampPercent(
    (toPercentRatio(sectionNameQualityCount, totalSections, 0) * 0.45)
    + (toPercentRatio(blockNameQualityCount, blockList.length, 70) * 0.35)
    + ((lowConfidenceSectionCount === 0 && totalSections) ? 20 : Math.max(0, 20 - (lowConfidenceSectionCount * 10)))
  );

  const stabilityScore = clampPercent(
    ((Number(confidence.page) || 0) * 100 * 0.7)
    + (toPercentRatio(interactiveSurfaceCount, Math.max(totalSections, 1), interactions.length ? 0 : 70) * 0.15)
    + (toPercentRatio(editableHotspotCount, Math.max(totalSections, 1), 0) * 0.15)
  );

  const score = Number(clampPercent(
    (structureScore * 0.35)
    + (decompositionScore * 0.35)
    + (maintainabilityScore * 0.2)
    + (stabilityScore * 0.1)
  ).toFixed(2));

  const blockers = [];
  if (!totalSections) {
    blockers.push('no-sections');
  }
  if (!editableHotspotCount) {
    blockers.push('no-editable-hotspots');
  }
  if (totalSections === 1 && oversizedUnsplitSectionCount >= 1) {
    blockers.push('single-giant-fragment');
  }
  if (fallbackSectionCount >= Math.max(2, Math.ceil(totalSections / 2)) && totalSections > 1) {
    blockers.push('fallback-pressure');
  }

  const warnings = [];
  if (oversizedUnsplitSectionCount > 0) {
    warnings.push(`仍有 ${oversizedUnsplitSectionCount} 个超大区块未继续拆分`);
  }
  if (lowConfidenceSectionCount > 0) {
    warnings.push(`仍有 ${lowConfidenceSectionCount} 个低置信度区块`);
  }
  if (blockList.length >= 4 && toPercentRatio(blockNameQualityCount, blockList.length, 0) < 75) {
    warnings.push('部分 block 命名仍偏通用，后续 AI 编辑定位成本偏高');
  }
  if (!stableInteractionCount && fallbackInteractionCount > 0) {
    warnings.push(`当前仅提取到 ${fallbackInteractionCount} 个 fallback 级交互协议`);
  } else if (!interactions.length) {
    warnings.push('当前页面未提取到稳定基础交互协议');
  }

  let status = 'weak';
  if (!blockers.length && score >= 78) {
    status = 'strong';
  } else if (score >= 58 && blockers.length < 2) {
    status = 'workable';
  } else if (blockers.length >= 2 || score < 45) {
    status = 'blocked';
  }

  const suggestedNextActions = [];
  if (oversizedUnsplitSectionCount > 0) {
    suggestedNextActions.push('继续把超大 section 拆成 block 级结构，避免后续 AI 只能修改整段 fragment');
  }
  if (lowConfidenceSectionCount > 0) {
    suggestedNextActions.push('优先复核低置信度 section 的边界和命名，提升后续 AI 二次编辑稳定性');
  }
  if (blockList.length >= 4 && toPercentRatio(blockNameQualityCount, blockList.length, 0) < 75) {
    suggestedNextActions.push('优化 block 命名，让标题和 id 更贴近业务语义而不是 DOM 语义');
  }
  if (!stableInteractionCount && fallbackInteractionCount > 0) {
    suggestedNextActions.push('继续把 fallback 级交互协议提升为稳定协议，避免 AI 把兜底协议误判为完整选项恢复');
  } else if (!interactions.length) {
    suggestedNextActions.push('补充 tabs、dropdown、dismiss、carousel 等基础交互识别与回放');
  }

  const recommendedFirstEdits = adjustedTargets
    .filter((target) => (
      target.renderMode !== 'fallback-body-fragment'
      && target.changeRisk !== 'high'
      && target.suitabilityScore >= 68
      && !target.excludeFromRecommendedFirstEdits
      && !target.isInheritedSubviewShellTarget
      && !['top-bar', 'footer', 'floating-layer', 'tabs', 'form'].includes(target.kind)
    ))
    .sort(compareRecommendedTargets)
    .slice(0, 5);

  const lowRiskTargets = adjustedTargets
    .filter((target) => (
      target.renderMode !== 'fallback-body-fragment'
      && target.changeRisk !== 'high'
      && target.suitabilityScore >= 68
      && !target.excludeFromLowRiskTargets
      && !target.isInheritedSubviewShellTarget
      && !['top-bar', 'footer', 'floating-layer', 'tabs', 'form'].includes(target.kind)
    ))
    .sort(compareRecommendedTargets)
    .slice(0, 8);

  const avoidForNow = adjustedTargets
    .filter((target) => (
      !target.isInheritedSubviewShellTarget
      && (
      target.renderMode === 'fallback-body-fragment'
      || target.changeRisk === 'high'
      || (target.kind === 'review-feed' && target.htmlLength >= 80000)
      || ['top-bar', 'footer', 'floating-layer', 'tabs', 'form'].includes(target.kind)
      )
    ))
    .sort(compareProblemAreas)
    .slice(0, 8);

  const problemAreas = adjustedTargets
    .filter((target) => (
      !target.isInheritedSubviewShellTarget
      && (
        target.issues.length
        || target.renderMode === 'fallback-body-fragment'
        || target.changeRisk === 'high'
        || target.confidence < 0.66
      )
    ))
    .sort(compareProblemAreas)
    .slice(0, 12);

  const scoreDrivers = buildEditabilityScoreDrivers({
    totalSections,
    structuredSectionCount,
    blockSectionCount,
    promotedSectionCount,
    totalBlocks,
    fallbackSectionCount,
      oversizedUnsplitSectionCount,
      lowConfidenceSectionCount,
      interactions,
      stableInteractionCount,
      fallbackInteractionCount,
      blockNameQualityCount,
      blockList
    });

  return {
    score,
    normalizedScore: Number((score / 100).toFixed(4)),
    status,
    editableHotspotCount,
    hotspots: finalEditableHotspots,
    blockers,
    warnings,
    suggestedNextActions,
    locationDimensions: [
      {
        key: 'sectionId',
        label: 'Section',
        description: '定位到页面结构层级中的 section'
      },
      {
        key: 'targetId',
        label: 'Target',
        description: '定位到具体 section 或 block'
      },
      {
        key: 'componentName',
        label: 'Component',
        description: '定位到生成后的组件文件'
      },
      {
        key: 'selectorHint',
        label: 'Selector Hint',
        description: '定位到原始 DOM 来源线索'
      },
      {
        key: 'matchedRules',
        label: 'Matched Rules',
        description: '说明该目标命中了哪些识别规则'
      },
      {
        key: 'interactionIds',
        label: 'Interactions',
        description: '定位到与该区块绑定的交互协议'
      }
    ],
    problemAreas,
    recommendedFirstEdits,
    lowRiskTargets,
    avoidForNow,
    pageSpecificDebug: searchPurTargetRules.pageSpecificDebug,
    scoreDrivers,
    breakdown: {
      structure: Number(structureScore.toFixed(2)),
      decomposition: Number(decompositionScore.toFixed(2)),
      maintainability: Number(maintainabilityScore.toFixed(2)),
      stability: Number(stabilityScore.toFixed(2))
    },
    metrics: {
      totalSections,
      structuredSectionCount,
      blockSectionCount,
      promotedSectionCount,
      totalBlocks,
      fallbackSectionCount,
      oversizedSectionCount,
      oversizedUnsplitSectionCount,
      lowConfidenceSectionCount,
      interactionCount: interactions.length,
      stableInteractionCount,
      fallbackInteractionCount,
      interactiveSurfaceCount,
      sectionNameQualityCount,
      blockNameQualityCount,
      recommendedFirstEditCount: recommendedFirstEdits.length,
      lowRiskTargetCount: lowRiskTargets.length,
      avoidForNowCount: avoidForNow.length,
      problemAreaCount: problemAreas.length
    }
  };
}

async function buildPageIR(input = {}) {
  const {
    captureDir,
    localizedHtml,
    pageTitle,
    pageUrl,
    metadata = {},
    assetReport = {},
    captureQuality = {},
    restoreSlug = '',
    restoreRelativeDir = '',
    captureVariant = null,
    onProgress
  } = input;
  let effectiveAssetReport = assetReport;
  let effectiveCaptureQuality = captureQuality;
  let effectiveMetadata = metadata;

  if (captureDir) {
    const captureMetaPath = path.join(captureDir, 'capture.meta.json');
    if (await fs.pathExists(captureMetaPath)) {
      try {
        const captureMeta = await fs.readJson(captureMetaPath);
        if ((!effectiveAssetReport || !Object.keys(effectiveAssetReport).length) && captureMeta?.assetReport) {
          effectiveAssetReport = captureMeta.assetReport;
        }
        if ((!effectiveCaptureQuality || !Object.keys(effectiveCaptureQuality).length) && captureMeta?.captureQuality) {
          effectiveCaptureQuality = captureMeta.captureQuality;
        }
        if (captureMeta?.viewport && !effectiveMetadata?.viewport) {
          effectiveMetadata = {
            ...effectiveMetadata,
            viewport: captureMeta.viewport
          };
        }
        if (captureMeta?.capturedAt && !effectiveMetadata?.capturedAt) {
          effectiveMetadata = {
            ...effectiveMetadata,
            capturedAt: captureMeta.capturedAt
          };
        }
      } catch (_error) {
        // Keep the explicit input values if capture.meta.json is malformed or unavailable.
      }
    }
  }

  const relativePageDir = normalizePathForUrl(restoreRelativeDir || restoreSlug || buildPageSlug(pageUrl, pageTitle));
  const pageSlug = sanitizeSegment(relativePageDir.replace(/[\\/]+/g, '-')) || sanitizeSegment(restoreSlug || buildPageSlug(pageUrl, pageTitle));
  const view = createViewDefinition({
    relativePageDir,
    pageSlug,
    pageTitle,
    metadata: effectiveMetadata,
    captureVariant
  });
  const pageAssetSlug = view.assetSlug || pageSlug;
  const assetOwnerRouteId = view.baseRouteId || relativePageDir;

  onProgress?.({
    phase: 'restore',
    message: '正在生成页面协议包...',
    currentItemTitle: '构建 PageIR',
    detail: '正在提取页面结构、资源和样式'
  });

  const htmlContent = localizedHtml || await fs.readFile(path.join(captureDir, 'index.html'), 'utf8');
  const assets = await collectCaptureAssets(captureDir, pageAssetSlug, relativePageDir, assetOwnerRouteId);
  const generationAssetMap = buildGenerationAssetMap(assets);
  const pageOrigin = effectiveMetadata?.url || pageUrl || '';
  const failedAssetUrls = new Set(
    Array.isArray(effectiveAssetReport?.failedUrls)
      ? effectiveAssetReport.failedUrls
          .map((value) => normalizeAbsoluteReference(value, pageOrigin))
          .filter(Boolean)
      : []
  );
  const preparedHtmlResult = prepareLocalizedHtmlForGeneration({
    html: htmlContent,
    metadata: effectiveMetadata,
    assetMap: generationAssetMap,
    options: {
      enableProxyFallback: true,
      pageOrigin,
      failedAssetUrls
    }
  });
  const $ = cheerio.load(preparedHtmlResult.html || htmlContent, { decodeEntities: false });
  if (preparedHtmlResult.maxCapturedScrollTop > 0) {
    $('body').attr('data-restore-captured-max-scroll-top', String(Math.round(preparedHtmlResult.maxCapturedScrollTop)));
  }
  const viewport = {
    width: Number(effectiveMetadata?.viewport?.width) || 0,
    height: Number(effectiveMetadata?.viewport?.height) || 0
  };
  const { byFileName, localAssetReferenceMap, previewAssetReferenceMap } = buildAssetReferenceMaps(assets);
  const siteAdapter = resolveSiteAdapterByUrl(pageUrl || metadata?.url || '');
  const sourceCssText = await collectStyleText({
    $,
    captureDir,
    metadata: effectiveMetadata,
    explicitMap: localAssetReferenceMap,
    byFileName
  });
  const previewCssText = await collectStyleText({
    $,
    captureDir,
    metadata: effectiveMetadata,
    explicitMap: previewAssetReferenceMap,
    byFileName
  });

  $(NOISE_SELECTORS).remove();
  $('style, link[rel~="stylesheet"], meta, title').remove();

  const archetype = classifyPage({ $, metadata });
  const { sections: extractedSections, interactions } = buildSections({
    $,
    siteAdapter,
    explicitLocalMap: localAssetReferenceMap,
    explicitPreviewMap: previewAssetReferenceMap,
    byFileName,
    pageSlug
  });
  const {
    sections,
    pageContextWrappers
  } = optimizeSharedPageContextWrappers(extractedSections);
  let structuralResult = applyStructuralDecomposition(sections);
  let effectiveSections = structuralResult.sections;
  const semanticSchemas = extractSemanticSchemas({ sections: effectiveSections });
  structuralResult = compactEditRouteLiteStructuralResult(structuralResult, {
    pageSlug,
    semanticSchemas
  });
  effectiveSections = structuralResult.sections;
  const confidence = createConfidenceBreakdown(effectiveCaptureQuality, effectiveMetadata, effectiveSections, interactions, sourceCssText);
  const bodyAttributes = $('body').get(0)?.attribs || {};
  const previewHeadTemplate = [
    '<meta charset="utf-8" />',
    '<meta name="viewport" content="width=device-width, initial-scale=1" />',
    `<title>${escapeHtml(pageTitle || $('title').first().text() || pageSlug)}</title>`,
    `<base href="${PREVIEW_STATIC_ROOT}/${normalizePathForUrl(relativePageDir)}/" />`,
    '__PROTOREC_GENERATED_STYLE__'
  ].join('\n');
  const degradedSections = effectiveSections
    .filter((section) => section.renderMode === 'fallback-body-fragment' || section.confidence < 0.6)
    .map((section) => ({
      id: section.id,
      kind: section.kind,
      renderMode: section.renderMode,
      confidence: section.confidence
    }));
  const editability = createEditabilityReport(effectiveSections, interactions, confidence, { view, pageSlug });
  const qa = evaluateQAGate({
    pageConfidence: confidence.page,
    degradedSections,
    editability,
    interactions
  });
  const readyState = qa.readyState || resolveReadyState(confidence.page, degradedSections, editability, interactions);

  const pageMeta = {
    id: pageSlug,
    routeId: relativePageDir,
    baseRouteId: view.baseRouteId,
    title: pageTitle || $('title').first().text() || pageSlug,
    archetype,
    generationMode: GENERATION_MODE,
    protocolVersion: PROTOCOL_VERSION,
    sourceUrl: pageUrl,
    pageConfidence: confidence.page,
    editabilityScore: editability.score,
    editabilityStatus: editability.status,
    qaStatus: qa.status,
    releaseDecision: qa.releaseDecision,
    readyState,
    viewId: view.viewId,
    viewLabel: view.viewLabel,
    preservedInteractions: interactions.map((item) => {
      const protocolLevel = String(item?.protocolLevel || 'full');
      return `${item.kind}${protocolLevel === 'fallback' ? '[fallback]' : ''}:${item.label}`;
    })
  };

  return {
    protocolVersion: PROTOCOL_VERSION,
    pageSlug,
    assetSlug: pageAssetSlug,
    routeId: relativePageDir,
    baseRouteId: view.baseRouteId,
    pageTitle: pageMeta.title,
    pageMeta,
    sourceUrl: pageUrl,
    capturedAt: metadata?.capturedAt || new Date().toISOString(),
    capturedAt: effectiveMetadata?.capturedAt || new Date().toISOString(),
    generationMode: GENERATION_MODE,
    viewport,
    archetype,
    sections: effectiveSections,
    sectionOrder: effectiveSections.map((section) => section.id),
    interactions,
    pageContextWrappers,
    sectionMap: structuralResult.sectionMap,
    structuralDecomposition: structuralResult.structuralDecomposition,
    semanticSchemas,
    view,
    degradedSections,
    editability,
    qa,
    readyState,
    confidence,
    assets,
    assetSummary: {
      attemptedAssetCount: Number(effectiveAssetReport?.attemptedAssetCount) || assets.length,
      downloadedAssetCount: Number(effectiveAssetReport?.downloadedAssetCount) || assets.length,
      failedAssetCount: Number(effectiveAssetReport?.failedAssetCount) || 0
    },
    bodyAttributes: {
      className: String(bodyAttributes.class || ''),
      style: String(bodyAttributes.style || ''),
      dataAttributes: buildPreviewBodyDataAttributes(bodyAttributes)
    },
    sourceCssText,
    previewCssText,
    previewHeadTemplate,
    previewBodyMarkup: '',
    notes: {
      sectionExtraction: 'semantic-boundary-splitting+block-decomposition',
      assetBinding: 'relative-page-assets',
      cssMode: 'layered-generated-and-source-styles',
      interactionMode: 'declarative-dom-markers',
      editabilityMode: 'pm-ai-vibecoding-gate-v1'
    }
  };
}

module.exports = {
  buildPageIR,
  createEditabilityReport
};
