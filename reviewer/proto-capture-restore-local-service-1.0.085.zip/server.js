const express = require('express');
const fs = require('fs-extra');
const path = require('path');
const cors = require('cors');
const axios = require('axios');
const esbuild = require('esbuild');
const React = require('react');
const ReactDOMServer = require('react-dom/server');
const Module = require('module');
const cheerio = require('cheerio');

const {
  META_ROOT,
  PAGES_ROOT,
  PREVIEW_STATIC_ROOT,
  PROTOTYPES_ROOT,
  PROTOTYPE_PREVIEW_STATIC_ROOT,
  PROJECT_ROOT
} = require('./generator/config');
const { sanitizeExtractedSourceCss } = require('./generator/css-sanitizer');
const { generatePagePackage } = require('./generator');
const { downloadAssets } = require('./scripts/assets_dl');
const { ensureCanvasSnapshotFallback } = require('./scripts/canvas_snapshot_fallback');
const { cleanAndSemanticize } = require('./scripts/cleaner');

const SERVICE_ROOT = __dirname;
const DEFAULT_WORKSPACE_ROOT = path.join(SERVICE_ROOT, 'workspace');
const WORKSPACE_ROOT = path.resolve(process.env.PROTO_CAPTURE_RESTORE_WORKSPACE_ROOT || DEFAULT_WORKSPACE_ROOT);
const CAPTURE_ROOT = path.join(WORKSPACE_ROOT, 'temp_proto');
const RESTORE_ROOT = PAGES_ROOT;
const DEFAULT_PORT = 3001;
const GENERIC_RESTORE_SEGMENTS = new Set(['index', 'home', 'page', 'list', 'detail', 'view', 'main']);
const HEALTH_PROTOCOL_VERSION = 2;
const KEEP_CAPTURE_ARTIFACTS = true;
const PROCESS_STARTED_AT = Date.now();
const MULTI_TAB_RESTORE_SESSIONS = new Map();
const SAVE_TASKS = new Map();

function maybeInjectSaveFailure(phase) {
  const configuredPhase = String(process.env.PROTOREC_SAVE_FAILURE_INJECTION_PHASE || '').trim();
  if (!configuredPhase || configuredPhase !== phase) {
    return;
  }

  throw new Error(`Injected save failure at ${phase}`);
}

function loadLatestRestoreModule() {
  delete require.cache[require.resolve('./scripts/restore')];
  return require('./scripts/restore');
}

function loadLatestInteractionModule() {
  delete require.cache[require.resolve('./generator/emit-page-interactions')];
  return require('./generator/emit-page-interactions');
}

function createSaveTask(runId) {
  const controller = new AbortController();
  const task = {
    runId,
    status: 'running',
    phase: 'save',
    message: '正在同步资源与代码...',
    currentItemTitle: '',
    progressText: '',
    detail: '',
    reason: '',
    controller,
    projectDir: '',
    restoreDir: '',
    metadata: {},
    captureVariant: null,
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  SAVE_TASKS.set(runId, task);
  return task;
}

function getSaveTask(runId) {
  const normalizedRunId = String(runId || '').trim();
  return normalizedRunId ? SAVE_TASKS.get(normalizedRunId) || null : null;
}

function updateSaveTask(runId, patch = {}) {
  const task = getSaveTask(runId);
  if (!task) {
    return null;
  }

  Object.assign(task, patch, { updatedAt: Date.now() });
  return task;
}

function cancelSaveTask(runId, reason = 'manual') {
  const task = getSaveTask(runId);
  if (!task) {
    return null;
  }

  task.reason = reason;
  task.status = 'canceled';
  task.message = reason === 'popup_closed' ? '已因关闭弹窗取消当前同步' : '已取消当前同步';
  task.updatedAt = Date.now();
  if (!task.controller.signal.aborted) {
    task.controller.abort(new Error(task.message));
  }
  return task;
}

function clearSaveTaskLater(runId) {
  if (!runId) {
    return;
  }

  setTimeout(() => {
    SAVE_TASKS.delete(runId);
  }, 60 * 1000);
}

function throwIfTaskCanceled(task) {
  if (!task) {
    return;
  }

  if (task.controller.signal.aborted) {
    const reasonMessage = task.reason === 'popup_closed' ? '已因关闭弹窗取消当前同步' : '当前同步已取消';
    const error = new Error(reasonMessage);
    error.name = 'AbortError';
    throw error;
  }
}

function createTaskProgressReporter(runId) {
  return (patch = {}) => {
    const task = updateSaveTask(runId, patch);
    throwIfTaskCanceled(task);
    return task;
  };
}

const GLOBAL_PREVIEW_PLACEHOLDER_STYLE = `<style>
input::placeholder { color: #bfbfbf !important; -webkit-text-fill-color: #bfbfbf !important; opacity: 1 !important; }
textarea::placeholder { color: #bfbfbf !important; -webkit-text-fill-color: #bfbfbf !important; opacity: 1 !important; }
input::-webkit-input-placeholder { color: #bfbfbf !important; -webkit-text-fill-color: #bfbfbf !important; opacity: 1 !important; }
textarea::-webkit-input-placeholder { color: #bfbfbf !important; -webkit-text-fill-color: #bfbfbf !important; opacity: 1 !important; }
input::-moz-placeholder { color: #bfbfbf !important; opacity: 1 !important; }
textarea::-moz-placeholder { color: #bfbfbf !important; opacity: 1 !important; }
.hammer-input::placeholder { color: #bfbfbf !important; -webkit-text-fill-color: #bfbfbf !important; opacity: 1 !important; }
.hammer-input::-webkit-input-placeholder { color: #bfbfbf !important; -webkit-text-fill-color: #bfbfbf !important; opacity: 1 !important; }
.hammer-input::-moz-placeholder { color: #bfbfbf !important; opacity: 1 !important; }
.ant-input::placeholder { color: #bfbfbf !important; -webkit-text-fill-color: #bfbfbf !important; opacity: 1 !important; }
.ant-input::-webkit-input-placeholder { color: #bfbfbf !important; -webkit-text-fill-color: #bfbfbf !important; opacity: 1 !important; }
.ant-input::-moz-placeholder { color: #bfbfbf !important; opacity: 1 !important; }
</style>`;

const GLOBAL_PREVIEW_SUBVIEW_SCROLL_STYLE = `<style>
html[data-protorec-preview-kind="subview"],
body[data-protorec-preview-kind="subview"] {
  overflow: auto !important;
  height: auto !important;
  min-height: 100vh !important;
}

body[data-protorec-preview-kind="subview"] {
  overflow-x: auto !important;
  overflow-y: auto !important;
}
</style>`;

const GLOBAL_PREVIEW_MEDIA_RECOVERY_STYLE = `<style>
img.css-9pa8cd[data-restore-image-fallback-bound="true"],
[data-restore-rn-image-hydrated="true"] > img.css-9pa8cd {
  opacity: 1 !important;
  visibility: visible !important;
  z-index: 1 !important;
  position: absolute !important;
}
</style>`;

const GLOBAL_PREVIEW_ROOT_LAYOUT_STYLE = `<style>
body[data-protorec-preview-kind="page"] {
  min-height: 100vh !important;
}

body[data-protorec-preview-kind="page"] #root {
  position: relative !important;
  width: 100% !important;
  min-height: 100vh !important;
}

body[data-protorec-preview-kind="page"] .hammer-app {
  min-height: 100vh !important;
}
</style>`;

const GLOBAL_PREVIEW_MENU_SCROLLBAR_STYLE = `<style>
body[data-protorec-preview-kind="page"] .hammer-app .hammer-pro-layout-menu-mix-column .ms-container {
  position: relative !important;
}

body[data-protorec-preview-kind="page"] .hammer-app .hammer-pro-layout-menu-mix-column .ms-track-box {
  display: none !important;
}
</style>`;

const app = express();
app.use(cors());
app.use(express.json({ limit: '150mb' }));

function applyLocalPreviewNoStoreHeaders(res) {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
}

function encodeInlineScriptPayload(scriptContent) {
  return Buffer.from(String(scriptContent || ''), 'utf8').toString('base64');
}

function buildInlineScriptBootstrap(scripts = []) {
  const payloads = scripts
    .map((script) => ({
      marker: String(script?.marker || '').trim(),
      payload: String(script?.payload || '').trim()
    }))
    .filter((script) => script.marker && script.payload);

  if (!payloads.length) {
    return '';
  }

  return `<script>(function(){var append=function(encoded,marker){if(!encoded){return;}var node=document.createElement('script');node.type='text/javascript';node.setAttribute('data-protorec-inline-script',marker);var bytes=Uint8Array.from(atob(encoded),function(character){return character.charCodeAt(0);});node.textContent=new TextDecoder().decode(bytes);document.body.appendChild(node);};${payloads.map((script) => `append(${JSON.stringify(script.payload)},${JSON.stringify(script.marker)});`).join('')}})();</script>`;
}

const localPreviewStaticOptions = {
  etag: false,
  lastModified: false,
  setHeaders(res) {
    applyLocalPreviewNoStoreHeaders(res);
  }
};

app.use('/temp_proto', express.static(CAPTURE_ROOT, localPreviewStaticOptions));
app.use('/restored', express.static(RESTORE_ROOT, localPreviewStaticOptions));
app.use(PREVIEW_STATIC_ROOT, express.static(PAGES_ROOT, localPreviewStaticOptions));
app.use(PROTOTYPE_PREVIEW_STATIC_ROOT, express.static(PROTOTYPES_ROOT, localPreviewStaticOptions));

app.get('/asset-proxy', async (req, res) => {
  const rawUrl = String(req.query.url || '').trim();
  const rawReferer = String(req.query.referer || '').trim();
  if (!rawUrl) {
    res.status(400).json({ error: 'Missing url query parameter.' });
    return;
  }

  let targetUrl;
  try {
    targetUrl = new URL(rawUrl);
  } catch (_error) {
    res.status(400).json({ error: 'Invalid asset URL.' });
    return;
  }

  if (!['http:', 'https:'].includes(targetUrl.protocol)) {
    res.status(400).json({ error: 'Unsupported protocol.' });
    return;
  }

  let referer = `${targetUrl.origin}/`;
  if (rawReferer) {
    try {
      const refererUrl = new URL(rawReferer);
      if (['http:', 'https:'].includes(refererUrl.protocol)) {
        referer = refererUrl.href;
      }
    } catch (_error) {
      referer = `${targetUrl.origin}/`;
    }
  }

  try {
    const upstreamResponse = await axios({
      url: targetUrl.href,
      method: 'GET',
      responseType: 'stream',
      timeout: 15000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        Referer: referer,
        Origin: targetUrl.origin,
        Accept: 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8'
      },
      validateStatus: (status) => status >= 200 && status < 400
    });

    const contentType = String(upstreamResponse.headers['content-type'] || '').trim();
    const cacheControl = String(upstreamResponse.headers['cache-control'] || '').trim();
    if (contentType) {
      res.setHeader('Content-Type', contentType);
    }
    res.setHeader('Cache-Control', cacheControl || 'public, max-age=300');
    upstreamResponse.data.on('error', (error) => {
      if (!res.headersSent) {
        res.status(502).end('Asset proxy stream error');
        return;
      }
      res.destroy(error);
    });
    upstreamResponse.data.pipe(res);
  } catch (error) {
    const statusCode = error?.response?.status;
    if (Number.isFinite(statusCode) && statusCode >= 400 && statusCode < 600) {
      res.status(statusCode).json({ error: 'Upstream asset request failed.' });
      return;
    }
    res.status(502).json({ error: 'Failed to proxy asset.' });
  }
});

function buildModuleLookupPaths(filename) {
  const lookupRoots = [
    path.dirname(path.resolve(filename)),
    SERVICE_ROOT,
    PROJECT_ROOT,
    process.cwd()
  ];
  const seen = new Set();
  const resolvedPaths = [];

  lookupRoots.forEach((rootPath) => {
    Module._nodeModulePaths(rootPath).forEach((candidatePath) => {
      if (seen.has(candidatePath)) {
        return;
      }
      seen.add(candidatePath);
      resolvedPaths.push(candidatePath);
    });
  });

  return resolvedPaths;
}

function requireFromString(code, filename) {
  const resolvedFilename = path.resolve(filename);
  const mod = new Module(resolvedFilename, module);
  mod.filename = resolvedFilename;
  mod.paths = buildModuleLookupPaths(resolvedFilename);
  mod._compile(code, filename);
  return mod.exports;
}

async function loadComponent(entryFilePath) {
  const result = await esbuild.build({
    entryPoints: [entryFilePath],
    bundle: true,
    platform: 'node',
    format: 'cjs',
    write: false,
    target: ['node18'],
    jsx: 'automatic',
    loader: {
      '.css': 'text',
      '.ts': 'ts',
      '.tsx': 'tsx',
      '.png': 'dataurl',
      '.jpg': 'dataurl',
      '.jpeg': 'dataurl',
      '.gif': 'dataurl',
      '.webp': 'dataurl',
      '.svg': 'dataurl',
      '.ico': 'dataurl',
      '.woff': 'dataurl',
      '.woff2': 'dataurl',
      '.ttf': 'dataurl',
      '.otf': 'dataurl',
      '.eot': 'dataurl'
    },
    external: ['react', 'react-dom', 'react/jsx-runtime'],
    define: { 'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV || 'development') }
  });

  const outputFile = result.outputFiles?.[0];
  if (!outputFile) throw new Error('Preview bundle build failed: no output file.');
  const previewModulePath = path.join(
    path.dirname(entryFilePath),
    `${path.basename(entryFilePath)}.preview.cjs`
  );
  const exports = requireFromString(outputFile.text, previewModulePath);
  return exports?.default || exports;
}

function sanitizeSegment(value) {
  const normalized = String(value || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return normalized || 'index';
}

function sanitizeReadableSegment(value) {
  const normalized = String(value || '')
    .trim()
    .replace(/[^A-Za-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return normalized || '';
}

function createShortHash(value) {
  return Buffer.from(String(value || ''))
    .toString('hex')
    .slice(0, 10) || 'root';
}

function buildCaptureRelativePath(pageUrl) {
  const urlObj = new URL(pageUrl);
  const hostSegment = sanitizeSegment(urlObj.hostname.replace(/\./g, '-'));
  const pathSegments = urlObj.pathname
    .split('/')
    .filter(Boolean)
    .map(sanitizeSegment);

  const segments = [hostSegment, ...(pathSegments.length ? pathSegments : ['index'])];

  if (urlObj.search) {
    segments.push(`query-${createShortHash(urlObj.search)}`);
  }

  return path.join(...segments);
}

function buildRestorePageSlug(pageUrl, pageTitle) {
  const urlObj = new URL(pageUrl);
  const rawPathSegments = urlObj.pathname
    .split('/')
    .filter(Boolean)
    .map(sanitizeReadableSegment)
    .filter(Boolean);

  const lastSegment = rawPathSegments[rawPathSegments.length - 1];
  const previousSegment = rawPathSegments[rawPathSegments.length - 2];
  const normalizedLastSegment = sanitizeSegment(lastSegment);
  const normalizedPreviousSegment = sanitizeSegment(previousSegment);
  const titleSegment = sanitizeReadableSegment(pageTitle);
  const hostnameSegment = sanitizeReadableSegment(urlObj.hostname.split('.').slice(0, -1).join('-') || urlObj.hostname);

  if (lastSegment && previousSegment) {
    const shouldComposeWithPrevious = GENERIC_RESTORE_SEGMENTS.has(normalizedLastSegment)
      || /^\d+$/.test(lastSegment)
      || previousSegment.toLowerCase() !== lastSegment.toLowerCase();

    if (shouldComposeWithPrevious && !GENERIC_RESTORE_SEGMENTS.has(normalizedPreviousSegment) && !/^\d+$/.test(previousSegment)) {
      return `${previousSegment}-${lastSegment}`;
    }
  }

  if (lastSegment && !GENERIC_RESTORE_SEGMENTS.has(normalizedLastSegment) && !/^\d+$/.test(lastSegment)) {
    return lastSegment;
  }

  if (titleSegment && !GENERIC_RESTORE_SEGMENTS.has(sanitizeSegment(titleSegment))) {
    return titleSegment;
  }

  return hostnameSegment || `page-${createShortHash(pageUrl)}`;
}

function buildCaptureVariantSlug(captureVariant) {
  if (!captureVariant) {
    return '';
  }

  const explicitSlug = sanitizeReadableSegment(captureVariant.slug);
  if (explicitSlug) {
    return explicitSlug;
  }

  const labelSlug = sanitizeReadableSegment(captureVariant.label);
  if (labelSlug) {
    return labelSlug;
  }

  const variantIndex = Number(captureVariant.index);
  return Number.isFinite(variantIndex) ? `tab-${variantIndex + 1}` : 'tab';
}

async function resolveAvailableRestoreSlug(baseSlug) {
  const sanitizedBaseSlug = sanitizeReadableSegment(baseSlug) || 'page';

  for (let suffix = 0; suffix < 1000; suffix += 1) {
    const candidateSlug = suffix === 0 ? sanitizedBaseSlug : `${sanitizedBaseSlug}-${suffix + 1}`;
    const candidatePath = path.join(RESTORE_ROOT, candidateSlug);
    if (!(await fs.pathExists(candidatePath))) {
      return candidateSlug;
    }
  }

  return `${sanitizedBaseSlug}-${createShortHash(Date.now())}`;
}

function toPosixPath(filePath) {
  return filePath.split(path.sep).join('/');
}

function toWorkspaceRelativePath(filePath) {
  return toPosixPath(path.relative(WORKSPACE_ROOT, filePath));
}

function toProjectRelativePath(filePath) {
  return toPosixPath(path.relative(PROJECT_ROOT, filePath));
}

function buildCaptureQualityReport(metadata = {}, assetReport = {}) {
  const downloadedAssetCount = Number(assetReport.downloadedAssetCount) || 0;
  const failedAssetCount = Number(assetReport.failedAssetCount)
    || (Array.isArray(assetReport.failedUrls) ? assetReport.failedUrls.length : 0);
  const attemptedAssetCount = Number(assetReport.attemptedAssetCount) || (downloadedAssetCount + failedAssetCount);
  const failedAssetRatio = attemptedAssetCount > 0
    ? Number((failedAssetCount / attemptedAssetCount).toFixed(4))
    : 0;
  const runtimeStyleTextCount = Number(metadata.runtimeStyleTextCount)
    || (Array.isArray(metadata.runtimeStyleTexts) ? metadata.runtimeStyleTexts.length : 0);
  const layoutNodeSnapshotCount = Array.isArray(metadata.layoutNodeSnapshots) ? metadata.layoutNodeSnapshots.length : 0;
  const scrollContainerSnapshotCount = Array.isArray(metadata.scrollContainerSnapshots) ? metadata.scrollContainerSnapshots.length : 0;
  const browserAssetSnapshotCount = Array.isArray(metadata.browserAssetSnapshots) ? metadata.browserAssetSnapshots.length : 0;
  const warmupMetrics = metadata.warmup?.lazyWarmupMetrics || {};
  const warnings = [];
  const clampScore = (value) => Math.max(0, Math.min(100, Math.round(Number(value) || 0)));

  if (attemptedAssetCount > 0 && failedAssetRatio >= 0.2) {
    warnings.push(`资源下载失败率偏高（${Math.round(failedAssetRatio * 100)}%）`);
  }
  if (Number(assetReport.failedStylesheetCount || 0) > 0) {
    warnings.push(`样式表本地化失败 ${Number(assetReport.failedStylesheetCount || 0)} 个，视觉还原可能偏差`);
  }
  if (Number(assetReport.failedImageCount || 0) > 0) {
    warnings.push(`图片本地化失败 ${Number(assetReport.failedImageCount || 0)} 个，可能出现缺图或远程依赖`);
  }
  if (Number(assetReport.failedFontCount || 0) > 0) {
    warnings.push(`字体本地化失败 ${Number(assetReport.failedFontCount || 0)} 个，字体观感可能不一致`);
  }
  if (metadata.chunkedCapture || metadata.fallbackCapture) {
    warnings.push('使用了分片或轻量兜底抓取，需重点核对布局和动态样式');
  }
  if (layoutNodeSnapshotCount === 0) {
    warnings.push('布局快照为空，复杂布局还原可能不稳定');
  }
  if (runtimeStyleTextCount === 0) {
    warnings.push('运行时样式采样为空，动态样式页面可能出现偏差');
  }

  const assetScore = attemptedAssetCount > 0
    ? clampScore((1 - failedAssetRatio) * 100)
    : 85;
  const runtimeStyleScore = clampScore((runtimeStyleTextCount / 40) * 100);
  const layoutSnapshotScore = clampScore((layoutNodeSnapshotCount / 260) * 100);
  const scrollSnapshotScore = clampScore((scrollContainerSnapshotCount / 24) * 100);
  const browserAssetSnapshotScore = clampScore((browserAssetSnapshotCount / 40) * 100);
  const warmupSignalCount = Object.values(warmupMetrics).reduce((sum, value) => sum + (Number(value) || 0), 0);
  const warmupScore = warmupSignalCount > 0 ? clampScore(65 + Math.log10(warmupSignalCount + 1) * 35) : 50;
  const overallScore = clampScore(
    (assetScore * 0.32)
    + (runtimeStyleScore * 0.16)
    + (layoutSnapshotScore * 0.24)
    + (scrollSnapshotScore * 0.1)
    + (browserAssetSnapshotScore * 0.1)
    + (warmupScore * 0.08)
  );
  const grade = overallScore >= 90
    ? 'A'
    : overallScore >= 80
      ? 'B'
      : overallScore >= 70
        ? 'C'
        : overallScore >= 60
          ? 'D'
          : 'E';

  return {
    generatedAt: new Date().toISOString(),
    attemptedAssetCount,
    downloadedAssetCount,
    failedAssetCount,
    failedAssetRatio,
    stylesheets: {
      attempted: Number(assetReport.attemptedStylesheetCount || 0),
      localized: Number(assetReport.localizedStylesheetCount || 0),
      failed: Number(assetReport.failedStylesheetCount || 0),
      failedUrls: Array.isArray(assetReport.failedStylesheetUrls) ? assetReport.failedStylesheetUrls : []
    },
    images: {
      attempted: Number(assetReport.attemptedImageCount || 0),
      downloaded: Number(assetReport.downloadedImageCount || 0),
      failed: Number(assetReport.failedImageCount || 0),
      failedUrls: Array.isArray(assetReport.failedImageUrls) ? assetReport.failedImageUrls : []
    },
    fonts: {
      attempted: Number(assetReport.attemptedFontCount || 0),
      downloaded: Number(assetReport.downloadedFontCount || 0),
      failed: Number(assetReport.failedFontCount || 0),
      failedUrls: Array.isArray(assetReport.failedFontUrls) ? assetReport.failedFontUrls : []
    },
    fallbackUsage: {
      chunkedCapture: Boolean(metadata.chunkedCapture),
      fallbackCapture: Boolean(metadata.fallbackCapture),
      canvasSnapshotCount: Array.isArray(metadata.browserAssetSnapshots)
        ? metadata.browserAssetSnapshots.filter((snapshot) => /canvas/i.test(String(snapshot?.kind || snapshot?.id || ''))).length
        : 0,
      browserAssetSnapshotCount
    },
    remoteResourceDependencies: Array.from(new Set(Array.isArray(assetReport.failedUrls) ? assetReport.failedUrls : [])),
    runtimeStyleTextCount,
    layoutNodeSnapshotCount,
    scrollContainerSnapshotCount,
    browserAssetSnapshotCount,
    warmupMetrics,
    scoreBreakdown: {
      assetScore,
      runtimeStyleScore,
      layoutSnapshotScore,
      scrollSnapshotScore,
      browserAssetSnapshotScore,
      warmupScore
    },
    overallScore,
    grade,
    warnings
  };
}

function decodeImageDataUrl(dataUrl = '') {
  const text = String(dataUrl || '');
  const match = text.match(/^data:image\/png;base64,([A-Za-z0-9+/=]+)$/);
  if (!match) {
    return null;
  }
  return Buffer.from(match[1], 'base64');
}

async function writeVisualAuditPayload(metaDir, visualAuditPayload = null) {
  if (!visualAuditPayload || !visualAuditPayload.captureSession) {
    return { written: false, reason: 'missing-visual-audit-payload' };
  }

  const visualAuditDir = path.join(metaDir, 'evidence', 'visual-audit');
  const cropsDir = path.join(visualAuditDir, 'region-crops');
  const scrollStopsDir = path.join(visualAuditDir, 'scroll-stops');
  await fs.ensureDir(cropsDir);
  await fs.ensureDir(scrollStopsDir);

  const captureSession = {
    ...visualAuditPayload.captureSession,
    screenshot: {
      capturedAt: new Date().toISOString(),
      path: 'screenshot.png'
    }
  };
  if (Array.isArray(visualAuditPayload.scrollStopScreenshots) && visualAuditPayload.scrollStopScreenshots.length) {
    captureSession.scrollStops = visualAuditPayload.scrollStopScreenshots
      .map((stop, index) => {
        const scrollY = Math.max(0, Math.round(Number(stop?.scrollY || 0)));
        const id = String(stop?.id || `stop-${String(index).padStart(3, '0')}`).replace(/[^A-Za-z0-9_-]/g, '') || `stop-${String(index).padStart(3, '0')}`;
        const fileName = String(stop?.fileName || `${id}-y${scrollY}.png`).replace(/[^A-Za-z0-9_.-]/g, '');
        return {
          id,
          scrollY,
          viewport: stop?.viewport || captureSession.viewport || {},
          screenshotPath: path.posix.join('scroll-stops', fileName),
          coveredRange: stop?.coveredRange || null
        };
      });
  }
  await fs.writeJson(path.join(visualAuditDir, 'capture-session.json'), captureSession, { spaces: 2 });
  await fs.writeJson(path.join(visualAuditDir, 'critical-elements.json'), visualAuditPayload.criticalElements || {}, { spaces: 2 });
  await fs.writeJson(path.join(visualAuditDir, 'asset-visibility.json'), visualAuditPayload.assetVisibility || {}, { spaces: 2 });

  const screenshotBuffer = decodeImageDataUrl(visualAuditPayload.screenshot);
  if (screenshotBuffer) {
    await fs.writeFile(path.join(visualAuditDir, 'screenshot.png'), screenshotBuffer);
  }

  const regionCrops = visualAuditPayload.regionCrops && typeof visualAuditPayload.regionCrops === 'object'
    ? visualAuditPayload.regionCrops
    : {};
  for (const [regionId, dataUrl] of Object.entries(regionCrops)) {
    const safeRegionId = String(regionId || '').replace(/[^A-Za-z0-9_-]/g, '');
    if (!safeRegionId) {
      continue;
    }
    const cropBuffer = decodeImageDataUrl(dataUrl);
    if (cropBuffer) {
      await fs.writeFile(path.join(cropsDir, `${safeRegionId}.png`), cropBuffer);
    }
  }

  const scrollStopScreenshots = Array.isArray(visualAuditPayload.scrollStopScreenshots)
    ? visualAuditPayload.scrollStopScreenshots
    : [];
  for (const stop of scrollStopScreenshots) {
    const safeFileName = String(stop?.fileName || '').replace(/[^A-Za-z0-9_.-]/g, '');
    if (!/^[A-Za-z0-9_-]+-y[0-9]+\.png$/.test(safeFileName)) {
      continue;
    }
    const dataUrl = stop?.dataUrl || stop?.screenshot || '';
    const buffer = decodeImageDataUrl(dataUrl);
    if (buffer) {
      await fs.writeFile(path.join(scrollStopsDir, safeFileName), buffer);
    }
  }

  return { written: true, path: toProjectRelativePath(visualAuditDir) };
}

async function cleanupFailedRestoreOutput(relativeRestoreDir) {
  const normalizedRelativeDir = String(relativeRestoreDir || '').replace(/^\/+|\/+$/g, '');
  if (!normalizedRelativeDir) {
    return;
  }

  const restoreDir = path.resolve(RESTORE_ROOT, normalizedRelativeDir);
  const relativeToRestoreRoot = path.relative(RESTORE_ROOT, restoreDir);
  if (relativeToRestoreRoot.startsWith('..') || path.isAbsolute(relativeToRestoreRoot)) {
    return;
  }

  const metaDir = path.resolve(META_ROOT, normalizedRelativeDir);
  const relativeToMetaRoot = path.relative(META_ROOT, metaDir);
  if (!relativeToMetaRoot.startsWith('..') && !path.isAbsolute(relativeToMetaRoot)) {
    await fs.remove(metaDir).catch(() => undefined);
  }

  await fs.remove(restoreDir).catch(() => undefined);

  const parts = normalizedRelativeDir.split(/[\\/]+/).filter(Boolean);
  const rootSlug = parts[0];
  const registryPath = rootSlug ? path.join(RESTORE_ROOT, rootSlug, 'pages.json') : '';
  if (!registryPath || !(await fs.pathExists(registryPath))) {
    return;
  }

  try {
    const registry = await fs.readJson(registryPath);
    const views = Array.isArray(registry.views) ? registry.views : [];
    const nextViews = views.filter((view) => String(view?.routeId || '').replace(/^\/+|\/+$/g, '') !== normalizedRelativeDir);
    if (nextViews.length !== views.length) {
      if (nextViews.length) {
        await fs.writeJson(registryPath, { ...registry, views: nextViews }, { spaces: 2 });
      } else {
        await fs.remove(path.join(RESTORE_ROOT, rootSlug)).catch(() => undefined);
      }
    }
  } catch (_error) {
  }
}

function isPathInsideRoot(rootPath, candidatePath) {
  const relativePath = path.relative(rootPath, candidatePath);
  return relativePath && !relativePath.startsWith('..') && !path.isAbsolute(relativePath);
}

function resolvePrototypeEntry(relativePreviewPath) {
  const normalizedRelativePath = normalizeRestorePathValue(relativePreviewPath);
  if (!normalizedRelativePath) {
    throw new Error('缺少预览路径参数 path。');
  }

  const prototypeDir = path.resolve(PROTOTYPES_ROOT, normalizedRelativePath);
  if (!isPathInsideRoot(PROTOTYPES_ROOT, prototypeDir)) {
    throw new Error('非法的预览路径。');
  }

  const entryPath = path.join(prototypeDir, 'index.tsx');
  return fs.existsSync(entryPath) ? entryPath : '';
}

function resolveRestoreEntry(relativeRestorePath) {
  const normalizedRelativePath = normalizeRestorePathValue(relativeRestorePath);
  if (!normalizedRelativePath) {
    throw new Error('缺少预览路径参数 path。');
  }

  const restoreDir = path.resolve(RESTORE_ROOT, normalizedRelativePath);
  const relativeToRoot = path.relative(RESTORE_ROOT, restoreDir);
  if (relativeToRoot.startsWith('..') || path.isAbsolute(relativeToRoot)) {
    throw new Error('非法的预览路径。');
  }

  return path.join(restoreDir, 'index.tsx');
}

function resolvePreviewEntry(relativePreviewPath, tabIndex = 1) {
  const prototypeEntryPath = resolvePrototypeEntry(relativePreviewPath);
  if (prototypeEntryPath) {
    return {
      entryFilePath: prototypeEntryPath,
      packageKind: 'prototype',
      previewKind: 'page'
    };
  }

  const entryFilePath = resolveTabbedRestoreEntry(relativePreviewPath, tabIndex);
  return {
    entryFilePath,
    packageKind: 'restore',
    previewKind: resolvePreviewKind(relativePreviewPath, tabIndex, entryFilePath)
  };
}

function resolveTabbedRestoreEntry(relativeRestorePath, tabIndex = 1) {
  const normalizedTabIndex = Number.parseInt(String(tabIndex || 1), 10);
  if (!Number.isFinite(normalizedTabIndex) || normalizedTabIndex <= 1) {
    return resolveRestoreEntry(relativeRestorePath);
  }

  const normalizedRelativePath = String(relativeRestorePath || '').replace(/^\/+|\/+$/g, '');
  const nextSubviewRelativePath = path.posix.join(normalizedRelativePath, 'subviews', `tab-${normalizedTabIndex}`);
  const nextSubviewEntry = path.join(path.resolve(RESTORE_ROOT, nextSubviewRelativePath), 'index.tsx');
  if (fs.existsSync(nextSubviewEntry)) {
    return nextSubviewEntry;
  }

  return resolveRestoreEntry(path.posix.join(normalizedRelativePath, '__tabs__', `tab-${normalizedTabIndex}`));
}

function buildMultiTabSessionKey(sessionId) {
  const normalizedSessionId = String(sessionId || '').trim();
  return normalizedSessionId ? `session:${normalizedSessionId}` : '';
}

async function resolveRestoreTarget({ baseRestoreSlug, relativeCapturePath, metadata = {}, captureVariant = null }) {
  const isMultiTabCapture = !!(metadata.multiTabCapture && captureVariant);
  if (!isMultiTabCapture) {
    const restoreSlug = await resolveAvailableRestoreSlug(baseRestoreSlug);
    return {
      restoreSlug,
      restoreRelativeDir: restoreSlug,
      isMultiTabCapture: false
    };
  }

  const sessionKey = buildMultiTabSessionKey(metadata.multiTabSessionId);
  let restoreSlug = sessionKey ? MULTI_TAB_RESTORE_SESSIONS.get(sessionKey)?.restoreSlug : '';

  if (!restoreSlug) {
    restoreSlug = await resolveAvailableRestoreSlug(baseRestoreSlug);
    if (sessionKey) {
      MULTI_TAB_RESTORE_SESSIONS.set(sessionKey, { restoreSlug });
    }
  }

  const variantIndex = Number(captureVariant.index);
  const restoreRelativeDir = Number.isFinite(variantIndex) && variantIndex > 0
    ? path.posix.join(restoreSlug, 'subviews', `tab-${variantIndex + 1}`)
    : restoreSlug;

  return {
    restoreSlug,
    restoreRelativeDir,
    isMultiTabCapture: true
  };
}

function finalizeRestoreTargetSession(metadata = {}, captureVariant = null) {
  const sessionKey = buildMultiTabSessionKey(metadata.multiTabSessionId);
  if (!sessionKey || !captureVariant) {
    return;
  }

  const variantIndex = Number(captureVariant.index);
  const total = Number(captureVariant.total);
  if (Number.isFinite(variantIndex) && Number.isFinite(total) && variantIndex >= total - 1) {
    MULTI_TAB_RESTORE_SESSIONS.delete(sessionKey);
  }
}

function parseTabRestoreSlug(restoreSlug) {
  const matched = /^(.*?)-tab-(\d+)(?:-(\d+))?$/.exec(String(restoreSlug || ''));
  if (!matched) {
    return null;
  }

  return {
    baseSlug: matched[1],
    tabIndex: Number(matched[2]),
    duplicateSuffix: matched[3] ? `-${matched[3]}` : ''
  };
}

function buildPreviewRestoreBase(restoreSlug) {
  const normalizedSlug = String(restoreSlug || '').replace(/^\/+|\/+$/g, '');
  return `/restored/${normalizedSlug}`;
}

function localizeMergedPreviewReference(referenceValue, restoreSlug) {
  const value = String(referenceValue || '').trim();
  if (!value) {
    return referenceValue;
  }

  if (
    value.startsWith('#')
    || value.startsWith('/')
    || /^(?:[a-z]+:)?\/\//i.test(value)
    || /^(?:data|blob|javascript|mailto|tel):/i.test(value)
  ) {
    return referenceValue;
  }

  const normalizedPath = value.replace(/^\.\//, '').replace(/^\/+/, '');
  if (!/^(?:assets|temp_assets)\//.test(normalizedPath)) {
    return referenceValue;
  }

  return `${buildPreviewRestoreBase(restoreSlug)}/${normalizedPath}`;
}

function rewriteMergedPreviewStyleValue(styleValue, restoreSlug) {
  if (!styleValue || !String(styleValue).includes('url(')) {
    return styleValue;
  }

  return String(styleValue).replace(/url\((['"]?)([^'")]+)\1\)/g, (match, quote, assetUrl) => {
    const localizedUrl = localizeMergedPreviewReference(assetUrl, restoreSlug);
    if (!localizedUrl || localizedUrl === assetUrl) {
      return match;
    }

    return `url(${quote}${localizedUrl}${quote})`;
  });
}

function rewriteMergedPreviewSrcset(srcsetValue, restoreSlug) {
  if (!srcsetValue) {
    return srcsetValue;
  }

  return String(srcsetValue)
    .split(',')
    .map((entry) => {
      const parts = entry.trim().split(/\s+/);
      const assetUrl = parts.shift();
      const descriptor = parts.join(' ');
      const localizedUrl = localizeMergedPreviewReference(assetUrl, restoreSlug);
      return [localizedUrl || assetUrl, descriptor].filter(Boolean).join(' ');
    })
    .join(', ');
}

function stripSiblingGlobalRootRules(styleValue) {
  if (!styleValue) {
    return styleValue;
  }

  return String(styleValue)
    .replace(/(?:html|body|:root)(?:\s*,\s*(?:html|body|:root))*\s*\{[^{}]*\}/g, '')
    .trim();
}

function collectClassNames(classValue) {
  return String(classValue || '')
    .split(/\s+/)
    .map((value) => value.trim())
    .filter(Boolean);
}

function mergeElementClassNames($element, classNames) {
  const mergedClassNames = Array.from(new Set([
    ...collectClassNames($element.attr('class')),
    ...collectClassNames(classNames)
  ]));

  if (mergedClassNames.length) {
    $element.attr('class', mergedClassNames.join(' '));
  } else {
    $element.removeAttr('class');
  }
}

function getMeaningfulChildNodes($element) {
  return $element.contents().toArray().filter((node) => {
    if (!node) {
      return false;
    }

    if (node.type === 'comment') {
      return false;
    }

    if (node.type === 'text') {
      return String(node.data || '').trim().length > 0;
    }

    return true;
  });
}

function normalizePreviewGeneratedBlockWrappers($root, $) {
  const blockWrappers = $root
    .find('[data-block-id]')
    .toArray();

  blockWrappers.forEach((blockWrapper) => {
    const $blockWrapper = $(blockWrapper);
    const $blockContent = $blockWrapper.children().filter((_, child) => {
      return collectClassNames($(child).attr('class')).some((className) => className.endsWith('__block-content'));
    }).first();

    if (!$blockContent.length) {
      return;
    }

    const meaningfulChildNodes = getMeaningfulChildNodes($blockContent);
    const meaningfulElementNodes = meaningfulChildNodes.filter((node) => (
      node.type === 'tag'
      || node.type === 'script'
      || node.type === 'style'
    ));

    if (meaningfulChildNodes.length === 1 && meaningfulElementNodes.length === 1) {
      const $actualRoot = $(meaningfulElementNodes[0]);
      const blockWrapperAttributes = blockWrapper.attribs || {};
      const blockContentAttributes = $blockContent.get(0)?.attribs || {};

      mergeElementClassNames(
        $actualRoot,
        [
          blockWrapperAttributes.class,
          blockContentAttributes.class
        ].filter(Boolean).join(' ')
      );

      Object.entries(blockWrapperAttributes).forEach(([name, value]) => {
        if (name === 'class' || name === 'style') {
          return;
        }

        $actualRoot.attr(name, value);
      });
      $blockContent.replaceWith($blockContent.contents());
      $blockWrapper.replaceWith($blockWrapper.contents());
    }
  });
}

function rewriteMergedPreviewMarkup(markup, restoreSlug) {
  if (!markup || !restoreSlug) {
    return markup;
  }

  const $ = cheerio.load(`<div id="__restore-root">${markup}</div>`, { decodeEntities: false });
  const assetAttributes = ['src', 'href', 'poster', 'data-src', 'data-original', 'data-origin', 'data-url', 'data-lazy-src', 'data-lazyload', 'data-echo'];

  assetAttributes.forEach((attributeName) => {
    $(`[${attributeName}]`).each((_, element) => {
      const $element = $(element);
      $element.attr(attributeName, localizeMergedPreviewReference($element.attr(attributeName), restoreSlug));
    });
  });

  $('[srcset]').each((_, element) => {
    const $element = $(element);
    $element.attr('srcset', rewriteMergedPreviewSrcset($element.attr('srcset'), restoreSlug));
  });

  $('[style*="url("]').each((_, element) => {
    const $element = $(element);
    $element.attr('style', rewriteMergedPreviewStyleValue($element.attr('style'), restoreSlug));
  });

  $('style').each((_, element) => {
    const $element = $(element);
    $element.html(
      sanitizeExtractedSourceCss(
        rewriteMergedPreviewStyleValue($element.html() || '', restoreSlug)
      )
    );
  });

  normalizePreviewGeneratedBlockWrappers($('#__restore-root'), $);

  return $('#__restore-root').html() || markup;
}

function parseInlineStyleDeclarations(styleText) {
  return String(styleText || '')
    .split(';')
    .map((entry) => entry.trim())
    .filter(Boolean)
    .map((entry) => {
      const separatorIndex = entry.indexOf(':');
      if (separatorIndex < 0) {
        return null;
      }

      const property = entry.slice(0, separatorIndex).trim().toLowerCase();
      const value = entry.slice(separatorIndex + 1).trim();
      if (!property || !value) {
        return null;
      }

      return [property, value];
    })
    .filter(Boolean);
}

function stringifyInlineStyleDeclarations(declarations) {
  return declarations
    .map(([property, value]) => `${property}:${value}`)
    .join(';');
}

function extractPixelStyleValue(styleMap, propertyName) {
  const value = styleMap.get(propertyName);
  if (!value) {
    return 0;
  }

  const matched = /(-?\d+(?:\.\d+)?)px/i.exec(value);
  return matched ? Number.parseFloat(matched[1]) : 0;
}

function sanitizePreviewMarkupInheritedTypography(markup) {
  if (!markup || !String(markup).includes('<style')) {
    return markup;
  }

  const $ = cheerio.load(`<div id="__restore-root">${markup}</div>`, { decodeEntities: false });
  $('style').each((_, element) => {
    const $element = $(element);
    $element.html(sanitizeExtractedSourceCss($element.html() || ''));
  });
  return $('#__restore-root').html() || markup;
}

function sanitizeRootSnapshotPreviewHead(previewHead) {
  if (!previewHead || !String(previewHead).includes('<style')) {
    return previewHead;
  }

  const $ = cheerio.load(`<head>${previewHead}</head>`, { decodeEntities: false });
  $('style').each((_, element) => {
    const $element = $(element);
    $element.html(sanitizeExtractedSourceCss($element.html() || ''));
  });
  return $('head').html() || previewHead;
}

function appendGlobalPreviewPlaceholderStyle(previewHead) {
  const normalizedPreviewHead = String(previewHead || '');
  const withPlaceholderStyle = normalizedPreviewHead.includes('-webkit-text-fill-color: #bfbfbf !important;')
    ? normalizedPreviewHead
    : [normalizedPreviewHead, GLOBAL_PREVIEW_PLACEHOLDER_STYLE].filter(Boolean).join('\n');

  return [
    withPlaceholderStyle,
    GLOBAL_PREVIEW_SUBVIEW_SCROLL_STYLE,
    GLOBAL_PREVIEW_MEDIA_RECOVERY_STYLE,
    GLOBAL_PREVIEW_ROOT_LAYOUT_STYLE,
    GLOBAL_PREVIEW_MENU_SCROLLBAR_STYLE
  ].filter(Boolean).join('\n');
}

function upsertHtmlAttribute(attributeSource, attributeName, attributeValue) {
  const normalizedAttributeSource = String(attributeSource || '');
  const sanitizedName = String(attributeName || '').trim();
  const sanitizedValue = String(attributeValue || '').replace(/"/g, '&quot;');
  if (!sanitizedName) {
    return normalizedAttributeSource;
  }

  const attributePattern = new RegExp(`\\s${sanitizedName}="[^"]*"`, 'g');
  const nextAttributeSource = normalizedAttributeSource.replace(attributePattern, '');
  return `${nextAttributeSource} ${sanitizedName}="${sanitizedValue}"`;
}

function resolvePreviewKind(relativeRestorePath, requestedTab, entryFilePath) {
  const normalizedRequestedTab = Number.parseInt(String(requestedTab || '1'), 10);
  if (Number.isFinite(normalizedRequestedTab) && normalizedRequestedTab > 1) {
    return 'subview';
  }

  const normalizedRelativeRestorePath = String(relativeRestorePath || '').replace(/^\/+|\/+$/g, '');
  if (/(?:^|\/)(?:subviews|__tabs__)(?:\/|$)/.test(normalizedRelativeRestorePath)) {
    return 'subview';
  }

  const normalizedEntryFilePath = toPosixPath(path.relative(RESTORE_ROOT, entryFilePath || ''));
  if (/(?:^|\/)(?:subviews|__tabs__)(?:\/|$)/.test(normalizedEntryFilePath)) {
    return 'subview';
  }

  return 'page';
}

const PREVIEW_TAB_SELECTOR = '.ant-tabs-tab, .el-tabs__item, .hammer-tabs-tab, [role="tab"]';
const PREVIEW_TAB_CLICK_TARGET_SELECTOR = '.ant-tabs-tab-btn, .hammer-tabs-tab-btn, [role="tab"]';
const PREVIEW_TAB_PANEL_SELECTOR = '.ant-tabs-tabpane, .el-tab-pane, .tab-pane, .hammer-tabs-tabpane, [role="tabpanel"]';

function collectPreviewTabs($root, $) {
  return $root
    .find(PREVIEW_TAB_SELECTOR)
    .toArray()
    .filter((element) => {
      const $element = $(element);
      const label = $element.text().trim();
      if (!label) {
        return false;
      }

      if ($element.attr('role') === 'tab') {
        const wrapper = $element.closest('.ant-tabs-tab, .el-tabs__item, .hammer-tabs-tab');
        if (wrapper.length && wrapper[0] !== element) {
          return false;
        }
      }

      return true;
    });
}

function scorePreviewTabPanel($panel) {
  const className = $panel.attr('class') || '';
  const style = $panel.attr('style') || '';
  const ariaHidden = String($panel.attr('aria-hidden') || '').trim().toLowerCase();
  const dataPanelActive = String($panel.attr('data-protorec-panel-active') || '').trim().toLowerCase();
  const tabIndex = String($panel.attr('tabindex') || '').trim();
  const isExplicitlyHidden = ariaHidden === 'true'
    || Boolean($panel.attr('hidden'))
    || /(?:^|\s)(?:ant-tabs-tabpane-hidden|hammer-tabs-tabpane-hidden|hidden)(?:\s|$)/i.test(className)
    || /display\s*:\s*none/i.test(style);
  const isActive = !isExplicitlyHidden && (
    /(?:^|\s)(?:ant-tabs-tabpane-active|hammer-tabs-tabpane-active|active|selected|current)(?:\s|$)/i.test(className)
    || ariaHidden === 'false'
    || dataPanelActive === 'true'
    || tabIndex === '0'
  );
  const textLength = $panel.text().trim().length;
  const htmlLength = ($panel.html() || '').trim().length;

  return {
    isExplicitlyHidden,
    isActive,
    score: (isActive ? 1000000 : 0) + (isExplicitlyHidden ? -1000000 : 0) + htmlLength + textLength
  };
}

function extractBestTabPanelMarkup(markup, options = {}) {
  if (!markup) {
    return null;
  }

  const { expectedPanelIndex = null } = options;
  const $ = cheerio.load(`<div id="__restore-root">${markup}</div>`, { decodeEntities: false });
  const panels = $(PREVIEW_TAB_PANEL_SELECTOR).toArray();
  if (!panels.length) {
    return null;
  }

  const normalizedExpectedPanelIndex = Number.parseInt(String(expectedPanelIndex ?? ''), 10);
  const scopedPanels = Number.isFinite(normalizedExpectedPanelIndex)
    ? panels.filter((panel) => {
        const $panel = $(panel);
        return Number.parseInt(String($panel.attr('data-protorec-panel-index') || ''), 10) === normalizedExpectedPanelIndex;
      })
    : panels;
  const candidatePanels = scopedPanels.length ? scopedPanels : panels;
  const scoredPanels = candidatePanels.map((panel) => {
    const $panel = $(panel);
    return {
      ...scorePreviewTabPanel($panel),
      markup: $.html($panel)
    };
  });

  scoredPanels.sort((left, right) => right.score - left.score);
  return scoredPanels[0]?.markup || null;
}

function normalizeMergedTabPanelMarkup(panelMarkup, options = {}) {
  if (!panelMarkup) {
    return null;
  }

  const {
    interactionId = '',
    panelIndex = null,
    isActive = false
  } = options;
  const $ = cheerio.load(`<div id="__restore-root">${panelMarkup}</div>`, { decodeEntities: false });
  const $panel = $('#__restore-root').find(PREVIEW_TAB_PANEL_SELECTOR).first();
  if (!$panel.length) {
    return panelMarkup;
  }

  const normalizedPanelIndex = Number.parseInt(String(panelIndex ?? ''), 10);
  if (Number.isFinite(normalizedPanelIndex)) {
    $panel.attr('data-protorec-panel-index', String(normalizedPanelIndex));
  }

  if (interactionId) {
    $panel.attr('data-protorec-interaction-id', interactionId);
  }

  $panel.attr('data-protorec-panel-active', isActive ? 'true' : 'false');
  $panel.attr('aria-hidden', isActive ? 'false' : 'true');
  $panel.attr('tabindex', isActive ? '0' : '-1');

  if (isActive) {
    $panel.removeAttr('hidden');
  } else {
    $panel.attr('hidden', '');
  }

  const classNames = new Set(
    String($panel.attr('class') || '')
      .split(/\s+/)
      .map((value) => value.trim())
      .filter(Boolean)
  );
  const hasAntTabPanelClass = Array.from(classNames).some((className) => className.startsWith('ant-tabs-'));
  const hasHammerTabPanelClass = Array.from(classNames).some((className) => className.startsWith('hammer-tabs-'));

  if (isActive) {
    if (hasAntTabPanelClass) {
      classNames.delete('ant-tabs-tabpane-hidden');
      classNames.add('ant-tabs-tabpane-active');
    }
    if (hasHammerTabPanelClass) {
      classNames.delete('hammer-tabs-tabpane-hidden');
      classNames.add('hammer-tabs-tabpane-active');
    }
    classNames.delete('hidden');
  } else {
    if (hasAntTabPanelClass) {
      classNames.delete('ant-tabs-tabpane-active');
      classNames.add('ant-tabs-tabpane-hidden');
    }
    if (hasHammerTabPanelClass) {
      classNames.delete('hammer-tabs-tabpane-active');
      classNames.add('hammer-tabs-tabpane-hidden');
    }
  }

  $panel.attr('class', Array.from(classNames).join(' '));
  return $('#__restore-root').html() || panelMarkup;
}

function resolveMetaDirForRestoreEntry(entryFilePath) {
  if (!entryFilePath) {
    return '';
  }

  const relativeEntryPath = path.relative(RESTORE_ROOT, entryFilePath);
  if (relativeEntryPath.startsWith('..') || path.isAbsolute(relativeEntryPath)) {
    return '';
  }

  const relativeEntryDir = path.dirname(relativeEntryPath);
  if (!relativeEntryDir || relativeEntryDir === '.') {
    return META_ROOT;
  }

  return path.join(META_ROOT, relativeEntryDir);
}

function extractInlineSymbolSpriteMarkup(sourceHtml) {
  if (!sourceHtml || !/<symbol\b/i.test(String(sourceHtml))) {
    return '';
  }

  const $ = cheerio.load(String(sourceHtml), { decodeEntities: false });
  const spriteNodes = $('svg')
    .toArray()
    .filter((element) => $(element).find('symbol').length > 0)
    .map((element) => $.html(element))
    .filter(Boolean);

  return spriteNodes.join('\n');
}

async function hydratePreviewInlineSymbolSprites(previewMarkup, entryFilePath) {
  const normalizedMarkup = String(previewMarkup || '');
  if (!normalizedMarkup.trim()) {
    return normalizedMarkup;
  }

  if (!/(?:xlink:href|href)=["']#/.test(normalizedMarkup) || /<symbol\b/i.test(normalizedMarkup)) {
    return normalizedMarkup;
  }

  const metaDir = resolveMetaDirForRestoreEntry(entryFilePath);
  if (!metaDir) {
    return normalizedMarkup;
  }

  const sourceHtmlPath = path.join(metaDir, 'source.original.html');
  if (!(await fs.pathExists(sourceHtmlPath))) {
    return normalizedMarkup;
  }

  const sourceHtml = await fs.readFile(sourceHtmlPath, 'utf8');
  const spriteMarkup = extractInlineSymbolSpriteMarkup(sourceHtml);
  if (!spriteMarkup) {
    return normalizedMarkup;
  }

  return `${spriteMarkup}\n${normalizedMarkup}`;
}

async function loadRenderedComponentMarkup(entryFilePath) {
  const Component = await loadComponent(entryFilePath);
  const previewMarkup = await hydratePreviewInlineSymbolSprites(
    typeof Component.previewBodyMarkup === 'string' && Component.previewBodyMarkup.trim()
      ? Component.previewBodyMarkup
      : ReactDOMServer.renderToString(React.createElement(Component)),
    entryFilePath
  );

  return {
    Component,
    previewMarkup
  };
}

function extractStyleNodesFromPreviewHead(previewHead, restoreSlug, options = {}) {
  if (!previewHead || !String(previewHead).trim()) {
    return [];
  }

  const {
    stripExtractedSourceStyles = false,
    stripGlobalRootRules = false
  } = options;
  const $ = cheerio.load(`<head>${previewHead}</head>`, { decodeEntities: false });
  $('style').each((_, element) => {
    const $element = $(element);
    const rewrittenStyle = rewriteMergedPreviewStyleValue($element.html() || '', restoreSlug);
    const sourceStyleTrimmed = stripExtractedSourceStyles
      ? rewrittenStyle.split('/* ProtoRec extracted source styles */')[0]
      : rewrittenStyle;
    const finalStyle = stripGlobalRootRules ? stripSiblingGlobalRootRules(sourceStyleTrimmed) : sourceStyleTrimmed;
    $element.html(finalStyle);
  });

  return $('style')
    .toArray()
    .map((node) => $.html(node))
    .filter((styleNode) => styleNode && !/^<style>\s*<\/style>$/.test(styleNode.trim()));
}

function mergePreviewHeads(primaryPreviewHead, siblingPreviewEntries) {
  const primaryHead = String(primaryPreviewHead || '');
  const existingStyleNodes = new Set(extractStyleNodesFromPreviewHead(primaryHead));
  const siblingStyleNodes = siblingPreviewEntries.flatMap((entry) => extractStyleNodesFromPreviewHead(
    entry?.previewHead,
    entry?.restoreSlug,
    {
      stripExtractedSourceStyles: true,
      stripGlobalRootRules: true
    }
  ));
  const appendedStyleNodes = siblingStyleNodes.filter((styleNode) => {
    if (!styleNode || existingStyleNodes.has(styleNode)) {
      return false;
    }

    existingStyleNodes.add(styleNode);
    return true;
  });

  if (!appendedStyleNodes.length) {
    return primaryHead;
  }

  return [primaryHead, ...appendedStyleNodes].filter(Boolean).join('\n');
}

async function buildPrototypePreviewHead(entryFilePath, basePreviewHead = '') {
  const entryDir = path.dirname(path.resolve(entryFilePath || ''));
  const relativePrototypeDir = path.relative(PROTOTYPES_ROOT, entryDir);
  if (
    !relativePrototypeDir
    || relativePrototypeDir.startsWith('..')
    || path.isAbsolute(relativePrototypeDir)
  ) {
    return basePreviewHead;
  }

  const normalizedPrototypeDir = toPosixPath(relativePrototypeDir).replace(/^\/+|\/+$/g, '');
  const baseHref = `${PROTOTYPE_PREVIEW_STATIC_ROOT}/${normalizedPrototypeDir}/`;
  const headParts = [
    String(basePreviewHead || ''),
    `<base href="${baseHref}" />`
  ];

  const stylePath = path.join(entryDir, 'style.css');
  if (await fs.pathExists(stylePath)) {
    const styleText = String(await fs.readFile(stylePath, 'utf8') || '').replace(/<\/style/gi, '<\\/style');
    if (styleText.trim()) {
      headParts.push(`<style data-protorec-prototype-style="true">\n${styleText}\n</style>`);
    }
  }

  return headParts.filter((part) => String(part || '').trim()).join('\n');
}

function mergePreviewBodyClassNames(primaryClassName, siblingClassNames) {
  const classNames = [primaryClassName, ...siblingClassNames]
    .flatMap((value) => String(value || '').split(/\s+/))
    .map((value) => value.trim())
    .filter(Boolean);

  return Array.from(new Set(classNames)).join(' ');
}

function parsePreviewBodyDataAttributes(attributeMarkup) {
  const $ = cheerio.load(`<body${String(attributeMarkup || '')}></body>`, { decodeEntities: false });
  const attributes = $('body').get(0)?.attribs || {};

  return Object.entries(attributes).filter(([name]) => name.startsWith('data-'));
}

function mergePreviewBodyDataAttributes(primaryAttributeMarkup, siblingAttributeMarkups) {
  const mergedAttributes = new Map(parsePreviewBodyDataAttributes(primaryAttributeMarkup));

  siblingAttributeMarkups.forEach((attributeMarkup) => {
    parsePreviewBodyDataAttributes(attributeMarkup).forEach(([name, value]) => {
      if (!mergedAttributes.has(name)) {
        mergedAttributes.set(name, value);
      }
    });
  });

  return Array.from(mergedAttributes.entries())
    .map(([name, value]) => ` ${name}="${String(value).replace(/"/g, '&quot;')}"`)
    .join('');
}

function normalizeRestorePathValue(value) {
  return String(value || '').replace(/^\/+|\/+$/g, '');
}

function resolveBaseRestorePath(relativeRestorePath) {
  const normalizedRelativePath = normalizeRestorePathValue(relativeRestorePath);
  if (!normalizedRelativePath) {
    return '';
  }

  return normalizedRelativePath
    .replace(/(?:\/(?:subviews|__tabs__)\/.*)?$/, '')
    .trim();
}

function isTabbedPreviewView(view) {
  if (!view || typeof view !== 'object') {
    return false;
  }

  const normalizedKind = String(view.kind || '').trim();
  const normalizedOrder = Number.parseInt(String(view.order || ''), 10);
  return (
    (normalizedKind === 'root-tab' || normalizedKind === 'tab')
    && Number.isFinite(normalizedOrder)
    && normalizedOrder > 0
  );
}

function resolveViewEntryFilePath(baseRestorePath, viewEntryPath) {
  const normalizedBaseRestorePath = normalizeRestorePathValue(baseRestorePath);
  const normalizedViewEntryPath = normalizeRestorePathValue(viewEntryPath);
  if (!normalizedBaseRestorePath || !normalizedViewEntryPath) {
    return '';
  }

  const pageRoot = path.resolve(RESTORE_ROOT, normalizedBaseRestorePath);
  const candidatePath = path.resolve(pageRoot, normalizedViewEntryPath);
  const relativeToPageRoot = path.relative(pageRoot, candidatePath);
  if (relativeToPageRoot.startsWith('..') || path.isAbsolute(relativeToPageRoot)) {
    return '';
  }

  return candidatePath;
}

async function resolveTabbedPreviewViews(relativeRestorePath, entryFilePath = '') {
  const baseRestorePath = resolveBaseRestorePath(relativeRestorePath);
  if (!baseRestorePath) {
    return {
      baseRestorePath: '',
      currentView: null,
      views: []
    };
  }

  const pageRoot = path.resolve(RESTORE_ROOT, baseRestorePath);
  const pagesJsonPath = path.join(pageRoot, 'pages.json');
  if (!(await fs.pathExists(pagesJsonPath))) {
    return {
      baseRestorePath,
      currentView: null,
      views: []
    };
  }

  let pagesJson = null;
  try {
    pagesJson = await fs.readJson(pagesJsonPath);
  } catch (_error) {
    return {
      baseRestorePath,
      currentView: null,
      views: []
    };
  }

  const views = (Array.isArray(pagesJson?.views) ? pagesJson.views : [])
    .filter(isTabbedPreviewView)
    .map((view) => ({
      ...view,
      order: Number.parseInt(String(view.order || '0'), 10),
      routeId: normalizeRestorePathValue(view.routeId),
      entryPath: normalizeRestorePathValue(view.entryPath)
    }))
    .filter((view) => view.entryPath)
    .sort((left, right) => left.order - right.order);

  if (views.length < 2) {
    return {
      baseRestorePath,
      currentView: null,
      views
    };
  }

  const normalizedRelativePath = normalizeRestorePathValue(relativeRestorePath);
  const normalizedEntryRelativePath = entryFilePath
    ? normalizeRestorePathValue(toPosixPath(path.relative(pageRoot, entryFilePath)))
    : '';
  const currentView = views.find((view) => (
    normalizedEntryRelativePath && view.entryPath === normalizedEntryRelativePath
  )) || views.find((view) => (
    normalizedRelativePath && view.routeId === normalizedRelativePath
  )) || null;

  return {
    baseRestorePath,
    currentView,
    views
  };
}

function buildPreviewPathForRoute(routeId) {
  const normalizedRouteId = normalizeRestorePathValue(routeId);
  return normalizedRouteId
    ? `/preview?path=${encodeURIComponent(normalizedRouteId)}`
    : '';
}

async function annotateSiblingTabPreviewPaths(relativeRestorePath, currentAppHtml) {
  const normalizedRelativePath = String(relativeRestorePath || '').replace(/^\/+|\/+$/g, '');
  if (!normalizedRelativePath) {
    return currentAppHtml;
  }

  const $ = cheerio.load(`<div id="__restore-root">${currentAppHtml}</div>`, { decodeEntities: false });
  const tabs = collectPreviewTabs($('#__restore-root'), $);

  if (tabs.length < 2) {
    return currentAppHtml;
  }

  const { views: tabViews } = await resolveTabbedPreviewViews(normalizedRelativePath);
  const matchingTabViews = tabViews.length === tabs.length ? tabViews : [];

  for (let tabOrder = 1; tabOrder <= tabs.length; tabOrder += 1) {
    const tab = tabs[tabOrder - 1];
    let previewPath = '';
    const matchingView = matchingTabViews[tabOrder - 1] || null;
    if (matchingView?.routeId) {
      previewPath = buildPreviewPathForRoute(matchingView.routeId);
    } else {
      const siblingEntryFilePath = resolveTabbedRestoreEntry(normalizedRelativePath, tabOrder);
      if (!(await fs.pathExists(siblingEntryFilePath))) {
        continue;
      }

      previewPath = tabOrder <= 1
        ? `/preview?path=${encodeURIComponent(normalizedRelativePath)}`
        : `/preview?path=${encodeURIComponent(normalizedRelativePath)}&tab=${tabOrder}`;
    }

    if (!previewPath) {
      continue;
    }

    const $tab = $(tab);
    const $clickTarget = $tab.is('[role="tab"]')
      ? $tab
      : $tab.find(PREVIEW_TAB_CLICK_TARGET_SELECTOR).first();

    $tab.attr('data-restore-preview-path', previewPath);
    if ($clickTarget.length) {
      $clickTarget.attr('data-restore-preview-path', previewPath);
    }
  }

  return $('#__restore-root').html() || currentAppHtml;
}

async function mergeSiblingTabPanels(relativeRestorePath, entryFilePath, currentAppHtml) {
  const { baseRestorePath, currentView, views } = await resolveTabbedPreviewViews(relativeRestorePath, entryFilePath);
  if (!currentView || views.length < 2) {
    return {
      appHtml: currentAppHtml,
      siblingPreviewEntries: [],
      didMerge: false
    };
  }

  const $ = cheerio.load(`<div id="__restore-root">${currentAppHtml}</div>`, { decodeEntities: false });
  const tabs = collectPreviewTabs($('#__restore-root'), $);
  const existingPanels = $('#__restore-root').find(PREVIEW_TAB_PANEL_SELECTOR);

  if (tabs.length < 2 || !existingPanels.length || tabs.length !== views.length) {
    return {
      appHtml: currentAppHtml,
      siblingPreviewEntries: [],
      didMerge: false
    };
  }

  const panelParent = existingPanels.first().parent();
  if (!panelParent.length) {
    return {
      appHtml: currentAppHtml,
      siblingPreviewEntries: [],
      didMerge: false
    };
  }

  const currentViewIndex = views.findIndex((view) => (
    view.routeId === currentView.routeId
    && view.entryPath === currentView.entryPath
  ));
  const currentPanelInteractionId = String(existingPanels.first().attr('data-protorec-interaction-id') || '').trim();
  const currentPanelMarkup = extractBestTabPanelMarkup(currentAppHtml);
  if (!currentPanelMarkup) {
    return {
      appHtml: currentAppHtml,
      siblingPreviewEntries: [],
      didMerge: false
    };
  }

  const mergedPanels = [];
  const siblingPreviewEntries = [];
  for (const [viewIndex, view] of views.entries()) {
    if (
      view.routeId === currentView.routeId
      && view.entryPath === currentView.entryPath
    ) {
      mergedPanels.push(normalizeMergedTabPanelMarkup(
        extractBestTabPanelMarkup(currentAppHtml, { expectedPanelIndex: viewIndex }) || currentPanelMarkup,
        {
          interactionId: currentPanelInteractionId,
          panelIndex: viewIndex,
          isActive: viewIndex === currentViewIndex
        }
      ));
      continue;
    }

    const siblingEntryFilePath = resolveViewEntryFilePath(baseRestorePath, view.entryPath);
    if (!siblingEntryFilePath || !(await fs.pathExists(siblingEntryFilePath))) {
      mergedPanels.push(null);
      continue;
    }

    const { Component, previewMarkup } = await loadRenderedComponentMarkup(siblingEntryFilePath);
    const siblingRestoreSlug = typeof Component.restoreSlug === 'string' && Component.restoreSlug.trim()
      ? Component.restoreSlug.trim()
      : view.routeId;
    siblingPreviewEntries.push({
      restoreSlug: siblingRestoreSlug,
      previewHead: Component.previewHead,
      previewBodyClassName: Component.previewBodyClassName,
      previewBodyDataAttributes: Component.previewBodyDataAttributes
    });
    mergedPanels.push(normalizeMergedTabPanelMarkup(
      rewriteMergedPreviewMarkup(
        extractBestTabPanelMarkup(previewMarkup, { expectedPanelIndex: viewIndex }),
        siblingRestoreSlug
      ),
      {
        interactionId: currentPanelInteractionId,
        panelIndex: viewIndex,
        isActive: viewIndex === currentViewIndex
      }
    ));
  }

  if (mergedPanels.filter(Boolean).length < 2) {
    return {
      appHtml: currentAppHtml,
      siblingPreviewEntries: [],
      didMerge: false
    };
  }

  existingPanels.remove();
  mergedPanels.forEach((panelMarkup) => {
    if (panelMarkup) {
      panelParent.append(panelMarkup);
    }
  });

  return {
    appHtml: $('#__restore-root').html() || currentAppHtml,
    siblingPreviewEntries,
    didMerge: true
  };
}

app.get('/', async (_req, res) => {
  res.send({
    status: 'ok',
    service: 'proto-capture-restore-local-service',
    port: PORT,
    protocolVersion: HEALTH_PROTOCOL_VERSION,
    startedAt: PROCESS_STARTED_AT
  });
});

app.get('/health', async (req, res) => {
  res.send({
    status: 'ok',
    port: PORT,
    protocolVersion: HEALTH_PROTOCOL_VERSION,
    startedAt: PROCESS_STARTED_AT,
    captureRoot: toProjectRelativePath(CAPTURE_ROOT),
    restoreRoot: toProjectRelativePath(RESTORE_ROOT),
    prototypeRoot: toProjectRelativePath(PROTOTYPES_ROOT),
    restoreMetaRoot: toProjectRelativePath(META_ROOT)
  });
});

app.get('/preview', async (req, res) => {
  try {
    const relativeRestorePath = String(req.query.path || '').replace(/^\/+|\/+$/g, '');
    const requestedTab = Number.parseInt(String(req.query.tab || '1'), 10);
    const previewTarget = resolvePreviewEntry(relativeRestorePath, requestedTab);
    const { entryFilePath } = previewTarget;
    const { Component, previewMarkup } = await loadRenderedComponentMarkup(entryFilePath);
    const currentRestoreSlug = typeof Component.restoreSlug === 'string' && Component.restoreSlug.trim()
      ? Component.restoreSlug.trim()
      : relativeRestorePath;
    const localizedAppHtml = previewTarget.packageKind === 'prototype'
      ? previewMarkup
      : rewriteMergedPreviewMarkup(previewMarkup, currentRestoreSlug);
    let siblingPreviewEntries = [];
    let appHtml = sanitizePreviewMarkupInheritedTypography(localizedAppHtml);
    if (previewTarget.packageKind !== 'prototype') {
      const {
        appHtml: mergedAppHtml,
        siblingPreviewEntries: resolvedSiblingPreviewEntries,
        didMerge: didMergeSiblingPanels
      } = await mergeSiblingTabPanels(relativeRestorePath, entryFilePath, localizedAppHtml);
      siblingPreviewEntries = resolvedSiblingPreviewEntries;
      appHtml = sanitizePreviewMarkupInheritedTypography(
        didMergeSiblingPanels
          ? mergedAppHtml
          : await annotateSiblingTabPreviewPaths(relativeRestorePath, mergedAppHtml)
      );
    }
    const basePreviewHead = typeof Component.previewHead === 'string'
      ? Component.previewHead
      : '<meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1" />';
    const mergedPreviewHead = previewTarget.packageKind === 'prototype'
      ? await buildPrototypePreviewHead(entryFilePath, basePreviewHead)
      : mergePreviewHeads(basePreviewHead, siblingPreviewEntries);
    const previewHead = appendGlobalPreviewPlaceholderStyle(
      sanitizeRootSnapshotPreviewHead(
        mergedPreviewHead
      )
    );
    
    const { createPreviewScript: latestCreatePreviewScript } = loadLatestRestoreModule();
    const { buildPreviewInteractionScript: latestBuildPreviewInteractionScript } = loadLatestInteractionModule();
    const previewInteractionDescriptors = Array.isArray(Component.pageInteractions)
      ? Component.pageInteractions
      : [];
    const previewInteractionScript = previewInteractionDescriptors.length
      ? latestBuildPreviewInteractionScript(previewInteractionDescriptors)
      : (
          typeof Component.previewInteractionScript === 'string'
            ? Component.previewInteractionScript
            : ''
        );
    const hasStructuredLocalInteractions = Boolean(previewInteractionScript.trim())
      || /data-protorec-interaction-(?:kind|scope-root|id|mode)=/i.test(appHtml);
    const previewScript = latestCreatePreviewScript({
      interactionMode: hasStructuredLocalInteractions ? 'passive' : 'heuristic'
    });
    const inlineScriptBootstrap = buildInlineScriptBootstrap([
      {
        marker: 'preview-runtime',
        payload: encodeInlineScriptPayload(previewScript)
      },
      {
        marker: 'preview-interactions',
        payload: encodeInlineScriptPayload(previewInteractionScript)
      }
    ]);
    
    const mergedPreviewBodyClassName = mergePreviewBodyClassNames(
      typeof Component.previewBodyClassName === 'string' ? Component.previewBodyClassName : '',
      siblingPreviewEntries.map((entry) => entry?.previewBodyClassName)
    );
    const previewBodyClassName = mergedPreviewBodyClassName.trim()
      ? ` class="${mergedPreviewBodyClassName.replace(/"/g, '&quot;')}"`
      : '';
    const previewBodyStyleRaw = typeof Component.previewBodyStyle === 'string'
      ? Component.previewBodyStyle.trim()
      : '';
    const mergedBodyStyle = ['margin:0', previewBodyStyleRaw].filter(Boolean).join('; ');
    const previewBodyStyle = ` style="${mergedBodyStyle.replace(/"/g, '&quot;')}"`;
    const previewKind = previewTarget.previewKind;
    const previewBodyDataAttributes = upsertHtmlAttribute(
      mergePreviewBodyDataAttributes(
        typeof Component.previewBodyDataAttributes === 'string'
          ? Component.previewBodyDataAttributes
          : '',
        siblingPreviewEntries.map((entry) => entry?.previewBodyDataAttributes)
      ),
      'data-protorec-preview-kind',
      previewKind
    );

    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    applyLocalPreviewNoStoreHeaders(res);
    res.end(`<!doctype html>
<html lang="zh-CN">
  <head>
    ${previewHead}
  </head>
  <body${previewBodyStyle}${previewBodyClassName}${previewBodyDataAttributes}>
    <div id="root">${appHtml}</div>
    ${inlineScriptBootstrap}
  </body>
</html>`);
  } catch (error) {
    res.status(500).send({ status: 'error', message: error.message });
  }
});

app.get('/save-progress/:runId', (req, res) => {
  const task = getSaveTask(req.params.runId);
  if (!task) {
    res.status(404).send({ status: 'error', message: '未找到对应同步任务。' });
    return;
  }

  res.send({
    status: task.status,
    phase: task.phase,
    message: task.message,
    currentItemTitle: task.currentItemTitle,
    progressText: task.progressText,
    detail: task.detail,
    updatedAt: task.updatedAt
  });
});

app.post('/save-cancel/:runId', (req, res) => {
  const task = cancelSaveTask(req.params.runId, req.body?.reason || 'manual');
  if (!task) {
    res.status(404).send({ status: 'error', message: '未找到对应同步任务。' });
    return;
  }

  res.send({ status: 'success', runId: task.runId, canceled: true });
});

app.post('/save', async (req, res) => {
  const runId = String(req.body?.runId || req.body?.metadata?.syncRunId || '').trim();
  const task = runId ? createSaveTask(runId) : null;
  const reportProgress = runId ? createTaskProgressReporter(runId) : () => null;
  let projectDir = '';
  let restoreDir = '';
  let restoreRelativeDirForCleanup = '';

  try {
    const { html, url, title, screenshot, stylesheets = [], metadata = {}, captureVariant = null, visualAudit = null } = req.body;
    let captureMetadata = metadata;

    console.log('[proto-capture] /save request summary', {
      runId,
      hasHtml: Boolean(html),
      htmlLength: String(html || '').length,
      hasUrl: Boolean(url),
      url: url || '',
      hasTitle: Boolean(title),
      stylesheetCount: Array.isArray(stylesheets) ? stylesheets.length : 0,
      runtimeStyleTextCount: Array.isArray(metadata?.runtimeStyleTexts) ? metadata.runtimeStyleTexts.length : 0,
      layoutNodeSnapshotCount: Array.isArray(metadata?.layoutNodeSnapshots) ? metadata.layoutNodeSnapshots.length : 0,
      scrollContainerSnapshotCount: Array.isArray(metadata?.scrollContainerSnapshots) ? metadata.scrollContainerSnapshots.length : 0,
      browserAssetSnapshotCount: Array.isArray(metadata?.browserAssetSnapshots) ? metadata.browserAssetSnapshots.length : 0,
      chunkedCapture: Boolean(metadata?.chunkedCapture),
      hasVisualAudit: Boolean(visualAudit?.captureSession)
    });

    if (
      metadata?.chunkedCapture
      && !Array.isArray(metadata?.runtimeStyleTexts)
      && !Array.isArray(metadata?.layoutNodeSnapshots)
    ) {
      console.warn('[proto-capture] chunked metadata arrived without runtime styles/layout snapshots', {
        runId,
        metadataKeys: Object.keys(metadata || {})
      });
    }

    if (!html || !url) {
      if (task) {
        updateSaveTask(runId, { status: 'error', message: 'html 和 url 为必填项。' });
        clearSaveTaskLater(runId);
      }
      res.status(400).send({ status: 'error', message: 'html 和 url 为必填项。' });
      return;
    }

    if (task) {
      task.metadata = metadata;
      task.captureVariant = captureVariant;
    }

    const relativeCapturePath = buildCaptureRelativePath(url);
    const baseRestoreSlug = buildRestorePageSlug(url, title);
    const { restoreSlug, restoreRelativeDir } = await resolveRestoreTarget({
      baseRestoreSlug,
      relativeCapturePath,
      metadata,
      captureVariant
    });
    projectDir = path.join(CAPTURE_ROOT, relativeCapturePath);
    const aiSnapshotPath = path.join(projectDir, 'ai_snapshot.html');
    const rawHtmlPath = path.join(projectDir, 'source.original.html');
    const localizedHtmlPath = path.join(projectDir, 'index.html');
    const metaPath = path.join(projectDir, 'capture.meta.json');
    restoreDir = path.join(RESTORE_ROOT, restoreRelativeDir);
    restoreRelativeDirForCleanup = restoreRelativeDir;

    if (task) {
      updateSaveTask(runId, { projectDir, restoreDir, phase: 'save', message: '正在同步资源与代码...' });
    }

    req.on('close', () => {
      if (task && task.status === 'running') {
        cancelSaveTask(runId, 'popup_closed');
      }
    });

    await fs.ensureDir(projectDir);
    reportProgress({ phase: 'save', message: '正在同步资源与代码...', currentItemTitle: '保存浏览器快照', detail: '正在写入原始 HTML 与截图' });
    console.log(`\n==========================================`);
    console.log(`🚀 正在拾取已登录页面: ${title}`);
    console.log(`📂 存储路径: ${projectDir}`);

    console.log('--- [1/4] 正在保存浏览器快照...');
    await fs.writeFile(rawHtmlPath, html);

    if (screenshot) {
      const base64Data = screenshot.replace(/^data:image\/png;base64,/, '');
      await fs.writeFile(path.join(projectDir, 'reference_full.png'), base64Data, 'base64');
    }

    console.log('--- [2/4] 正在本地化资源与样式...');
    const localizedResult = await downloadAssets(html, url, projectDir, {
      stylesheets,
      signal: task?.controller.signal,
      onProgress: reportProgress
    });

    reportProgress({ phase: 'save', message: '正在生成 AI 还原快照...', currentItemTitle: '生成 AI 快照', detail: '正在清洗页面结构供 AI 使用' });
    console.log('--- [3/4] 正在生成 AI 还原快照...');
    const cleanedHtml = cleanAndSemanticize(localizedResult.html);
    await fs.writeFile(aiSnapshotPath, cleanedHtml);

    reportProgress({ phase: 'restore', message: '正在整理还原页面...', currentItemTitle: '写入同步索引', detail: '正在写入本地化 HTML 与元数据' });
    console.log('--- [4/4] 正在写入索引与元数据...');
    await fs.writeFile(localizedHtmlPath, localizedResult.html);
    const captureQuality = buildCaptureQualityReport(metadata, localizedResult.assetReport);
    if (captureQuality.warnings.length) {
      console.warn('[proto-capture] capture quality warnings', captureQuality.warnings);
    }

    let localizedHtml = localizedResult.html;
    reportProgress({
      phase: 'restore',
      message: '正在整理还原页面...',
      currentItemTitle: '补齐动态图表快照',
      detail: '正在为缺失的 canvas 内容生成通用兜底快照'
    });
    try {
      const fallbackResult = await ensureCanvasSnapshotFallback({
        captureDir: projectDir,
        captureRelativePath: relativeCapturePath,
        localizedHtml,
        metadata: captureMetadata,
        previewBaseUrl: `http://127.0.0.1:${PORT}`,
        signal: task?.controller.signal
      });
      localizedHtml = fallbackResult.localizedHtml || localizedHtml;
      captureMetadata = fallbackResult.metadata || captureMetadata;
      if (fallbackResult.applied) {
        await fs.writeFile(localizedHtmlPath, localizedHtml);
        console.log('[proto-capture] synthesized canvas browserAssetSnapshots', {
          canvasCount: fallbackResult.canvasCount,
          synthesizedCanvasCount: fallbackResult.synthesizedCanvasCount,
          synthesizedSnapshotCount: fallbackResult.synthesizedSnapshotCount
        });
      } else {
        console.log('[proto-capture] canvas fallback skipped', {
          reason: fallbackResult.reason,
          canvasCount: fallbackResult.canvasCount || 0
        });
      }
    } catch (fallbackError) {
      console.warn('[proto-capture] canvas fallback failed', fallbackError?.message || fallbackError);
    }

    const restoreResult = await generatePagePackage({
      captureDir: projectDir,
      restoreSlug,
      restoreRelativeDir,
      pageTitle: title,
      pageUrl: url,
      localizedHtml,
      assetReport: localizedResult.assetReport,
      metadata: captureMetadata,
      captureVariant,
      captureQuality,
      onProgress: reportProgress
    });
    const visualAuditWriteResult = await writeVisualAuditPayload(restoreResult.metaDir, visualAudit);
    if (visualAuditWriteResult.written) {
      console.log('[proto-capture] visual audit evidence written', visualAuditWriteResult);
    } else {
      console.warn('[proto-capture] visual audit evidence not written', visualAuditWriteResult);
    }
    maybeInjectSaveFailure('after-generate');
    const restorePreviewUrl = `http://localhost:${PORT}/preview?path=${encodeURIComponent(restoreRelativeDir)}`;
    await fs.writeJson(metaPath, {
      title,
      url,
      capturedAt: new Date().toISOString(),
      capturePath: toProjectRelativePath(projectDir),
      restoreTargetPath: toProjectRelativePath(restoreResult.pageDir),
      previewUrl: `http://localhost:${PORT}/temp_proto/${toPosixPath(relativeCapturePath)}/index.html`,
      restorePreviewUrl,
      restoreComponentPath: toProjectRelativePath(restoreResult.entryFilePath),
      specPath: toProjectRelativePath(path.join(restoreResult.pageDir, 'spec.md')),
      restoreAssetsPath: {
        fonts: toProjectRelativePath(restoreResult.fontsDir),
        images: toProjectRelativePath(restoreResult.imagesDir)
      },
      pagesJsonPath: toProjectRelativePath(restoreResult.pagesJsonPath),
      restoreMetaPath: toProjectRelativePath(restoreResult.metaDir),
      qaReportPath: toProjectRelativePath(restoreResult.qaReportPath),
      readyState: restoreResult.readyState,
      editability: restoreResult.pageIR?.editability || null,
      qa: restoreResult.pageIR?.qa || null,
      captureVariant,
      metadata: captureMetadata,
      assets: localizedResult.assetReport,
      captureQuality
    }, { spaces: 2 });

    if (!KEEP_CAPTURE_ARTIFACTS) {
      await fs.remove(projectDir);
    }

    let parentDir = path.dirname(projectDir);
    while (!KEEP_CAPTURE_ARTIFACTS && parentDir !== CAPTURE_ROOT && parentDir.startsWith(CAPTURE_ROOT)) {
      try {
        const files = await fs.readdir(parentDir);
        if (files.length === 0) {
          await fs.remove(parentDir);
          parentDir = path.dirname(parentDir);
        } else {
          break;
        }
      } catch (_err) {
        break;
      }
    }

    finalizeRestoreTargetSession(metadata, captureVariant);

    if (task) {
      updateSaveTask(runId, {
        status: 'success',
        phase: 'restore',
        message: '已完成抓取与还原',
        currentItemTitle: '协议页面包已生成',
        progressText: '完成'
      });
      clearSaveTaskLater(runId);
    }

    console.log(`✅ 拾取完成！截图与代码均已同步。`);
    console.log(`==========================================`);

    res.send({
      status: 'success',
      capturePath: toProjectRelativePath(projectDir),
      captureCleanupStatus: KEEP_CAPTURE_ARTIFACTS ? 'kept' : 'deleted',
      restoreTargetPath: toProjectRelativePath(restoreResult.pageDir),
      restorePreviewUrl,
      restoreComponentPath: toProjectRelativePath(restoreResult.entryFilePath),
      specPath: toProjectRelativePath(path.join(restoreResult.pageDir, 'spec.md')),
      restoreAssetsPath: {
        fonts: toProjectRelativePath(restoreResult.fontsDir),
        images: toProjectRelativePath(restoreResult.imagesDir)
      },
      pagesJsonPath: toProjectRelativePath(restoreResult.pagesJsonPath),
      restoreMetaPath: toProjectRelativePath(restoreResult.metaDir),
      qaReportPath: toProjectRelativePath(restoreResult.qaReportPath),
      readyState: restoreResult.readyState,
      editability: restoreResult.pageIR?.editability || null,
      qa: restoreResult.pageIR?.qa || null,
      captureVariant,
      assets: localizedResult.assetReport,
      captureQuality,
      progressTitle: '协议页面包已生成'
    });
  } catch (error) {
    if (task) {
      const isCanceled = error?.name === 'AbortError' || /取消/.test(String(error?.message || ''));
      updateSaveTask(runId, {
        status: isCanceled ? 'canceled' : 'error',
        phase: task.phase || 'save',
        message: isCanceled ? '已取消当前同步' : (error.message || '处理失败'),
        currentItemTitle: '',
        progressText: ''
      });
      clearSaveTaskLater(runId);
    }

    if (projectDir) {
      await fs.remove(projectDir).catch(() => undefined);
    }
    if (restoreRelativeDirForCleanup) {
      await cleanupFailedRestoreOutput(restoreRelativeDirForCleanup).catch(() => undefined);
    }
    if (task?.metadata && task?.captureVariant) {
      finalizeRestoreTargetSession(task.metadata, task.captureVariant);
    }

    console.error('❌ 处理出错:', error);
    if (error?.name === 'AbortError' || /取消/.test(String(error?.message || ''))) {
      res.status(499).send({ status: 'canceled', message: error.message || '当前同步已取消' });
      return;
    }
    res.status(500).send({ status: 'error', message: error.message });
  }
});

const configuredPort = Number.parseInt(process.env.PORT || '', 10);
const PORT = Number.isFinite(configuredPort) ? configuredPort : DEFAULT_PORT;

const server = app.listen(PORT, () => {
  console.log(`
  **********************************************
  🚀 PM 原型复刻服务器 [登录态兼容版] 已启动！
  📡 监听端口: ${PORT}
  🛠️  模式: 浏览器同步截图 (不再使用后台抓取)
  📦 restore.js 版本: 2026-04-10T11:22 (conservative runtime: evidence-driven tab/carousel activation + heuristic layout fixes opt-in)
  **********************************************
  `);
});

server.on('error', (err) => {
  if (err && err.code === 'EADDRINUSE') {
    console.error(`❌ 端口 ${PORT} 被占用，请先关闭占用进程或换一个端口启动（例如 PORT=3002 node server.js）。`);
    process.exitCode = 1;
    return;
  }
  console.error('❌ 服务启动失败:', err);
  process.exitCode = 1;
});
